import os
import gc
import torch
import psutil
from util.env import EMBEDDINGS_MODEL_NAME, EMBEDDINGS_MODEL_DIR, RERANKER_MODEL_NAME
from langchain_community.embeddings import HuggingFaceBgeEmbeddings



def cuda_show_memory_usage():
    if torch.cuda.is_available():
        print("Show memory:")
        print(torch.cuda.memory_summary())
        print(torch.cuda.memory_stats())
        print(torch.cuda.mem_get_info())
        print(torch.cuda.memory_allocated())
        print(torch.cuda.memory_reserved())
    else:
        print("cuda_show_memory_usage: no Cuda available")


def cuda_cache_clean_up():
    if torch.cuda.is_available():
        with torch.no_grad():
            torch.cuda.empty_cache()
        print("cleared the gpu cache...")
    else:
        print("No Cuda available")

def cuda_memory_info():
    try:
        cuda_cache_clean_up()
        print("cleared the gpu cache...")
        print("GPU MEMORY", torch.cuda.get_device_properties(0).total_memory)
        print("SYSTEM MEMORY", psutil.virtual_memory().available)
        gc.collect()
    except Exception as ex:
        print(ex)

def get_embedding_snapshot_path(cache_directory, model_name):
    temp = model_name.replace("/", "--")
    _model_path = f"models--{temp}"
    path1 = os.path.join(cache_directory, _model_path)
    snapshot_names = os.listdir(os.path.join(path1, "snapshots"))
    embedding_location = os.path.join(path1, "snapshots", snapshot_names[0])
    return embedding_location

encode_kwargs = {'normalize_embeddings': True}  # set True to compute cosine similarity

### Load models that we don't want to use GPU
os.environ["TOKENIZERS_PARALLELISM"] = "false"
model_kwargs = {'device': 'cpu'}

print("start")
cuda_show_memory_usage()

# downloading the reranker model and caching out in EMBEDDINGS_CACHE_DIR+RERANKER_MODEL_NAME(with underscore)
try:
    print(model_kwargs)
    embeddings_ = HuggingFaceBgeEmbeddings(model_name=RERANKER_MODEL_NAME,
                                           model_kwargs=model_kwargs,
                                           encode_kwargs=encode_kwargs,
                                           cache_folder=EMBEDDINGS_MODEL_DIR)
    print(f"Downloaded Reranker {RERANKER_MODEL_NAME}:", embeddings_)
    del embeddings_
    gc.collect()
except Exception as ex:
    print(ex)

cuda_memory_info()

if torch.cuda.is_available():
    model_kwargs = {'device': 'cuda'}
    os.environ["TORCH_USE_CUDA_DSA"] = "1"
    os.environ["CUDA_LAUNCH_BLOCKING"] = "1"
    # clear what we set when only CPU
    os.environ.pop("TOKENIZERS_PARALLELISM")


# now load models with GPU ---- move any of the model loading below here if needed


cuda_memory_info()
print(model_kwargs)
embeddings = HuggingFaceBgeEmbeddings(model_name=EMBEDDINGS_MODEL_NAME,
                                      model_kwargs=model_kwargs,
                                      encode_kwargs=encode_kwargs,
                                      cache_folder=EMBEDDINGS_MODEL_DIR)
print(f"Downloaded Embedding {EMBEDDINGS_MODEL_NAME}:", embeddings)
cuda_memory_info()
