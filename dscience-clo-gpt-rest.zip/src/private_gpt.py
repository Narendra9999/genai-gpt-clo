import time
import os
import heapq
import gc
import torch
import re

import langchain
from langchain.chains import RetrievalQA
from langchain_community.llms import GPT4All, LlamaCpp, CTransformers
from llama_cpp import Llama

from langchain_community.vectorstores import OpenSearchVectorSearch
from FlagEmbedding import FlagReranker
from langchain.cache import InMemoryCache
from langchain.docstore.document import Document
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_experimental.text_splitter import SemanticChunker

from util import env, logger
from sys import platform
from huggingface_hub import hf_hub_download

from src.nlp_config import embeddings, cuda_memory_info, cuda_show_memory_usage, get_embedding_snapshot_path
from src.model_functions import download_model_to_workspace
from src.llama_prompt import chain_type_kwargs

from util.env import opensearch_client, opensearch_credentials, opensearch_host_url
from opensearchpy import RequestsHttpConnection

langchain.llm_cache = InMemoryCache()

logger = logger.getlogger()

source_documents = env.SOURCE_DIRECTORY
embeddings_model_name = env.EMBEDDINGS_MODEL_NAME
persist_directory = env.PERSIST_DIRECTORY
model_type = env.MODEL_TYPE
model_path = env.MODEL_FILE_PATH
model_n_ctx = env.MODEL_N_CTX
model_dir = env.MODEL_DIR_LOC
model_n_batch = env.MODEL_N_BATCH
model_n_threads = env.MODEL_N_THREADS
target_source_chunks = env.TARGET_SOURCE_CHUNKS
max_tokens = env.MAX_TOKEN
RERANKER_MODEL_NAME = env.RERANKER_MODEL_NAME
top_k_rerank_chunks = env.TOP_K_RERANK_CHUNKS
model_name = env.MODEL_NAME
CHROMADB = env.CHROMADB
CLO_USER = env.CLO_USER
chunk_size = env.CHUNK_SIZE
chunk_overlap = env.CHUNK_OVERLAP

def trim_incomplete_sentence(paragraph):
    if paragraph and len(paragraph) > 2 and not paragraph.endswith('.'):
        # Split the paragraph into sentences and remove any empty strings and leading/trailing whitespaces
        sentences = [sentence.strip() for sentence in paragraph.split('.') if sentence.strip()]

        if len(sentences) >= 2:
            sentences.pop()

        # Join the remaining sentences back into a paragraph
        trimmed_paragraph = '. '.join(sentences)

        return trimmed_paragraph

    else:
        return paragraph

def download_model_to_path(m_path, repo_id, file_name, cache_dir=None):
    if os.path.exists(m_path):
        logger.info("Model File already exist in /model location ")
        import glob
        for filename in glob.iglob(m_path + "/**", recursive=True):
            print(filename)
        return m_path
    else:
        logger.info(f"{m_path} Model File Not found!. downloading now...")

        if cache_dir is None:
            m_dir = model_dir
        else:
            m_dir = cache_dir
        try:
            file = hf_hub_download(repo_id=repo_id, filename=file_name, cache_dir=m_dir)
            logger.info(file)
            return file
        except Exception as ex:
            print(ex)

def split_into_paragraphs(file_names, term_list, text):
    # text_splitter = SemanticChunker(embeddings)
    rec_text_splitter = RecursiveCharacterTextSplitter(chunk_size=chunk_size, chunk_overlap=chunk_overlap)
    
    file_name = file_names[0]
    metadata = {'source': file_name}
    newDoc = [Document(page_content=text, metadata = metadata)]
    # semantic_chunks = text_splitter.split_documents(newDoc)
    recursive_semantic_chunks = rec_text_splitter.split_documents(newDoc)

    paragraphs = []
    
    for t in recursive_semantic_chunks:
        if t.page_content:
            sub_paragraphs = ' '.join(term_list) + ' : ' + t.page_content.strip(' \n\t')
            paragraphs.append(sub_paragraphs)

    return paragraphs


class QAndAModel:

    def __init__(self):

        self.llm = None
        self.qa = None
        self.reranker = None
        self.retriever = None

        try:
            logger.info("QAndAModel init!")
            if not self.load_model():
                raise Exception("Model Unable to configure, Ensure the Model download to Model Location and Access")

            cuda_memory_info()
            result = self.op_refresh_db(CLO_USER)

            if result:
                logger.info("Initial DB Refresh & Model Configuration is completed")
            else:
                logger.info("Failed to refresh DB")

        except Exception as ex:
            logger.error(ex)
            cuda_show_memory_usage()
            raise RuntimeError(ex)

        logger.info("to return from QAndAModel")


    def get_top_k_ranked_indices(self, qa_pairs, k):
        try:
            logger.info(f"In get_top_k_ranked_indices with K: {k}, len(qa_pairs): {len(qa_pairs)}")

            # Compute ranker scores
            ranker_scores = self.reranker.compute_score(qa_pairs)

            # Create a min-heap of (value, index) tuples
            heap = [(value, index) for index, value in enumerate(ranker_scores)]
            heapq.heapify(heap)

            k = min(k, len(qa_pairs))

            # Extract the top k indices
            top_k_ranked_indices = [index for _, index in heapq.nlargest(k, heap)]

            return top_k_ranked_indices

        except Exception as ex:
            logger.error(f"An error occurred in get_top_k_ranked_indices: {str(ex)}")
            return []

    def send_topk_ranked_chunks_to_llm(self, user_question, is_this_batch_job):
        try:
            logger.info(f"In send_topk_ranked_chunks_to_llm: {user_question}")

            # Retrieve relevant documents
            _documents = self.retriever.get_relevant_documents(query=user_question)
            logger.info(f"In send_topk_ranked_chunks_to_llm, _documents len: {len(_documents)}")

            # Prepare QA pairs
            _pairs = [[user_question, doc.page_content] for doc in _documents]
            logger.info(f"In send_topk_ranked_chunks_to_llm, _pairs len: {len(_pairs)}")

            # Get top k ranked indices
            top_k_indices = self.get_top_k_ranked_indices(_pairs, k=top_k_rerank_chunks)
            logger.info(f"In send_topk_ranked_chunks_to_llm, top_k_indices: {top_k_indices}")

            top_k_chunks = []
            source_data = []

            for index in top_k_indices:
                top_k_chunks.append(_documents[index].page_content)
                source_data.append({"doc_name": _documents[index].metadata["source"],
                                    'source_content': _documents[index].page_content})

            context = '\n'.join(top_k_chunks)

            if not context or len(context) <= 5:
                context = 'NO CONTEXT FOUND!'
                return {"query": user_question, "answer": context, "source": [], "status": 200,
                   "retrieval_time": 0}

            answer = ''
            _start_time = time.time()

            if not is_this_batch_job:
                prompt = chain_type_kwargs['prompt'].format(context=context, question=user_question)

                if model_type=="llama3":

                    logger.info(f"In send_topk_ranked_chunks_to_llm, prompt: {prompt}")
                    raw_answer = self.llm(prompt, max_tokens=max_tokens, temperature=0.1)['choices'][0]['text']
                    raw_answer = raw_answer.replace("|eot_id|", "")

                    if torch.cuda.is_available(): torch.cuda.empty_cache()
                else:

                    logger.info(f"In send_topk_ranked_chunks_to_llm, prompt: {prompt}")
                    raw_answer = self.llm.invoke(prompt)
                
                raw_answer = raw_answer.split("assistant")[0]

                answer = trim_incomplete_sentence(raw_answer)

            res = {"query": user_question, "answer": answer, "source": source_data, "status": 200,
                   "retrieval_time": round(time.time() - _start_time, 2)}

            logger.info(f"send_topk_ranked_chunks_to_llm - response:{res}")

        except Exception as ex:
            logger.error(f"An error occurred in send_topk_ranked_chunks_to_llm: {str(ex)}")
            res = {"query": user_question, "answer": '', "source": [], "status": 500, "retrieval_time": 0}

        return res

    def query_llm_with_es_context(self, es_responses, user_question, is_this_batch_job):
        try:
            # Extract the document name from the first response
            doc_name = es_responses[0]['file_name']

            # Initialize lists to store context, definition terms, and file names
            context_list = []
            term_list = []
            file_names = []

            # Loop through Elasticsearch responses to extract relevant data
            for esp in es_responses:
                file_names.append(esp['file_name'])
                if 'term' in esp and 'text' in esp:
                    term_list.append(esp['term'])
                    context_list.append(' '.join([esp['term'], esp['text']]))


            # Join context into a single string
            context = '\n'.join(context_list)

            if not context or len(context) <= 5:
                return self.send_topk_ranked_chunks_to_llm(user_question)

            # Check if context length is within limits
            elif len(context) <= 2048:
                # If within limits, construct prompt and source data
                prompt = chain_type_kwargs['prompt'].format(context=context, question=user_question)
                source_data = [{"doc_name": doc_name, 'source_content': context}]
            else:
                # If exceeds limits, split context into paragraphs and select top-k chunks
                term_list = list(set(term_list))
                file_names = list(set(file_names))
                paragraphs = split_into_paragraphs(file_names, term_list, context)
                _pairs = [[user_question, p] for p in paragraphs]
                top_k_indices = self.get_top_k_ranked_indices(_pairs, k=top_k_rerank_chunks)
                logger.info(f"In query_llm_with_es_context, top_k_indices: {top_k_indices}")

                top_k_chunks = [paragraphs[index] for index in top_k_indices]
                top_context = '\n'.join(top_k_chunks)

                # Construct prompt and source data from top-k chunks
                prompt = chain_type_kwargs['prompt'].format(context=top_context, question=user_question)
                source_data = [{"doc_name": doc_name, 'source_content': top_context}]

            # Measure execution time
            _start_time = time.time()

            # Log prompt information
            logger.info(f'len(prompt): {len(prompt)}')
            logger.info(f"prompt: {prompt}")

            answer = ''
            # Invoke LLM model and retrieve raw answer
            if source_data[0]['doc_name'] == 'dummy_filename.docx':
                answer = ' '.join(source_data[0]['source_content'].split())
            elif not is_this_batch_job:
                if model_type=='llama3':
                    raw_answer = self.llm(prompt=prompt, max_tokens=max_tokens, temperature=0.1)['choices'][0]['text']
                    raw_answer = raw_answer.replace("|eot_id|", "")
                    if torch.cuda.is_available(): torch.cuda.empty_cache()

                else:
                    raw_answer = self.llm.invoke(prompt)
                    
                raw_answer = raw_answer.split("assistant")[0]
                answer = trim_incomplete_sentence(raw_answer)

            # Log answer
            logger.info(f"raw answer: {answer}")

            # Construct response dictionary
            res = {"query": user_question, "answer": answer, "source": source_data, "status": 200,
                   "retrieval_time": round(time.time() - _start_time, 2)}

            # Log response information
            logger.info(f"query_llm_with_es_context- response:{res}")

            return res

        except Exception as e:
            # Log any exceptions that occur during the execution of the function
            logger.error(f"An error occurred: {str(e)}")
            # Return a generic error response
            return {"query": user_question, "answer": 'An error occurred while processing the query.', "source": None,
                    "status": 500, "retrieval_time": 0}

    @staticmethod
    def _retriever_context(user_question):
        input_query = user_question
        user_id = CLO_USER
        top_k_doc_retriever = target_source_chunks
        all_indices = opensearch_client.cat.indices(format='json')
        indices_list = [index['index'] for index in all_indices]
        if user_id in indices_list:
            db = OpenSearchVectorSearch(index_name=user_id, embedding_function=embeddings,
                                        http_auth=opensearch_credentials, opensearch_url=opensearch_host_url,
                                        use_ssl=True, verify_certs=True, ssl_show_warn=False,
                                        timeout=300, connection_class=RequestsHttpConnection
                                        )


            search_options = {"k": top_k_doc_retriever}
            retriever = db.as_retriever(search_kwargs=search_options)
            _documents = retriever.get_relevant_documents(query=input_query)
            _documents_json = {}
            for _document in _documents:
                page_content = re.sub(' +', ' ', _document.page_content)
                doc_name = _document.metadata['source'].split('/')[-1]
                if doc_name in _documents_json:
                    _documents_json[str(doc_name)] = str(_documents_json[str(doc_name)]) + "\n\n" + page_content
                else:
                    _documents_json[str(doc_name)] = str(page_content)
            return _documents_json, _documents
        else:
            return "No Context for given user for the question, response assistant as Ask user to upload the document", []

    def connect_qa_model(self, user_question: str):
        logger.info(f"QAndAModel- user_question:{user_question}")
        if not os.path.exists(persist_directory):
            return {"query": user_question,
                    "message": "Execute the Model ingestion layer",
                    "source": " Click on ingest",
                    "status": 201}

        if user_question is not None and user_question != "":
            qa = self.qa
            try:
                _start_time = time.time()
                if model_type == 'llama3':
                    context, docs = self._retriever_context(user_question)
                    prompt = chain_type_kwargs['prompt'].format(context=context, question=user_question)
                    raw_answer = self.llm(prompt, max_tokens=max_tokens, temperature=0.1)['choices'][0]['text']
                    raw_answer = raw_answer.replace("|eot_id|", "")

                    if torch.cuda.is_available(): torch.cuda.empty_cache()
                else:
                    res = qa.invoke(user_question)
                    raw_answer, docs = res['result'], res['source_documents']

                raw_answer = raw_answer.split("assistant")[0]

                # answer = raw_answer
                answer = trim_incomplete_sentence(raw_answer)

                _end_time = time.time()
                source_data = []
                for document in docs:
                    # source_data.append({"name": document.metadata["source"]})
                    source_data.append(
                        {"doc_name": document.metadata["source"], 'source_content': document.page_content})
                results_ = {"query": user_question, "answer": answer, "source": source_data, "status": 200,
                            "retrieval_time": round(_end_time - _start_time, 2)
                            }
                logger.info(f"qa_results: {results_}")
                return results_
            except Exception as ex:
                logger.error(str(ex))
                return {"message": str(ex), "status": 400}
        return {"message": "Empty Query", "status": 201}

    def load_model(self, model_path=model_path, model_name=model_name, model_type=model_type, num_gpu_layer=-1):
        """
         method connects to the model folder and creates a model object.
         It is responsible for initializing the necessary components to load a pre-trained model
         from a specified directory or location. Once the model is loaded, it will be available as global variable
        :return: assign LLM object to GLOBAL object
        """
        try:
            if not os.path.exists(model_path):
                logger.info(f"Model not available : {model_path}")
            else:
                logger.info(f"Model already available : {model_path}")
                # os.remove(model_path)

            if self.reranker is None:
                if platform.startswith('win'):
                    reranker_path = get_embedding_snapshot_path(env.EMBEDDINGS_MODEL_DIR, env.RERANKER_MODEL_NAME)
                else:
                    reranker_path = os.path.join(env.EMBEDDINGS_MODEL_DIR, env.RERANKER_MODEL_NAME.replace('/', '_'))
                logger.info(f"reranker location: {reranker_path}")
                self.reranker = FlagReranker(reranker_path)
                print("reranker:", self.reranker)

            callbacks = []  # [StreamingStdOutCallbackHandler()]
            cuda_show_memory_usage()
            match model_type:
                case "llama3":
                    logger.info(f"Loading model from {model_path}")
                    # m_path = download_model_to_path(model_path, "TheBloke/CausalLM-14B-GGUF", "causallm_14b.Q5_1.gguf")
                    del self.llm
                    self.llm = None
                    gc.collect()
                    if torch.cuda.is_available(): torch.cuda.empty_cache()
                    with torch.no_grad():
                        self.llm = Llama(
                            model_path=model_path,
                            n_gpu_layers=-1,
                            n_batch=int(model_n_batch),
                            n_ctx=int(model_n_ctx),
                            max_tokens=int(max_tokens),
                            temperature=float(0.01),
                            top_p=float(0.01),
                            top_k=100,
                            repetition_penalty=float(1.4),
                            seed=1,
                            f16_kv=True,  # MUST set to True, otherwise you will run into problem after a couple of calls
                            verbose=False,  # True,  # Verbose is required to pass to the callback manager
                        )
                        
                        logger.info(f"{model_path} : llama3 model configured completed..")
                        return True
                    
                case "LlamaCpp" | "llama":
                    download_model_to_workspace(model_path, model_name)
                    logger.info(f"Loading model from {model_path}")
                    # m_path = download_model_to_path(model_path, "TheBloke/CausalLM-14B-GGUF", "causallm_14b.Q5_1.gguf")
                    del self.llm
                    self.llm = None
                    gc.collect()
                    cuda_memory_info()
                    self.llm = LlamaCpp(model_path=model_path,
                                        n_ctx=model_n_ctx,
                                        n_batch=model_n_batch,
                                        n_threads=model_n_threads,
                                        seed=1,
                                        max_tokens=max_tokens,
                                        temperature=0.01,
                                        callbacks=callbacks,
                                        n_gpu_layers=-1,
                                        f16_kv=True,
                                        top_p=0.01,
                                        top_k=100,
                                        verbose=True)
                    logger.info(f"{model_path} : LlamaCpp model configured completed..")
                    cuda_memory_info()
                    return True
                case "causalLM":
                    if num_gpu_layer is None:
                        num_gpu_layer = -1
                    download_model_to_workspace(model_path, model_name)
                    del self.llm
                    self.llm = None
                    gc.collect()
                    cuda_memory_info()
                    logger.info(f"Loading causalLLM model from {model_path}, n_gpu_layer:{num_gpu_layer}")
                    self.llm = LlamaCpp(model_path=model_path,
                                        n_ctx=model_n_ctx,
                                        n_batch=model_n_batch,
                                        n_threads=model_n_threads,
                                        seed=1,
                                        max_tokens=max_tokens,
                                        temperature=0.1,
                                        callbacks=callbacks,
                                        n_gpu_layers=num_gpu_layer,
                                        f16_kv=True,
                                        top_p=2,
                                        top_k=100,
                                        verbose=True)

                    logger.info(f"{model_path} : causalLLM model configured completed..")
                    cuda_memory_info()
                    return True
                case "gptq":
                    cuda_memory_info()
                    input_model_name = model_name
                    input_model_type = model_type
                    config = {
                        "context_length": env.MODEL_N_CTX,
                        "max_new_tokens": env.MAX_TOKEN,
                        "threads": env.MODEL_N_THREADS,
                        "repetition_penalty": 1.1,
                        "temperature": 0.1,
                        # "stream": True,
                        'seed': 1,
                        "reset": True
                    }
                    logger.info(config)
                    self.llm = CTransformers(model=input_model_name,
                                             model_type=input_model_type,
                                             config=config
                                             )
                    cuda_memory_info()
                    cuda_show_memory_usage()
                    logger.info(f"{input_model_name} : gptq model configured completed..")
                    return True
                case "GPT4All":
                    self.llm = GPT4All(model=model_path, n_ctx=model_n_ctx,
                                       backend='gptj', n_batch=model_n_batch,
                                       callbacks=callbacks, verbose=False)
                    logger.info("model configured completed..")
                    cuda_memory_info()
                    return True
                case "mistral":
                    config = {'top_k': 40,
                              'top_p': 0.95,
                              'temperature': 0.5,
                              'repetition_penalty': 1.1,
                              'last_n_tokens': 64,
                              'seed': 1,
                              'max_new_tokens': max_tokens,
                              'batch_size': model_n_batch,
                              'threads': model_n_threads,
                              'context_length': model_n_ctx,
                              #   'gpu_layers': 50
                              }
                    if env.local_model:
                        input_model_name = env.MODEL_FILE_PATH
                        input_model_type = "mistral"
                    else:
                        input_model_name = "TheBloke/Mistral-7B-Instruct-v0.2-GPTQ"
                        input_model_type = "gptq"

                    self.llm = CTransformers(model=input_model_name,
                                             model_type=input_model_type,
                                             config=config,
                                             device_map="auto")
                    return True
                case _default:
                    logger.warning(f"Model {model_type} not supported!")
                    return False
        except Exception as ex:
            logger.error(ex)
            cuda_show_memory_usage()
            raise Exception(ex)

        # logger.info("load model will return")
        return False

    def op_refresh_db(self, user_id=None):
        logger.info("op_refresh_db")
        try:
            self.db = OpenSearchVectorSearch(
                index_name=user_id,
                embedding_function=embeddings,
                http_auth=opensearch_credentials,
                opensearch_url=opensearch_host_url,
                use_ssl=True,
                verify_certs=True,
                ssl_show_warn=False,
                timeout=300,
                connection_class=RequestsHttpConnection
            )
            self.retriever = self.db.as_retriever(search_kwargs={"k": env.TARGET_SOURCE_CHUNKS})
            
            if model_type != 'llama3':
                self.qa = RetrievalQA.from_chain_type(llm=self.llm,
                                                    chain_type="stuff",
                                                    retriever=self.retriever,
                                                    chain_type_kwargs=chain_type_kwargs,
                                                    return_source_documents=True)
            else:
                logger.info(f"self.qa is not set as the model_type: {model_type}!")

            logger.info("Q & A Model is configured....")
            return True
        except Exception as ex:
            logger.warning(ex)
            return False

if __name__ == '__main__':
    print("This is main call for this module, used for Unittest/Dry Run")
    # Get the answer from the chain
    start_time = time.time()
    from src.ingestion import DBIngestion

    print("This is main call for this module, used for Unittest/Dry Run")
    ingestionObj = DBIngestion()
    print(ingestionObj.status)
    qaObject = QAndAModel()
    while True:
        query = input("enter the input query: ")
        if query == 'exit':
            break
        # Get the answer from the chain
        end_time = time.time()
        print("TIME GAP", round(end_time - start_time, 2))
        results = qaObject.connect_qa_model(query)
        print(results)
