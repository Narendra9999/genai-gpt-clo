from langchain.prompts import PromptTemplate
from util.env import MODEL_TYPE

chain_type_kwargs = {"prompt": ""}
prompt_template = ''

if MODEL_TYPE in ('gptq', 'LlamaCpp'):
    # Default LLaMA-2 prompt style
    B_INST, E_INST = "<s>[INST] ", "[/INST]</s>"
    B_SYS, E_SYS = "<<SYS>>\n", "\n<</SYS>>\n\n"
    DEFAULT_SYSTEM_PROMPT = """\
    You are a helpful, respectful and honest assistant. Always answer as helpfully as possible, while being safe. Your answers should not include any harmful, unethical, racist, sexist, toxic, dangerous, or illegal content. Please ensure that your responses are socially unbiased and positive in nature.

    If a question does not make any sense, or is not factually coherent, explain why instead of answering something not correct. If you don't know the answer to a question, please don't share false information."""

    def get_prompt(input_instruction, new_system_prompt=DEFAULT_SYSTEM_PROMPT):
        SYSTEM_PROMPT = B_SYS + new_system_prompt + E_SYS
        _prompt_template = B_INST + SYSTEM_PROMPT + input_instruction + E_INST
        return _prompt_template

    # sys_prompt = """Answer the Question based on the CONTEXT below. Keep the answer short, non-repetitive and 
    # concise. Respond "I don't know" if not sure about the answer."""
    # instruction = """CONTEXT:/n/n {context}/n Question: {question}/n Answer:"""
    sys_prompt = """Answer the question in the specified format, using only the provided CONTEXT below. Think logically, step by step, through the multiple parts of the question, and find the answer to each part before providing the final answer. Respond with \"I don't know\" if you are unsure about the answer.\n"""
    instruction = "CONTEXT:{context}\nQuestion: {question}\nAnswer: "

    prompt_template = get_prompt(instruction, sys_prompt)

elif MODEL_TYPE in ('mistral', 'zephyr'):
    prompt_template = """
    <|system|>
    You are a Collateralized loan obligation documents Specialist at a Credit Rating Agency.
    </s>
    <|user|> Answer the Question based on the CONTEXT below. Keep the answer short, non-repetitive and concise. Respond "I don't know" if not sure about the answer..
    CONTEXT:
    {context}
    Question: {question}

    </s>
    <|assistant|>
    Answer:
    """

elif MODEL_TYPE in ('causalLM'):
    prompt_template = """<|im_start|>system\nAnswer the question in the specified format, using only the information in the provided Context. Think logically step by step through the multiple parts of the question and find the answer to each part, before providing the final answer. Don't repeat or hallucinate.\n<|im_end|>\n<|im_start|>user\nQuestion: {question}\nContext: {context}\n<|im_end|>\n<|im_start|>assistant\nAnswer: """

elif MODEL_TYPE in ('llama3', 'llama'):
    prompt_template = """<|start_header_id|>system<|end_header_id|>\n\n\
    Using the provided "Context," please answer the "Question" logically. Ensure that your response is concise, follows the requested format, and does not hallucinate or repeat information. Provide only accurate and relevant information based on the context given.<|eot_id|>\n<|start_header_id|>user<|end_header_id|>\n\n\
    Question: {question}\n\nContext:{context}<|eot_id|>\n<|start_header_id|>assistant<|end_header_id|>\n\n"""

llm_prompt = PromptTemplate(template=prompt_template, input_variables=["context", "question"])
chain_type_kwargs["prompt"] = llm_prompt