import os
import requests
import time
from langchain_community.vectorstores import Chroma
from opensearchpy import RequestsHttpConnection
from util import env, logger
from src.nlp_config import embeddings, cuda_memory_info
from util.env import CHROMA_SETTINGS

logger = logger.getlogger()

empty_message_info = """Hi, I'm Rating's GEN AI Sandbox, Who learns from the privately upload data and provide 
response. Please use the 'import data' to upload documents/info to make our interaction very effective & meaningfully"""


def trim_incomplete_sentence(paragraph):
    if paragraph and len(paragraph) > 2 and not paragraph.endswith('.'):
        # Split the paragraph into sentences and remove any empty strings and leading/trailing whitespaces
        sentences = [sentence.strip() for sentence in paragraph.split('.') if sentence.strip()]

        if len(sentences) >= 2:
            sentences.pop()

        if len(sentences[-1]) == 1:
            sentences.pop()

        # Join the remaining sentences back into a paragraph
        trimmed_paragraph = '. '.join(sentences)

        return trimmed_paragraph + "."

    else:
        return paragraph


sys_prompt = """As a expert in the financial domain, you should provide honest, respectful,
and helpful responses regarding compliance, standard operating procedures, and financial matters within a Ratings firm.
Credibility is key, so keep the responses concise, accurate, reliable, and non-repetitive.
Answer the Question based on the Context below. Keep the answer short and concise.
If information is lacking, indicate so; don't provide false responses.
"""


def run_azure_endpoint(input_system_prompt, selected_context, user_prompt):
    url = 'https://10.173.18.4/openai/deployments/gpt-35-turbo-16k/chat/completions?api-version=2023-05-15'
    headers = {"Content-Type": "application/json", "api-key": '10a91bf98cd347bd963bf7acc78dcfe0'}

    # selected_context = ""  # RAG
    # user_prompt = "summarize the document"  # question
    system_context = f"""{input_system_prompt} Answer only from given or else say I don't know  \n
                       Context: {selected_context} \n
                      """

    data = {
        "messages":
            [
                {"role": "system", "content": system_context},  # system prompt
                {"role": "user", "content": user_prompt},  # question i.e user prompt
            ],
        # "temperature": "0.3",
        # "max_tokens": 4096
    }
    try:
        response = requests.post(url, headers=headers, json=data, timeout=25, verify=False)
        if response.status_code == 200:
            print('4k Model is working for https://rating-nonprod-useast2.openai.azure.com ')
            print(response.json())
            return response.json()
    except Exception as ex:
        print(f'4k Model is NOT working for https://rating-nonprod-useast2.openai.azure.com {ex}')


def azure_open_end_to_end_model_flow(params: dict):
    try:
        cuda_memory_info()
        user_id = params.get("user_id", "clo-gpt-si")
        input_query = params.get("query")
        input_sys_prompt = params.get("DefaultPrompt", sys_prompt)
        top_k = params.get("top_k", env.TARGET_SOURCE_CHUNKS)

        db = Chroma(persist_directory=env.PERSIST_DIRECTORY,
                    embedding_function=embeddings,
                    client_settings=CHROMA_SETTINGS)

        source_file_name = os.path.join(env.SOURCE_DIRECTORY, user_id, params.get("file_name"))
        retriever = db.as_retriever(search_kwargs={"k": top_k,
                                                   "filter": {"source": {"$eq": source_file_name}}})
        _documents = retriever.get_relevant_documents(query=input_query)

        res = run_azure_endpoint(input_sys_prompt, _documents, input_query)  # azure open
        _start_time = time.time()
        answer = res['choices'][0]['message']['content']
        docs = _documents
        # answer, docs = res['result'], res['source_documents']
        answer = trim_incomplete_sentence(answer)
        _end_time = time.time()
        source_data = []
        for document in docs:
            source_data.append(
                {
                    "doc_name": document.metadata["source"],
                    'source_content': document.page_content}
            )
        source_data.append(
            {"doc_name": "-", 'source_content': "Prompt Info for reference - > " + str(input_sys_prompt)})
        results_ = {"query": input_query,
                    "answer": answer,
                    "source": source_data,
                    "retrieval_time": round(_end_time - _start_time, 2)
                    }
        params.update(results_)
        logger.info(params)
        del params
        cuda_memory_info()
        return results_
    except Exception as ex:
        cuda_memory_info()
        logger.error(ex)
