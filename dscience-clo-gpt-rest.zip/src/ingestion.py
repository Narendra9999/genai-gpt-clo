import os
import re
import glob
import time
from measure_exec_time import measure_time
from langchain.docstore.document import Document
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_community.vectorstores import OpenSearchVectorSearch
from opensearchpy import RequestsHttpConnection

from util import env, logger, common_functions
from src.nlp_config import embeddings, cuda_memory_info
from src.document_upload_type import load_documents

from util.clo_common_extractor import DefinitionExtractor
from util.db_elastic import init_es_client, load_data, search_es, check_and_delete_index_es
from util.env import opensearch_client, opensearch_credentials, opensearch_host_url, CLO_USER
from util.s3utils import S3FileManager

logger = logger.getlogger()

persist_directory = env.PERSIST_DIRECTORY
source_directory = env.SOURCE_DIRECTORY
chunk_size = env.CHUNK_SIZE
chunk_overlap = env.CHUNK_OVERLAP
global_s3_bucket_name = env.global_s3_bucket_name
documents_s3_loc = env.documents_s3_loc
s3_file_manager = S3FileManager(global_s3_bucket_name)
CHROMADB = env.CHROMADB

def search_definitions_old(query_term):

    final_search_strings = []
    #Definition filters to identify if the user_question is related to definitions
    definition_filters = {'definition', 'definitions', 'section', 'sections', 'define'}

    query_term_lower = query_term.split(':')[0].lower() if ':' in query_term else query_term.lower()
    # query_term_lower = query_term.lower()

    # Check if any definition filter is present in the user_question
    if any(substring in query_term_lower for substring in definition_filters):
        # Regular expression pattern to extract text within single or double quotes
        pattern = r"'(.*?)'|\"(.*?)\""
        matches = re.findall(pattern, query_term_lower)

        # Extract the final search string from the matches
        final_search_strings = list(set([match[0] or match[1] for match in matches]))

        logger.info(f"final_search_strings: {final_search_strings}")
    
    return final_search_strings

def extract_values(query, keyword):
    """
    Extracts values associated with a given keyword from a string.

    Args:
    string (str): The input string to search for values.
    keyword (str): The keyword to search for in the string.

    Returns:
    list: A list of values associated with the keyword.
    """
    # Initialize a list to store definitions or sections
    items = []

    # Split the query string by the provided keyword
    parts = query.split(keyword + '=')

    # Process each part to extract definitions or sections
    for part in parts[1:]:
        # Use regular expression to extract quoted strings
        matches = re.findall(r'"([^"]+)"|\'([^\']+)\'', part)

        # Extend the list of items with the extracted quoted strings
        items.extend([match[0] or match[1] for match in matches])

    return items

def query_parser(query):
    """
    Parses a query string to extract definitions and sections.

    Args:
    query (str): The input query string.

    Returns:
    tuple: A tuple containing a code indicating parsing success and a tuple of definitions and sections.
    """
    query_roi = query.split(':')[0]

    
    definitions = []
    sections = []

    if '#' in query_roi:
        for q in query_roi.split('#'):
            # Extract definitions and sections from the query string
            definitions.extend(extract_values(q, "definitions"))
            sections.extend(extract_values(q, "sections"))
    else:
        # Extract search strings based on definition filters
        final_search_strings = search_definitions_old(query_roi)
    
        # Combine the extracted search strings with existing definitions
        definitions.extend(final_search_strings)
        sections.extend(final_search_strings)

    # Determine the parsing code based on the presence of ':' and extracted values
    if ':' in query and (definitions or sections):
        code = 2  # Both definitions and sections found before ':'
    elif definitions or sections:
        code = 1  # Either definitions or sections found without ':'
    else:
        code = 3  # No definitions or sections found
    
    # Return the parsing code and a tuple of definitions and sections
    return code, definitions, sections

def clean_metadata_section_key(raw_key):
    clean_key = re.sub(r'[0-9()\s.]+', '', raw_key).lower()

    return clean_key


def get_word_doc_file(directory):
    roi_extensions = ['docx', 'DOCX', 'DOC', 'doc']
    files = [file for ext in roi_extensions for file in
            glob.glob(os.path.join(directory, f"**/*.{ext}"), recursive=True)]
    
    if files:
        file = files[-1]     
    else:
        file = None     
    
    return file


def add_file_name_to_metadata(texts):
    for text_doc in texts:
        for k, v in text_doc.metadata.items():
            if k == 'source':
                logger.info(text_doc.metadata['source'])
                text_doc.metadata['file_name'] = os.path.basename(v)

    return texts



def convert_es_context_to_response(es_responses, user_question):
    source_data = []
    context_string = ''
    for es_response in es_responses:
        context = ' '.join([es_response['term'], es_response['text']])
        context_string += context + '\n'
        if 'file_name' in es_response.keys():
            source_data.append({"doc_name": es_response['file_name'], 'source_content': context})

    _start_time = time.time()
    res = {"user_question": user_question, "answer": context_string, "source": source_data, "status": 200,
           "retrieval_time": round(time.time() - _start_time, 2)}

    logger.info(f"convert_es_context_to_response- response:{res}")

    return res


class DBIngestion:
    def __init__(self):
        self.sections_definitions = None

        self.status = self.op_ingest_data_to_vector_db(CLO_USER)

        logger.info(f"VECTOR DB Ingestion -initialize ingestion call status {self.status}")
        default_es_client = opensearch_client

        self.es_client = init_es_client(default_es_client)
        cuda_memory_info()

    def save_the_file(self, user_id, file_name, contents):
        dir_loc = self.user_based_source_s3_directory(user_id)
        file_name = os.path.basename(file_name)
        file_location = os.path.join(dir_loc['source_dir'], file_name)
        try:
            logger.info(f"File Location: {file_location}")
            if not os.path.exists(file_location):
                # Save contents to a new file
                with open(file_location, "wb+") as file_object:
                    file_object.write(contents)

            return file_location

        except Exception as ex:
            logger.error(ex)

        return None

    def get_sections_definitions(self, file_location=None):
        if not file_location:
            file_location = get_word_doc_file(source_directory)
            if not file_location:
                return None
        
        clo_extractor = DefinitionExtractor(file_location)

        sections_definitions_json_dict = None
        sections_definitions_json_dict = clo_extractor.extract_clo_data_using_api()

        if sections_definitions_json_dict is None or sections_definitions_json_dict['Sections_Data'] == 'Failed_to_extract':
            sections_definitions_json_dict = clo_extractor.extract_clo_data()

        if sections_definitions_json_dict is not None:
            sections_definitions = clo_extractor.extract_just_definitions(sections_definitions_json_dict)

        del clo_extractor

        logger.info(f"sections_definitions length: {len(sections_definitions)}")
        return sections_definitions

    def index_into_es(self, user_id, file_location):
        logger.info(f"file_location: {file_location}")
        res = None
        if self.sections_definitions is None:
            self.sections_definitions = self.get_sections_definitions(file_location)
        if len(self.sections_definitions) > 0:
            self.sections_definitions['user_id'] = str(user_id)
            res = load_data(self.es_client,
                            self.sections_definitions)

        return res

    def search_into_es(self, user_id, file_name, definitions, sections):
        response = search_es(self.es_client, user_id, file_name, definitions, sections)

        return response

    @staticmethod
    def vector_db_exist(persist_directory_: str) -> bool:
        """
        Checks if vector store exists
        """
        logger.info("Checking if vector store exists")
        if os.path.exists(os.path.join(persist_directory_, 'index')):
            if os.path.exists(os.path.join(persist_directory_, 'chroma-collections.parquet')) and os.path.exists(
                    os.path.join(persist_directory_, 'chroma-embeddings.parquet')):
                list_index_files = glob.glob(os.path.join(persist_directory_, 'index/*.bin'))
                list_index_files += glob.glob(os.path.join(persist_directory_, 'index/*.pkl'))
                if len(list_index_files) > 3:
                    logger.info("vector store exists")
                    return True

        logger.info("vector store not exists")
        return False

    def process_sections_definitions(self, file_location):
        if self.sections_definitions is None:
            self.sections_definitions = self.get_sections_definitions(file_location)
        if self.sections_definitions is not None:
            documents = []
            file_name = self.sections_definitions['file_name']

            for k in ('definitions', 'sections'):
                for s in self.sections_definitions[k]:
                    metadata = {'source': file_name}
                    if k=='definitions':
                        text = ' '.join([s['definition_term'], s['definition_text']])
                        documents.extend([Document(page_content=text, metadata = metadata)])
                    elif k=='sections':
                        text = ' '.join([s['section_term'], s['section_text']])
                        documents.extend([Document(page_content=text, metadata = metadata)])

            if not documents:
                logger.info("No sections_definitions to load")
                return None
            
            text_splitter = RecursiveCharacterTextSplitter(chunk_size=chunk_size, chunk_overlap=chunk_overlap,
                                                        separators=['.'])

            logger.info("Splitting the documents!")
            texts = text_splitter.split_documents(documents)
            logger.info(f"Split into {len(texts)} chunks of text (max. {chunk_size} characters each)")
            return texts
        
        return None
    
    @staticmethod
    def process_documents(ignored_files=None, _source_dir=None):
        """
        Load documents and split in chunks
        """
        if ignored_files is None:
            ignored_files = []
        if _source_dir is None:
            _source_dir = source_directory
        logger.info(f"Loading documents from {_source_dir}")
        documents = load_documents(_source_dir, ignored_files)
        if not documents:
            logger.info("No new documents to load")
            return None
        logger.info(f"Loaded {len(documents)} documents from {_source_dir}")
        text_splitter = RecursiveCharacterTextSplitter(chunk_size=chunk_size, chunk_overlap=chunk_overlap,
                                                       separators=['.'])
        # text_splitter = SemanticChunker(embeddings)

        logger.info("Splitting the documents!")
        texts = text_splitter.split_documents(documents)
        logger.info(f"Split into {len(texts)} chunks of text (max. {chunk_size} characters each)")
        return texts

    @staticmethod
    def user_based_source_s3_directory(user_id_):
        _dir_loc = {"s3_loc": documents_s3_loc, "source_dir": source_directory}

        if user_id_ is not None:
            if not os.path.exists(os.path.join(source_directory, user_id_)):
                os.mkdir(os.path.join(source_directory, user_id_))
            _dir_loc = {
                "s3_loc": documents_s3_loc + user_id_ + "/",
                "source_dir": os.path.join(source_directory, user_id_)
            }
        logger.info("document location s3 --> source document")
        logger.info(_dir_loc)
        return _dir_loc


    def ingest_into_both_dbs(self, user_id, file_location, contents):
        """
        This method is to ingest into vector db & Keyworddb with new document
        """
        logger.info(f"ingest_into_both_dbs user_id:{user_id}, file:{file_location}")
        try:
            file_location = self.save_the_file(user_id, file_location, contents)

            es_flag = False
            vector_db_ingested = False

            if file_location is not None:
                es_res = self.index_into_es(user_id, file_location)
                if es_res and '_shards' in es_res and 'failed' in es_res['_shards']:
                    es_flag = es_res['_shards']['failed'] == 0
                else:
                    logger.info(f"failed to index in ElasticSearch: {es_res}")
                    return False

                vector_db_ingested =  self.op_ingest_data_to_vector_db(user_id, file_location)
                    
            return vector_db_ingested and es_flag

        except Exception as e:
            logger.error(f"Error in ingest_into_both_dbs: {str(e)}")

        return False


    def refresh_vector_db(self, user_id=None):
        """
        This is method to create vector db with new documents
        """
        dir_loc = self.user_based_source_s3_directory(user_id)
        if s3_file_manager.get_filesFromS3Bucket(dir_loc['s3_loc'], dir_loc['source_dir']):
            return self.op_ingest_data_to_vector_db(user_id)
        else:
            logger.info('Failed to copy S3 files to source directory!!!')
        return False


    def get_document_embeddings_list(self):
        document_list = set()
        document_names = self.op_get_vector_db_metadata()
        for document in document_names:
            file_name = document.split('/')[-1]
            if file_name != "sample_mount.txt":
                document_list.add(file_name)
        return list(document_list)


    def delete_es_index(self):
        logger.info("About to delete the keywordDB")
        self.sections_definitions = None

        if self.es_client and check_and_delete_index_es(self.es_client):
            return True
        
        return False

    def delete_all_embeddings(self):
        try:
            logger.info(f"Deleting index and directories: {persist_directory}, {source_directory}")

            # Delete and recreate directories
            common_functions.delete_dir_if_exist(persist_directory)
            common_functions.delete_dir_if_exist(source_directory)
            common_functions.create_dir_if_not_exist(persist_directory)
            common_functions.create_dir_if_not_exist(source_directory)

            # Create a sample file in the source directory
            sample_file_path = os.path.join(source_directory, "sample_mount.txt")
            with open(sample_file_path, "w") as file:
                file.write("dummy text")

            logger.info(f"Successfully deleted index and directories, and created a sample file: {sample_file_path}")

            # Ingest data to the vector database
            return self.ingest_data_to_vector_db()

        except Exception as e:
            logger.error(f"Error in delete_all_embeddings: {str(e)}")

        # Return False for any errors
        return False

    @measure_time(show_timedelta=True, show_start_end=False)
    def op_multi_process_ingest(self, i_user_id, file_location):
        cuda_memory_info()

        try :
            """Update and store locally vector store"""
            # logger.info(f"Appending to existing vector store at {i_persist_directory}")
            db = OpenSearchVectorSearch(
                index_name=i_user_id,
                embedding_function=embeddings,
                http_auth=opensearch_credentials,
                opensearch_url=opensearch_host_url,
                use_ssl=True,
                verify_certs=True,
                ssl_show_warn=False,
                timeout=300,
                connection_class=RequestsHttpConnection
            )

            query = {
                "query": {
                    "match_all": {}
                }
            }
            initial_scroll = opensearch_client.search(index=i_user_id, body=query, _source=["metadata.source"],
                                                    scroll="2m", size=1000)

            all_documents = initial_scroll['hits']['hits']
            if not all_documents:
                logger.info("no documents found in the initial scroll")
                scroll_id = initial_scroll["_scroll_id"]

                while True:
                    page = opensearch_client.scroll(scroll_id=scroll_id, scroll="2m")

                    # error handling
                    if page.get('_shard', {}).get('failed', 0) > 0:
                        logger.error("error occurred during scrolling")
                        break

                    scroll_id = page['_scroll_id']
                    if not page['hits']['hits']:
                        logger.error("no more documents to scroll")
                        break

                    all_documents.extend(page['hits']['hits'])
                opensearch_client.clear_scroll(scroll_id=scroll_id)

            # ignore_file_lst = list(set([doc["_source"]["metadata"]["source"] for doc in all_documents]))
            # texts = self.process_documents(ignore_file_lst, _source_dir=i_source_directory)
            texts = self.process_sections_definitions(file_location)

            
            if texts:
                db.add_documents(documents=texts, bulk_size=len(texts) + 5)
            logger.info("DB persist is completed for the document")
            del db
            del initial_scroll
            del texts
            cuda_memory_info()

        except Exception as e:
            logger.error(str(e))

    @measure_time(show_timedelta=True, show_start_end=False)
    def op_ingest_data_to_vector_db(self, user_id: str = None, file_location: str = None):
        """
        refers to a process where data is sourced from a document folder and ingested into a vector database.
        This method provides functionality to extract relevant information from documents within a specified folder and store
        it in a vector database for further analysis or retrieval.
        :return: True or False
        """
        if not env.local_model:
            cuda_memory_info()
        try:
            if user_id is not None:
                _source_directory = os.path.join(env.SOURCE_DIRECTORY, user_id)
                common_functions.create_dir_if_not_exist(_source_directory)
            else:
                user_id = CLO_USER
                _source_directory = os.path.join(env.SOURCE_DIRECTORY, user_id)

            all_indices = opensearch_client.cat.indices(format='json')
            indices_list = [index['index'] for index in all_indices]

            if user_id in indices_list:
                logger.info(f"{user_id} is in indices_list")
                self.op_multi_process_ingest(i_user_id=user_id, file_location=file_location)
            else:
                """Create and store locally vector store"""
                # texts = self.process_documents(_source_dir=_source_directory)
                texts = self.process_sections_definitions(file_location)

                if texts:
                    logger.info("New Users: Creating embeddings. May take some minutes...")
                    db = OpenSearchVectorSearch.from_documents(
                        documents=texts,
                        embedding=embeddings,
                        opensearch_url=opensearch_host_url,
                        http_auth=opensearch_credentials,
                        timeout=300,
                        use_ssl=True,
                        verify_certs=True,
                        connection_class=RequestsHttpConnection,
                        index_name=user_id,
                        bulk_size=len(texts) + 5
                    )
                    logger.info("DB persist is completed for the document")
                    del db
                    del texts
            logger.info("Ingestion complete! You can now run /gpt/chat service with query")
            return True
        except Exception as ex:
            logger.error(ex)
            logger.error("Issues at op_ingest_data_to_vector_db..")
            return False

    @staticmethod
    def op_delete_document_embeddings(document_name, user_id: str):
        logger.info(f"op_delete_document_embeddings....user_id:{user_id}, document_name:{document_name}")
        try:
            query = {
                "query": {
                    "match_all": {}
                }
            }
            initial_scroll = opensearch_client.search(index=user_id, body=query, _source=["metadata.source"],
                                                      scroll="2m", size=1000)

            if not initial_scroll['hits']['hits']:
                logger.info("no documents/embeddings found in the user id")
                return None

            all_documents = initial_scroll['hits']['hits']
            scroll_id = initial_scroll["_scroll_id"]
            match_ids = []

            while True:
                page = opensearch_client.scroll(scroll_id=scroll_id, scroll="2m")

                # error handling
                if page.get('_shard', {}).get('failed', 0) > 0:
                    logger.error("error occurred during scrolling")
                    break

                scroll_id = page['_scroll_id']
                if not page['hits']['hits']:
                    logger.info("scrolling completed, no more documents have to be fetch")
                    break

                all_documents.extend(page['hits']['hits'])
            opensearch_client.clear_scroll(scroll_id=scroll_id)

            if all_documents:
                for doc in all_documents:
                    doc_path = doc["_source"]["metadata"]["source"]

                    if os.path.basename(doc_path) == document_name:
                        match_ids.append(doc["_id"])

                if match_ids:
                    logger.info("match ids founds for delete")
                    for doc_id in match_ids:
                        opensearch_client.delete(index=user_id, id=doc_id)
                    opensearch_client.indices.refresh(index=user_id)
                    return True
                else:
                    logger.info(f"no ids found for {document_name} in database")
                    return False
            else:
                logger.info(f" {document_name} not in database")
                return False
        except Exception as ex:
            logger.error(ex)

    @staticmethod
    def op_delete_all_embeddings(user_id: str = None):
        try:
            all_indices = opensearch_client.cat.indices(format='json')
            indices_list = [index['index'] for index in all_indices]

            if user_id is not None and user_id in indices_list:
                _user_source_directory = os.path.join(source_directory, user_id)
                common_functions.delete_dir_if_exist(_user_source_directory)
                common_functions.create_dir_if_not_exist(_user_source_directory)

                query = {
                    "query": {
                        "match_all": {}
                    }
                }
                response_mes = opensearch_client.delete_by_query(index=user_id, body=query)
                logger.info(response_mes)
                opensearch_client.indices.refresh(index=user_id)

                initial_scroll = opensearch_client.search(index=user_id, body=query, _source=["metadata.source"],
                                                          scroll="2m", size=1000)

                if not initial_scroll['hits']['hits']:
                    logger.info("no documents found in scrolling")
                    return True
                scroll_id = initial_scroll["_scroll_id"]

                all_documents = initial_scroll['hits']['hits']
                while True:
                    page = opensearch_client.scroll(scroll_id=scroll_id, scroll="2m")

                    # error handling
                    if page.get('_shard', {}).get('failed', 0) > 0:
                        logger.error("error occurred during scrolling")
                        break

                    scroll_id = page['_scroll_id']
                    if not page['hits']['hits']:
                        logger.error("no more documents to scroll")
                        break

                    all_documents.extend(page['hits']['hits'])
                opensearch_client.clear_scroll(scroll_id=scroll_id)

                if all_documents:
                    for doc in all_documents:
                        opensearch_client.delete(index=user_id, id=doc["_id"])
                    opensearch_client.indices.refresh(index=user_id)
                else:
                    logger.info("no documents found")
            else:
                logger.error("no user found")
            
            return True

        except Exception as ex:
            logger.error(ex)

        return False
    
    @staticmethod
    def op_get_vector_db_metadata(user_id: str = None):
        try:
            all_indices = opensearch_client.cat.indices(format='json')
            indices_list = [index['index'] for index in all_indices]
            if user_id is not None and user_id in indices_list:
                logger.info(f"User id Present in indices {user_id}")
                query = {
                    "query": {
                        "match_all": {}
                    }
                }
                initial_scroll = opensearch_client.search(index=user_id, body=query, _source=["metadata.source"],
                                                          scroll="2m", size=1000)
                if not initial_scroll['hits']['hits']:
                    logger.info("no documents found in the initial scroll")
                    return []

                all_documents = initial_scroll['hits']['hits']
                scroll_id = initial_scroll["_scroll_id"]

                while True:
                    page = opensearch_client.scroll(scroll_id=scroll_id, scroll="2m")

                    # error handling
                    if page.get('_shard', {}).get('failed', 0) > 0:
                        logger.error("error occurred during scrolling")
                        break

                    scroll_id = page['_scroll_id']
                    if not page['hits']['hits']:
                        logger.error("no more documents to scroll")
                        break

                    all_documents.extend(page['hits']['hits'])
                opensearch_client.clear_scroll(scroll_id=scroll_id)

                metadata_list = list(set([doc["_source"]["metadata"]["source"] for doc in all_documents]))
                logger.info(metadata_list)
                file_names = set()
                for metadata in metadata_list:
                    filename = metadata.split('\\')[-1]
                    file_names.add(filename)
                return file_names
            else:
                logger.info("User id not Present Or New user... ")
        except Exception as ex:
            logger.error(ex)

        return []

    def op_get_document_embeddings_list(self, user_id: str = None):
        try:
            document_list = set()
            document_names = self.op_get_vector_db_metadata(user_id)
            for document in document_names:
                file_name = document.split('/')[-1]
                if file_name != "sample_mount.txt":
                    document_list.add(file_name)
            return list(document_list)
        except Exception as ex:
            logger.error(ex)



if __name__ == '__main__':
    logger.info("This is main call for this module, used for Unittest/Dry Run")
    ingestionObj = DBIngestion()
    logger.info(ingestionObj.status)
