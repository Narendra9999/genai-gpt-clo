## Private GPT Setup in Local

- Python 3.11
- install requirements.txt packages

### How to run service in local 
 - `python3 -m gunicorn --bind 0.0.0.0:8080 app:app`
 - `python3 -m gunicorn --bind 0.0.0.0:8080 app:app --timeout 240`
 

### Coding Standards
- PEP 8 (Python Enhancement Proposal 8) is the official style guide 


### Reference kratos information 
- https://spglobal.visualstudio.com/ratingsproducts/_git/kratos-helm-chart?path=/chart/templates/service.yaml&version=GBdevelop&_a=contents