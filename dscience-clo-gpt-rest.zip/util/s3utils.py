import boto3
from botocore.config import Config
from botocore.exceptions import ClientError
import os
from util import env, logger
from pathlib import Path
from sys import platform


logging = logger.getlogger()
s3_file_ignored_list = [".git", ".gitattributes"]

def uploadSingleFiletoS3(s3_client, bucket, cloud_dir, local_file):
    try:
        remote_directory = cloud_dir
        base_file = os.path.basename(local_file)
        object_name = f"{remote_directory}/{base_file}"
        if platform.startswith('win'):
            object_name = object_name.replace("\\", "/")

        logging.info(f"local file :{local_file}")
        logging.info(f"remote file:{object_name}")
        ret = s3_client.upload_file(local_file, bucket, object_name)
        if ret is not None:
            logging.error(ret)
        return True
    except Exception as e:
        logging.error(e)
        return False

def uploadFilesToS3(s3_client, bucket, cloud_dir, local_dir, ignored_list=s3_file_ignored_list):
    """ cloud_dir is excluding the target directory name
        local_dir can be a single file """

    failed = 0
    num_files = 0
    # if we are uploading the entire directory, then use that as the target name
    if Path(local_dir).is_dir():
        remote_directory = os.path.join(cloud_dir, os.path.basename(local_dir))
        # remote_directory = f"{cloud_dir}/{os.path.basename(local_dir)}"
        print(f"File(s) will be uploaded to {remote_directory}")
        directory_list = [local_dir]
        while len(directory_list) > 0:
            current_dir = directory_list.pop(0)
            filepath = Path(current_dir)

            for path in filepath.iterdir():
                partial_path = path.relative_to(local_dir)
                # print(f"....looking at {partial_path}")
                if os.path.basename(path) in ignored_list:
                    logging.info("----SKIP:", path)
                    continue
                elif path.is_dir():
                    directory_list.append(path)
                elif path.is_file():
                    object_name = f"{remote_directory}/{partial_path}"
                    if uploadSingleFiletoS3(s3_client, bucket, object_name, str(path)):
                        num_files += 1
                    else:
                        failed += 1
    else:
        if uploadSingleFiletoS3(s3_client, bucket, cloud_dir, local_dir):
            num_files += 1
        else:
            failed += 1

    logging.info(f"Upload completed for {num_files} file(s). Failed:{failed}")
    return failed == 0

class S3FileManager:
    def __init__(self, bucket_name):
        if env.local_model:
            try:
                session = boto3.Session(profile_name="ADFS-MHF-IdfDScience")
                self.s3_client = session.client('s3')
                print("local s3 client:", self.s3_client)
            except Exception as e:
                print(e)
                print("No local s3 client")
                self.s3_client = None
        else:
            self.s3_client = boto3.client('s3')
        self.bucket_name = bucket_name

    def uploadSingleFiletoS3(self, cloud_dir, local_file):
        return uploadSingleFiletoS3(self.s3_client, self.bucket_name, cloud_dir, local_file)

    def uploadFilesToS3(self, cloud_dir, local_dir):
        return uploadFilesToS3(self.s3_client, self.bucket_name, cloud_dir, local_dir)

    def get_fileFromS3Bucket(self, cloud_file_loc, cloud_file_name, download_location, delete_from_pod=False):
        logging.info("In get_fileFromS3Bucket")
        cloud_file_path = os.path.join(cloud_file_loc, cloud_file_name)

        try:
            logging.info("CloudFilePath ::::" + cloud_file_path)
            logging.info("CloudFileLocation ::::" + cloud_file_loc)
            logging.info("CloudFileName ::::" + cloud_file_name)
            logging.info("DownloadLocation ::::" + download_location)

            download_file_path = os.path.join(download_location, cloud_file_name)

            logging.info("Download full path ::::" + download_file_path)

            if delete_from_pod and os.path.exists(download_file_path):
                os.remove(download_file_path)

            if os.path.exists(download_file_path):
                logging.info(f"File Already exists at {download_file_path} ")
                return True
            else:
                logging.info(f"Downloading file from S3={cloud_file_path}")
                try:
                    self.s3_client.download_file(self.bucket_name, cloud_file_path, download_file_path)
                    logging.info(f"File fetched from S3={cloud_file_path}")
                    return True
                except Exception as e:
                    logging.info(f"Error in downloading. Error Description={e}")
                    raise Exception(f"Error in downloading. Error Description={e}")

        except Exception as e:
            logging.error('Error occured while Fetching file from S3', str(e))
            return False

    def get_filesFromS3Bucket(self, cloud_files_loc, download_files_loc=''):
        logging.info("In get_filesFromS3Bucket")
        logging.info(f"Downloading files from {cloud_files_loc} location to {download_files_loc}.")

        try:
            # List objects in the S3 bucket
            response = self.s3_client.list_objects_v2(Bucket=self.bucket_name, Prefix=cloud_files_loc)
            # Iterate over each object in the bucket
            for obj in response['Contents']:
                # Get the object key
                object_key = obj['Key']
                file_name = os.path.basename(object_key)
                if not file_name.startswith('.'):
                    download_file_path = os.path.join(download_files_loc, file_name)

                    if os.path.exists(download_file_path):
                        logging.info(f"{file_name} already exists at {download_file_path} ")
                    else:
                        logging.info(f"Downloading file {file_name}")
                        try:
                            self.s3_client.download_file(self.bucket_name, object_key, download_file_path)
                        except Exception as e:
                            e_msg = f"Error in downloading {file_name}. Error Description={e}"
                            logging.info(e_msg)
                            raise Exception(e_msg)

            return True

        except Exception as e:
            logging.error('Error occurred while Fetching file from S3', str(e))

        return False

