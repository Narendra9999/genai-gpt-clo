import os

# Fetch Environment Variables


db_user = os.environ.get('DB_USER')
db_password = os.environ.get('DB_PASSWORD')
db_service_name = os.environ.get('DB_SERVICE_NAME')
db_hostname = os.environ.get('DB_HOSTNAME')
db_port = os.environ.get('DB_PORT')
max_connection = os.environ.get('MAX_CONNECTION')
min_connection = os.environ.get('MIN_CONNECTION')
connection_increment = os.environ.get('CONNECTION_INCREMENT')
spr_app_secret_hc_vault_token = os.environ.get('SPR_APP_SECRET_HC_VAULT_TOKEN')
spr_app_secret_hc_vault_base_url = os.environ.get('SPR_APP_SECRET_HC_VAULT_BASE_URL')
spr_shelf_id = os.environ.get('SPR_SHELF_ID')
debug_level = os.environ.get('DEBUG_LEVEL', 'DEBUG')
