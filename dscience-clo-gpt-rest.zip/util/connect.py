import requests

from util import logger

logger = logger.getlogger()


def getpassword(key_name, spr_app_secret_hc_vault_base_url, spr_shelf_id, spr_app_secret_hc_vault_token) -> str:
    base_url = spr_app_secret_hc_vault_base_url + "/" + spr_shelf_id
    logger.debug('spr_app_secret_hc_vault_token' + spr_app_secret_hc_vault_token)
    logger.debug(base_url)
    params = {'secret-keys': key_name}
    headers = {"spr-sm-token": spr_app_secret_hc_vault_token}
    response = requests.get(base_url, headers=headers, params=params)
    data = response.json()
    secret_val = data['data'][key_name]
    return secret_val
