import subprocess
import sys
from ast import literal_eval
import os
import torch
from rootdir import ROOT_DIR
import logging as logger

from util.document_sample.state_of_the_union import txt_message
from util.common_functions import create_dir_if_not_exist, delete_dir_if_exist
from opensearchpy import OpenSearch
from util.secretutil import get_secret
from util.mongo_connecter import MongoHandler


# Set environment variables
os.environ['LLAMA_CUBLAS'] = '1'
# os.environ["PYTORCH_CUDA_ALLOC_CONF"] = "max_split_size_mb:1024"
# os.environ['OPENBLAS_NUM_THREADS'] = '1'
# based on blog : https://clearlinux.org/blogs-news/improving-python-numpy-performance-kubernetes-using-clear-linux-os
# os.environ['OMP_NUM_THREADS'] = '10'
# os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'

# Logging CUDA status
CUDA_STATUS = torch.cuda.is_available()
logger.info(f"CUDA STATUS: {CUDA_STATUS}")

if CUDA_STATUS:
    CUDA_DEVICE_COUNT = torch.cuda.device_count()
    logger.info(f"Available CUDA device count: {CUDA_DEVICE_COUNT}")
    logger.info(os.system("nvidia-smi"))
    torch.zeros(1).cuda()
    subprocess.check_call([sys.executable, "-m", "pip", "install", "pysqlite3-binary"])
    __import__("pysqlite3")
    sys.modules["sqlite3"] = sys.modules.pop("pysqlite3")
    logger.info("System configured with SQLite3")


# Mount directory
MOUNT_DIR = os.environ.get("MOUNT_PATH", ROOT_DIR)
create_dir_if_not_exist(MOUNT_DIR)

# Environment variables
SPR_VAULT_ENV = os.environ.get("SPR_VAULT_ENV", "dev")
local_model = literal_eval(str(os.environ.get("MODEL_LOCAL", True)).lower().capitalize())
model_download_s3 = literal_eval(str(os.environ.get("MODEL_DOWNLOAD_S3", False)).lower().capitalize())
MODEL_DIR_LOC = os.environ.get("MODEL_DOWNLOAD_FILE_LOC", os.path.join(MOUNT_DIR, "models"))
EMBEDDINGS_MODEL_DIR = os.path.join(MODEL_DIR_LOC, "embedding_model")
SOURCE_DIRECTORY = os.path.join(MOUNT_DIR, "source_documents")
PERSIST_DIRECTORY = os.path.join(MOUNT_DIR, "db")
global_s3_bucket_name = os.environ.get("global_s3_bucket_name", "spr-idf-dev-platform-dscience")
model_s3_file_loc = os.environ.get("model_s3_loc", "data/machinelearning/private_gpt/models/v1/")
documents_s3_loc = os.environ.get("documents_s3_loc", "data/machinelearning/private_gpt/uploads/")

DELETE_MOUNT_DB = literal_eval(str(os.environ.get("DELETE_MOUNT_DB", False)).lower().capitalize())
logger.info(f"DELETE_MOUNT_DB Marked: {DELETE_MOUNT_DB}")

delete_dir_if_exist(MODEL_DIR_LOC)  # Deleting older model temp files
create_dir_if_not_exist(MODEL_DIR_LOC)  # Ensuring model (LLM, embedding) location files exist
os.environ["HF_HOME"] = MODEL_DIR_LOC


if DELETE_MOUNT_DB:
    logger.info(f"DELETE_MOUNT_DB Marked: {DELETE_MOUNT_DB}, removing existing memory/source documents")
    delete_dir_if_exist(PERSIST_DIRECTORY)
    delete_dir_if_exist(SOURCE_DIRECTORY)
else:
    logger.info("Persisting the existing DB memory...")

create_dir_if_not_exist(PERSIST_DIRECTORY)
create_dir_if_not_exist(SOURCE_DIRECTORY)
with open(os.path.join(SOURCE_DIRECTORY, "sample_mount.txt"), "w") as file:
    file.write(txt_message)

# Model configuration
MODEL_TYPE = os.environ.get("MODEL_TYPE", "llama3")
MODEL_NAME = os.environ.get("MODEL_NAME", "llama-3-8B-Instruct.Q8_0.gguf")
EMBEDDINGS_MODEL_NAME = os.environ.get("EMBEDDINGS_MODEL_NAME", "BAAI/bge-large-en-v1.5")
RERANKER_MODEL_NAME = os.environ.get("RERANKER_MODEL_NAME", "BAAI/bge-reranker-large")
MODEL_FILE_PATH = os.path.join(MODEL_DIR_LOC, MODEL_NAME)
MODEL_N_CTX = literal_eval(str(os.environ.get("MODEL_N_CTX", 4096)))
MAX_TOKEN = literal_eval(str(os.environ.get("MAX_TOKEN", 512)))
MODEL_N_BATCH = literal_eval(str(os.environ.get("MODEL_N_BATCH", 512)))
MODEL_N_THREADS = literal_eval(str(os.environ.get("MODEL_N_THREADS", 16)))
TARGET_SOURCE_CHUNKS = literal_eval(str(os.environ.get("TARGET_SOURCE_CHUNKS", 10)))
CHUNK_SIZE = literal_eval(str(os.environ.get("CHUNK_SIZE", 1024)))
CHUNK_OVERLAP = literal_eval(str(os.environ.get("CHUNK_OVERLAP", 100)))
TOP_K_RERANK_CHUNKS = literal_eval(str(os.environ.get("TOP_K_RERANK_CHUNKS", 4)))
CHROMADB = literal_eval(str(os.environ.get("CHROMADB", False)).lower().capitalize())
CLO_USER = os.environ.get("DEFAULT_CLO_USER", "clo-local")
DEPLOYMENT_ENV = os.environ.get("DEPLOYMENT_ENV", "dev")
RUN_BATCH_JOB = literal_eval(str(os.environ.get("RUN_BATCH_JOB", False)).lower().capitalize())
OPENSEARCH_DB = literal_eval(str(os.environ.get("OPENSEARCH_DB", True)).lower().capitalize())
OPENSEARCH_AUTH_USER = os.environ.get("OPENSEARCH_AUTH_USER", "YCrG6yNg20rLB6Dn")
OPENSEARCH_AUTH_PW = os.environ.get("OPENSEARCH_AUTH_PW", "opensearch_non_prod_pw")
OPENSEARCH_HOST = os.environ.get("OPENSEARCH_HOST", "dscience-chatgpt-int-os.dev.spratingsvpc.com")
MONGODB_USER = os.environ.get("MONGODB_USER", "dsciencegenai_user")
MONGODB_PW = os.environ.get("MONGODB_PW", "mongo_db_non_prod_pw")
MONGODB_HOST = os.environ.get("MONGODB_HOST", "mongo-dev-1-clu1.dev.spratingsvpc.com:27060")
MONGODB_NAME = os.environ.get("MONGODB_NAME", "dsciencegenai")

if not CHROMADB:
    opensearch_credentials = (OPENSEARCH_AUTH_USER, get_secret(OPENSEARCH_AUTH_PW))
    opensearch_host_url = "https://" + OPENSEARCH_HOST
    try:
        opensearch_client = OpenSearch(hosts=[{"host": OPENSEARCH_HOST, "port": 443}],
                                       http_auth=opensearch_credentials,
                                       use_ssl=True,
                                       verify_certs=False,
                                       ssl_assert_hostname=False,
                                       ssl_show_warn=False, )
        logger.info(f"Connected to OPEN SEARCH .... {OPENSEARCH_HOST}")
    except Exception as ex:
        logger.error(ex)


logger.info("MongoDB Credentials:")
logger.info(f"User: {MONGODB_USER}")
logger.info(f"Password: {MONGODB_PW}")
logger.info(f"Host: {MONGODB_HOST}")
logger.info(f"Database: {MONGODB_NAME}")

mongo_con = MongoHandler(mongo_db_user=MONGODB_USER,
                         mongo_db_pw=get_secret(MONGODB_PW),
                         mongo_db_host=MONGODB_HOST,
                         mongo_db_name=MONGODB_NAME)

# Log configuration details
logger.info(f"SPR_VAULT_ENV: {SPR_VAULT_ENV}")
logger.info(f"local_model: {local_model}")
logger.info(f"model_download_s3: {model_download_s3}")
logger.info(f"documents_s3_loc: {documents_s3_loc}")
logger.info(f"MODEL_NAME: {MODEL_NAME}")
logger.info(f"MODEL_FOLDER: {MODEL_DIR_LOC}")
logger.info(f"MODEL_FILE_PATH: {MODEL_FILE_PATH}")
logger.info(f"global_s3_bucket_name: {global_s3_bucket_name}")
logger.info(f"model_s3_file_loc: {model_s3_file_loc}")
logger.info(f"SOURCE_DIRECTORY: {SOURCE_DIRECTORY}")
logger.info(f"PERSIST_DIRECTORY: {PERSIST_DIRECTORY}")
logger.info(f"MODEL_TYPE: {MODEL_TYPE}")
logger.info(f"EMBEDDINGS_MODEL_NAME: {EMBEDDINGS_MODEL_NAME}")
logger.info(f"RERANKER_MODEL_NAME: {RERANKER_MODEL_NAME}")
logger.info(f"EMBEDDINGS_MODEL_DIR: {EMBEDDINGS_MODEL_DIR}")
logger.info(f"MODEL_DIR_LOC: {MODEL_DIR_LOC}")
logger.info(f"MODEL_N_CTX: {MODEL_N_CTX}")
logger.info(f"MAX_TOKEN: {MAX_TOKEN}")
logger.info(f"MODEL_N_BATCH: {MODEL_N_BATCH}")
logger.info(f"MODEL_N_THREADS: {MODEL_N_THREADS}")
logger.info(f"TARGET_SOURCE_CHUNKS: {TARGET_SOURCE_CHUNKS}")
logger.info(f"chunk_size: {CHUNK_SIZE}")
logger.info(f"chunk_overlap: {CHUNK_OVERLAP}")
logger.info(f"CHROMADB: {CHROMADB}")
logger.info(f"CLO_USER: {CLO_USER}")
logger.info(f"DEPLOYMENT_ENV: {DEPLOYMENT_ENV}")
logger.info(f"RUN_BATCH_JOB: {RUN_BATCH_JOB}")
logger.info(f"TOP_K_RERANK_CHUNKS: {TOP_K_RERANK_CHUNKS}")