from docx import Document
import re
import os
from functools import reduce
import operator
import requests
import json

from util import logger
from util.interested_sections_definitions import section_definitions
from util.extraction_module.emea_extraction_utils import extract_emea_docx_clo_sections_definitions
from util.extraction_module.us_extraction_utils import extract_us_docx_clo_sections_definitions

logger = logger.getlogger()


def get_by_path(root: dict, items: list):
    """
    Access a nested object in root by item sequence.

    :param root: root dictionary
    :param items: list of dict keys
    :return dictionary path output
    """
    try:
        return reduce(operator.getitem, items, root)
    except KeyError:
        def _recurse(dic: dict, chain: list[str]):
            if len(chain) == 0:
                return
            if len(chain) == 1:
                dic[chain[0]] = {}
                return
            key, *new_chain = chain
            if key not in dic:
                dic[key] = {}
            _recurse(dic[key], new_chain)
            return

        _recurse(root, items)

        return reduce(operator.getitem, items, root)


def set_by_path(root: dict, items: list, value):
    """
    Set a value in a nested object in root by item sequence.

    :param root: root dictionary
    :param items: list of dict keys
    :param value: value to be set in path
    :return dictionary with path added
    """
    get_by_path(root, items[:-1])[items[-1]] = value


def replace_whitespace_and_strip(string, replacement=" "):
    """
    Replace whitespace in string with replacement text and strip trailing/preceding whitespace

    :param string: string for whitespace to be replaced
    :param replacement: string whitespace replacement text
    :return stripped string with whitespace replaced
    """
    # Replace all runs of whitespace with a single dash
    string = re.sub(r"[\s\n\xa0]+", replacement, string)

    # Replace all runs of whitespace with a single dash
    string = re.sub(r"\s+", replacement, string)

    return string.strip()


def create_lower_level_terms_conditions_sections(sections_dictionary: dict) -> dict:
    """
    Take sections dictionary and output terms and conditions section dictionary with subsections nested

    :param sections_dictionary: sections dictionary
    :return output_dict: terms and conditions section with subsections nested in dictionary
    """

    output_dict = {}

    # So far only the terms and conditions sections in all emea docs have the string 'terms and conditions' within it
    terms_conditions_keys = [key for key in sections_dictionary["Sections_Data"].keys() if
                             "terms and conditions" in key.lower()]

    if len(terms_conditions_keys) != 1:
        raise (
            ValueError(
                "terms_conditions_keys must find 1 singular key for lower level data extraction of conditions"))
    else:
        terms_conditions_dict = sections_dictionary["Sections_Data"][terms_conditions_keys[0]]
        for terms_condition_section in list(terms_conditions_dict):
            if terms_condition_section not in ['Text', 'Text_Left_Indent', 'Raw_Text_Definitions',
                                               'Edited_Text_Definitions']:
                indentation_levels = []
                sections_path = []
                for idx, line in enumerate(
                        zip(
                            terms_conditions_dict[terms_condition_section]["Text"],
                            terms_conditions_dict[terms_condition_section]["Text_Left_Indent"]
                        )
                ):
                    if idx == 0:
                        # Extract only the numeric value of the top level section for easier indexing of conditions
                        sections_path = [re.findall("^[0-9]+", replace_whitespace_and_strip(line[0]))[0]]
                        indentation_levels = [line[1]]
                    else:
                        # Find parenthesis enclosed or numeric start of lines to pull sub section keys
                        sub_section_keys = re.findall(r"(?:^\([^\)]*\)|^[0-9]\.)", line[0].strip())
                        if len(sub_section_keys) > 0:
                            sub_section_value = line[0].strip().split(sub_section_keys[0])[1].strip()
                            try:
                                index_of_section_indent = indentation_levels.index(line[1])
                                indentation_levels = indentation_levels[:index_of_section_indent + 1]
                                sections_path = sections_path[:index_of_section_indent] + [sub_section_keys[0]]
                            # If indent does not exist in indentation levels
                            except ValueError:
                                # If indent is None that simply add to current indent levels values
                                if line[1] is None:
                                    sub_section_value = line[0]
                                else:
                                    # If indent is not None then add indent to indent levels and add section key to path
                                    indentation_levels.append(line[1])
                                    sections_path.append(sub_section_keys[0])
                        else:
                            # if no subsection keys in line text
                            try:
                                index_of_section_indent = indentation_levels.index(line[1])
                                indentation_levels = indentation_levels[:index_of_section_indent + 1]
                                sections_path = sections_path[:index_of_section_indent + 1]
                                sub_section_value = line[0]
                            # If indent does not exist in indentation levels
                            except ValueError:
                                # If indent is None that simply add to current indent levels values
                                if line[1] is None:
                                    sub_section_value = line[0]
                                else:
                                    # If indent is not None then this is a bullet value
                                    indentation_levels.append(line[1])
                                    sections_path.append('Bullets')
                                    sub_section_value = line[0]

                        # If subsection path exists add text to the current subsection text list
                        if get_by_path(
                                root=output_dict,
                                items=[terms_conditions_keys[0]] + sections_path + ['Text']
                        ) != {}:
                            current_value_text = get_by_path(
                                root=output_dict,
                                items=[terms_conditions_keys[0]] + sections_path + ['Text']
                            )
                            set_by_path(
                                root=output_dict,
                                items=[terms_conditions_keys[0]] + sections_path + ['Text'],
                                value=current_value_text + [sub_section_value]
                            )
                        else:
                            # If subsection path doesn't exist, create subsection and set text to list
                            set_by_path(
                                root=output_dict,
                                items=[terms_conditions_keys[0]] + sections_path + ['Text'],
                                value=[sub_section_value])

    return output_dict


def create_lower_level_sections(sections_dictionary: dict) -> dict:
    """
    Take sections dictionary and output sections dictionary with subsections nested

    :param sections_dictionary: sections dictionary
    :return output_dict: sections dictionary with subsections nested in dictionary
    """

    output_dict = {}

    sections_dictionary_section_data = sections_dictionary["Sections_Data"]
    for section_data_section in list(sections_dictionary_section_data):
        if (
                section_data_section not in ['Text',
                                             'Text_Left_Indent',
                                             'Raw_Text_Definitions',
                                             'Edited_Text_Definitions']
                and
                re.findall(
                    '(:?^[0-9]+\.[0-9]+|^Section\s[0-9]+\.[0-9]+)',
                    section_data_section
                )
        ):
            indentation_levels = []
            sections_path = []
            for idx, line in enumerate(
                    zip(
                        sections_dictionary_section_data[section_data_section]["Text"],
                        sections_dictionary_section_data[section_data_section]["Text_Left_Indent"]
                    )
            ):
                if idx == 0:
                    # Extract the top level section for easier indexing in future
                    sections_path = [re.findall(
                        '(:?^[0-9]+\.[0-9]+|^Section\s[0-9]+\.[0-9]+)',
                        replace_whitespace_and_strip(line[0]
                                                     )
                    )[0]]
                    if re.findall('^[0-9]+\.[0-9]$', sections_path[0]):
                        sections_path[0] = "Section " + sections_path[0]
                    indentation_levels = [line[1]]
                else:
                    # Find parenthesis enclosed or numeric start of lines to pull sub section keys
                    sub_section_keys = re.findall(r"(?:^\([^\)]*\)|^[0-9]\.)", line[0].strip())
                    if len(sub_section_keys) > 0:
                        sub_section_value = line[0].strip().split(sub_section_keys[0])[1].strip()
                        # If indent is None that simply add to current indent levels values
                        if line[1] is None:
                            sub_section_value = line[0]
                        else:
                            try:
                                index_of_section_indent = indentation_levels.index(line[1])
                                indentation_levels = indentation_levels[:index_of_section_indent + 1]
                                sections_path = sections_path[:index_of_section_indent] + [sub_section_keys[0]]
                            # If indent does not exist in indentation levels
                            except ValueError:
                                # add indent to indent levels and add section key to path
                                indentation_levels.append(line[1])
                                sections_path.append(sub_section_keys[0])
                                if sections_path == ["(III)"]:
                                    logger.error("sections_path")
                    else:
                        # if no subsection keys in line text
                        try:
                            index_of_section_indent = indentation_levels.index(line[1])
                            indentation_levels = indentation_levels[:index_of_section_indent + 1]
                            sections_path = sections_path[:index_of_section_indent + 1]
                            sub_section_value = line[0]
                        # If indent does not exist in indentation levels
                        except ValueError:
                            # If indent is None that simply add to current indent levels values
                            if line[1] is None:
                                sub_section_value = line[0]
                            else:
                                # If indent is not None then this is a bullet value
                                indentation_levels.append(line[1])
                                sections_path.append('Bullets')
                                sub_section_value = line[0]
                    # If subsection path exists add text to the current subsection text list
                    if get_by_path(
                            root=output_dict,
                            items=['Section_Data'] + sections_path + ['Text']
                    ) != {}:
                        current_value_text = get_by_path(
                            root=output_dict,
                            items=['Section_Data'] + sections_path + ['Text']
                        )
                        set_by_path(
                            root=output_dict,
                            items=['Section_Data'] + sections_path + ['Text'],
                            value=current_value_text + [sub_section_value]
                        )
                    else:
                        # If subsection path doesn't exist, create subsection and set text to list
                        set_by_path(
                            root=output_dict,
                            items=['Section_Data'] + sections_path + ['Text'],
                            value=[sub_section_value])

    return output_dict


def is_substring_in_section_definitions(given_string, string_set):
    # Check if any substring in string_set matches the given string
    for substring in string_set:
        # Check if the substring is present in the given string
        if substring in given_string or given_string in substring:
            return substring.lstrip('1234567890 ')
    return ''


class DefinitionExtractor:
    def __init__(self, word_doc_filepath):
        self.word_doc_filepath = word_doc_filepath
        self.file_name = os.path.basename(word_doc_filepath)
        self.which_region_file = self.check_which_region_file()

    def check_which_region_file(self):
        first_9_chars = self.file_name[:9]

        # First 9 characters are 8 number characters followed by an underscore for EMEA docs
        if re.match(r'^\d+_.*', first_9_chars):
            return 'emea'

        return 'us'

    def rename_key(self, dictionary, old_key, new_key):
        """
        Renames a key in a dictionary.

        Args:
            dictionary: The dictionary to modify.
            old_key: The key to rename.
            new_key: The new name for the key.
        """
        if old_key in dictionary:
            dictionary[new_key] = dictionary.pop(old_key)
        else:
            logger.info(f"Key '{old_key}' not found in the dictionary.")
        
        return dictionary
    
    def extract_clo_data_using_api(self):
        api_endpoint = 'https://genaiclo-wordextraction-rest.api.dev.spratingsvpc.com/clo_docx_text_extract/' + str(self.which_region_file)
        headers = {
            'accept': 'application/json'
                }

        logger.info(f"Extracting {self.word_doc_filepath} from {api_endpoint}")
        with open(self.word_doc_filepath, 'rb') as file:
            files = {'clo_region': self.which_region_file, 'word_docx_file': (self.file_name, file)}
            response = requests.post(api_endpoint, headers=headers, files=files)
            logger.info(f"response.status_code: {response.status_code}")

            if response.status_code==200:
                response_dict = json.loads(response.text)
                if 'parsed_text' in response_dict:
                    result_dict = self.rename_key(response_dict['parsed_text'], 'File_Name', 'file_name')
                    return result_dict

        return None

    def extract_clo_data(self):
        if self.which_region_file == 'emea':
            # return self.extract_EMEA_docx_clo_sections_definitions()
            return extract_emea_docx_clo_sections_definitions(self.word_doc_filepath)
        else:
            # return self.extract_US_docx_clo_sections_definitions()
            return extract_us_docx_clo_sections_definitions(self.word_doc_filepath)

    def process_json(self, data, result_dict=None, parent_key=None):
        if result_dict is None:
            result_dict = {}

        for key, value in data.items():
            current_key = key

            if key == 'Text':
                result_dict[parent_key] = value
            elif key == 'Edited_Text_Definitions' and isinstance(value, dict) and value:
                result_dict.update(value)
            elif isinstance(value, dict):
                self.process_json(value, result_dict, current_key)

        return result_dict
    
    def get_definitions(self, sections_dictionary, definition_data=None, section_data = None):
        if definition_data is None:
            definition_data = []

        if section_data is None:
            section_data = []

        for k, v in sections_dictionary.items():
            if isinstance(v, dict):
                # section_definition = is_substring_in_section_definitions(k, section_definitions)
                # if "Text" in v and section_definition:
                #     section_data.append({'section_term': section_definition, 'section_text': "  ".join(v["Text"]).strip(' \n')})
                if "Text" in v:
                    section_data.append({'section_term': k.lstrip('.1234567890 '), 'section_text': "  ".join(v["Text"]).strip(' \n')})
                
                if k == 'Edited_Text_Definitions':
                    for k2, v2 in v.items():
                        if isinstance(v2, list):
                            definition_data.append({'definition_term': k2.lstrip('1234567890 '), 'definition_text': "\n".join(v2)})
                else:
                    self.get_definitions(v, definition_data, section_data)

        return definition_data, section_data

    def extract_just_definitions(self, sections_dictionary):
        sample_data = {'file_name': sections_dictionary['file_name']}
        definition_data, section_data = self.get_definitions(sections_dictionary)
        sample_data['definitions'] = definition_data
        sample_data['sections'] = section_data

        return sample_data if len(definition_data) > 0 or len(section_data) > 0 else {}

    def create_single_edited_definition_value(
            self,
            lower_level_sections: dict,
            definition_value: list,
            previously_referenced_sections_string_list: list = []
    ) -> list:
        """
            Create edited definition value where referenced sections are added

            :param lower_level_sections: sections dictionary with subsections nested
            :param definition_value: definition value which need to be potentially edited
            :param previously_referenced_sections_string_list: sections that have be queried to avoid infinite recursive loops
            :return edited_definition_value: Which is the raw definition value if no referenced sections were found or
            the definition value with referenced sections added.
            """


        # Search for referenced sections within definitions values
        edited_definition_value = definition_value
        # If a reference section exists in the text
        if re.search('Section\s[0-9]+\.[0-9]+(?:[(][^\s]*[)])*',
                     definition_value.replace('”', '"').replace('“', '"').replace(u'\xa0', u' ')):
            # Extract sections strings, sections top section numbers and sections headers
            referenced_sections = []
            referenced_section_string = []
            for m in re.findall('Section\s[0-9]+\.[0-9]+(?:[(][^\s]*[)])*',
                                definition_value.replace('”', '"').replace('“', '"').replace(u'\xa0', u' ')):
                if m not in referenced_section_string:
                    single_rc = [m]
                    referenced_section_string.append(m)
                    # Sometimes the sections top section number is missing
                    try:
                        single_rc.append(
                            re.findall(
                                r'Section\s[0-9]+\.[0-9]+',
                                re.sub("\(.*?\)", "", m).strip()
                            )[0])
                    except:  # noqa: E722
                        single_rc.append("")

                    single_rc.append(re.findall(r"\((.*?)\)", m))
                    if single_rc[0] not in previously_referenced_sections_string_list:
                        referenced_sections.append(single_rc)

            previously_referenced_sections_string_list = previously_referenced_sections_string_list + referenced_section_string
            for section in referenced_sections:
                try:
                    # If in the referenced section there are sections headers and a top level number
                    if len(section[2]) >= 1 and len(section[1]) > 0:
                        section_text_dict = get_by_path(
                            root=lower_level_sections,
                            items=[section[1]] + [f"({level})" for level in section[2]]
                        )
                        if section_text_dict == {}:
                            if len(section[2]) > 1:
                                section_text_dict = get_by_path(
                                    root=lower_level_sections,
                                    items=[section[1]] + [f"({level})" for level in section[2][:-1]]
                                )
                            else:
                                section_text_dict = get_by_path(
                                    root=lower_level_sections,
                                    items=[section[1]]
                                )

                        section_text_dict_text_value_strings = '. '.join([
                            str(item) for sublist in self.get_recursively(section_text_dict) for item in sublist
                        ])
                        section_text_dict_text_value_strings = section_text_dict_text_value_strings.replace(
                            ". .",
                            "."
                        )
                        if re.search('Section\s[0-9]+\.[0-9]+[(][^\s]*[)]',
                                     section_text_dict_text_value_strings.replace(
                                         '”',
                                         '"'
                                     ).replace(
                                         '“',
                                         '"'
                                     ).replace(u'\xa0', u' ')):
                            section_text_dict_text_value_strings = self.create_single_edited_definition_value(
                                lower_level_sections,
                                section_text_dict_text_value_strings,
                                previously_referenced_sections_string_list=previously_referenced_sections_string_list
                            )
                        replacement_text = f". {section[0]}: {section_text_dict_text_value_strings}"
                        edited_definition_value = edited_definition_value + replacement_text
                        edited_definition_value = edited_definition_value.replace("..", ".")
                    else:
                        # If the section is not created in format that is referencable simply output the original
                        # definition
                        logger.info(f"Failed to extract data for the section {section}")
                except Exception as e:
                    # If the section is not created in format that is referencable simply output the original definition
                    logger.error(f"Failed to extract data for the section {section} becuase of error: {e}")

        return edited_definition_value

    def us_create_edited_definition_value(
            self,
            sub_sections_dictionary: dict,
            definition_value_list: list
    ) -> list:
        """
            Create edited definition values list where referenced sections are added

            :param sub_sections_dictionary: sections dictionary with subsections nested
            :param definition_value_list: definition values list which need to be potentially edited
            :return edited_definition_value_list: Which is the raw definition value if no referenced sections were found or
            the definition value with referenced sections added.
            """

        top_level_section = list(sub_sections_dictionary.keys())[0]
        # Nested sub sections
        lower_level_sections = sub_sections_dictionary[top_level_section]
        edited_definition_value_list = []

        for definition_value in definition_value_list:
            # Search for referenced sections within definitions values
            edited_definition_value = self.create_single_edited_definition_value(
                lower_level_sections,
                definition_value
            )
            edited_definition_value_list.append(edited_definition_value)

        return edited_definition_value_list

    def get_recursively(self, search_dict: dict, field: str = "Text") -> list:
        """
        Takes a dict with nested lists and dicts,
        and searches all dicts for a key of the field
        provided.

        :param search_dict: dict to search recursively
        :param field: dict key whoes values you want to collect
        :return fields_found: list of values with the field as a key in the dict
        """
        fields_found = []

        for key, value in search_dict.items():

            if key == field:
                fields_found.append(value)

            elif isinstance(value, dict):
                results = self.get_recursively(value, field)
                for result in results:
                    fields_found.append(result)

            elif isinstance(value, list):
                for item in value:
                    if isinstance(item, dict):
                        more_results = self.get_recursively(item, field)
                        for another_result in more_results:
                            fields_found.append(another_result)

        return fields_found

    def EMEA_create_edited_definition_value(self, terms_conditions_sub_sections_dictionary: dict,
                                            definition_value_list: list) -> list:
        """
        Create edited definition values list where referenced conditions from terms and conditions section are added

        :param terms_conditions_sub_sections_dictionary: terms and conditions section with subsections nested
        :param definition_value_list: definition values list which need to be potentially edited
        :return edited_definition_value_list: Which is the raw definition value if no referenced conditions were found or
        the definition value with referenced conditions added.
        """
        # Terms and conditions section key
        top_level_section = list(terms_conditions_sub_sections_dictionary.keys())[0]
        # Terms and conditions section nested sub sections
        lower_level_conditions_sections = terms_conditions_sub_sections_dictionary[top_level_section]
        edited_definition_value_list = []

        for definition_value in definition_value_list:
            # Search for referenced conditions within definitions values
            edited_definition_value = definition_value
            # If a reference condition exists in the text
            if re.search('Condition\s[0-9]*[^\s]*\s[(][^)]*[)]',
                         definition_value.replace('”', '"').replace('“', '"').replace(u'\xa0', u' ')):
                # Extract conditions strings, conditions top section numbers and conditions headers
                referenced_conditions = []
                for m in re.findall('Condition\s[0-9]*[^\s]*\s[(][^)]*[)]',
                                    definition_value.replace('”', '"').replace('“', '"').replace(u'\xa0', u' ')):
                    single_rc = [m]
                    # Sometimes the conditions top section number is missing
                    try:
                        single_rc.append(re.findall(r'\d+', re.sub("\(.*?\)", "", m).strip())[0])
                    except Exception as err:
                        single_rc.append("")
                        logger.error(err)

                    single_rc.append(re.findall(r"\((.*?)\)", m))
                    referenced_conditions.append(single_rc)

                for condition in referenced_conditions:
                    try:
                        # If in the referenced condition there are conditions headers and a top level number
                        if len(condition[2]) >= 1 and len(condition[1]) > 0:
                            condition_text_dict = get_by_path(
                                root=lower_level_conditions_sections,
                                items=[condition[1]] + [f"({level})" for level in condition[2][:-1]]
                            )

                            condition_text_dict_text_value_strings = '. '.join(
                                [str(item) for sublist in self.get_recursively(condition_text_dict) for item in
                                 sublist])
                            condition_text_dict_text_value_strings = condition_text_dict_text_value_strings.replace(
                                "..",
                                ".")

                            replacement_text = f". {condition[0]}: {condition_text_dict_text_value_strings}"
                            edited_definition_value = edited_definition_value + replacement_text
                            edited_definition_value = edited_definition_value.replace("..", ".")
                        # If in the referenced condition there are conditions headers but no top level number
                        elif len(condition[2]) >= 1 and len(condition[1]) == 0:
                            condition_text = get_by_path(root=lower_level_conditions_sections,
                                                         items=[condition[2][0]] + [f"({level})" for level in
                                                                                    condition[2][1:-1]])
                            condition_text_dict_text_value_strings = '. '.join(
                                [str(item) for sublist in self.get_recursively(condition_text) for item in sublist])
                            condition_text_dict_text_value_strings = condition_text_dict_text_value_strings.replace(
                                "..",
                                ".")
                            replacement_text = f". {condition[0]}: {condition_text_dict_text_value_strings}"
                            edited_definition_value = edited_definition_value + replacement_text
                            edited_definition_value = edited_definition_value.replace("..", ".")
                        else:
                            # If the condition is not created in format that is referencable simply output the original definition
                            logger.info(f"Failed to extract data for the condition {condition}")
                    except Exception as err:
                        logger.error(err)
                        # If the condition is no created in format that is referencable simply output the original definition
                        pass
                edited_definition_value_list.append(edited_definition_value)
            else:
                edited_definition_value_list.append(definition_value)

        return edited_definition_value_list

    def extract_EMEA_docx_clo_sections_definitions(self):
        """
        Extract text info broken down by section and definitions from CLO docx files into dictionary

        :return sections_dictionary: extract text dictionary
        """
        global main_top_level_section_style, terms_conditions_sub_sections_dictionary
        logger.info(f"\nExtracting text from: {self.file_name}")

        try:
            doc = Document(self.word_doc_filepath)

            # Extract Sections
            sections_dictionary = {"file_name": self.file_name,
                                   "Sections_Data": {}}

            eligibility_criteria_text_style = "Not Assigned"
            main_section_key_list = []
            for idx, docpara in enumerate(doc.paragraphs):
                # Extract the eligibility_criteria text style if assigned for subsection extraction later
                if "Eligibility Criteria" == docpara.text and not docpara.runs[0].italic:
                    eligibility_criteria_text_style = docpara.style.name
                table_of_content_finder = re.findall('^.+\t[0-9]+$', docpara.text)
                # Extract main sections from the table of contents of the word doc
                if table_of_content_finder and "toc 1" in docpara.style.name:
                    main_section_key_list.append(replace_whitespace_and_strip(docpara.text.split('\t')[0]))

            # If the table of contents is in hyperlink format, extract manually via xml elements
            if len(main_section_key_list) == 0:
                start_of_toc = False
                start_saving_toc = False
                index_after_start_save = 0
                previous_text = ""
                # extract body elements
                body_elements = doc._body._body
                # extract those wrapped in <w:r> tag
                rs = body_elements.xpath('.//w:r')
                # check if style is hyperlink (toc)
                for r in rs:
                    # Table of contents always starts with string "table of contents"
                    if "table of contents" in r.text.lower():
                        start_of_toc = True
                        continue
                    if start_of_toc:
                        # Always a table before table of contents text
                        if "\t" == r.text:
                            start_saving_toc = True

                        if start_saving_toc:
                            # First line of table of contents text is simply header
                            if index_after_start_save == 0:
                                main_section_key_list.append(replace_whitespace_and_strip(previous_text))
                                index_after_start_save += 1
                            else:
                                # Past irst line of table of contents text is simply header need to extract section
                                found_main_section = re.findall("^.*[a-zA-Z]+$", r.text)
                                if found_main_section:
                                    # If section does not alreaedy exist in main_section_key_list append to list
                                    if len(
                                            set(main_section_key_list).intersection(
                                                {replace_whitespace_and_strip(
                                                    found_main_section[0],
                                                    replacement=" "
                                                )}
                                            )
                                    ) == 0:
                                        main_section_key_list.append(
                                            replace_whitespace_and_strip(found_main_section[0]))
                                    else:
                                        break
                        # capture previous lines text for initial toc line section
                        previous_text = r.text

            index_of_main_sections = 0
            all_section_paths = []
            current_indent_list = [0]
            sections_path = ["Initial_Section"]
            # Iterate through word document paragraphs text, finding sections then adding text to sections
            for idx, docpara in enumerate(doc.paragraphs):

                # If paragraph left_indent number exists update indent list and section path accordingly
                try:
                    if docpara.paragraph_format.left_indent:
                        index_of_section_indent = current_indent_list.index(docpara.paragraph_format.left_indent)
                        current_indent_list = current_indent_list[:index_of_section_indent + 1]
                        sections_path = sections_path[:index_of_section_indent + 1]
                    else:
                        pass
                # if left indent exists but is not in current_indent_list
                except ValueError:
                    pass

                # Find if paragraph is a main section header
                intersection_main_sections = set(main_section_key_list).intersection(
                    {replace_whitespace_and_strip(docpara.text, replacement=" ")})

                # If first main section
                if intersection_main_sections and index_of_main_sections < 1:
                    # Remove section header from main section list to make sure not used twice
                    main_section_key_list.remove(list(intersection_main_sections)[0])
                    main_section_key = replace_whitespace_and_strip(docpara.text)
                    sections_path = [main_section_key]
                    current_indent_list = [docpara.paragraph_format.left_indent]
                    main_top_level_section_style = docpara.style.name
                    index_of_main_sections += 1
                # If not first main section
                elif intersection_main_sections and index_of_main_sections >= 1:
                    if main_top_level_section_style == docpara.style.name:
                        main_section_key_list.remove(list(intersection_main_sections)[0])
                        main_section_key = replace_whitespace_and_strip(docpara.text)
                        sections_path = [main_section_key]
                        current_indent_list = [docpara.paragraph_format.left_indent]
                        index_of_main_sections += 1
                # If not a main section search if it is numeric subsection
                elif re.findall("^[0-9]+.[\t\s]*", docpara.text):
                    # Review if paragraph has subsection format characteristics
                    if (
                            (len(re.findall("(?:\.[\t\s]+|\.$)",
                                            docpara.text.split(re.findall("^[0-9]+.[\t\s]*", docpara.text)[0])[
                                                1])) == 0)
                            and
                            ("toc" not in docpara.style.name)
                            and
                            (len(re.findall("\+",
                                            docpara.text.split(re.findall("^[0-9]+.[\t\s]*", docpara.text)[0])[
                                                1])) == 0)
                            and
                            docpara.paragraph_format.left_indent
                    ):
                        # Add sub section to current_indent_list and sections_path
                        sub_section_key = replace_whitespace_and_strip(docpara.text)
                        try:
                            index_of_section_indent = current_indent_list.index(docpara.paragraph_format.left_indent)
                            # Subsection level is stopped at level 3 since it is not extractable past this level
                            if len(sections_path[:index_of_section_indent] + [sub_section_key]) < 3:
                                # If left indent exists in index_of_section_indent
                                current_indent_list = current_indent_list[:index_of_section_indent + 1]
                                sections_path = sections_path[:index_of_section_indent] + [sub_section_key]
                        except ValueError:
                            # Subsection level is stopped at level 3 since it is not extractable past this level
                            if len(sections_path + [sub_section_key]) < 3:
                                # If subsection does not exist with this indent, add newly to list
                                current_indent_list.append(docpara.paragraph_format.left_indent)
                                sections_path.append(sub_section_key)
                # If not a main section, nor numeric subsection, search if paragraph style is
                # same as eligibility criteria subsection header text style
                elif docpara.style.name == eligibility_criteria_text_style:
                    # Add sub section to current_indent_list and sections_path if it is only alpa numeric or space
                    if len(re.findall("^[a-zA-Z0-9\s]+$", docpara.text)):
                        sub_section_key = replace_whitespace_and_strip(docpara.text)
                        indent = 1
                        try:
                            index_of_section_indent = current_indent_list.index(indent)
                            # Subsection level is stopped at level 3 since it is not extractable past this level
                            if len(sections_path[:index_of_section_indent] + [sub_section_key]) < 3:
                                # If left indent exists in index_of_section_indent
                                current_indent_list = current_indent_list[:index_of_section_indent + 1]
                                sections_path = sections_path[:index_of_section_indent] + [sub_section_key]
                        except ValueError:
                            # Subsection level is stopped at level 3 since it is not extractable past this level
                            if len(sections_path + [sub_section_key]) < 3:
                                # If subsection does not exist with this indent, add newly to list
                                current_indent_list.append(indent)
                                sections_path.append(sub_section_key)
                # If the paragraph is not a section nor a subsection start
                else:
                    pass
                # If the section path already exists, append to it
                if get_by_path(
                        root=sections_dictionary,
                        items=["Sections_Data"] + sections_path
                ) != {}:
                    current_value_text = get_by_path(
                        root=sections_dictionary,
                        items=["Sections_Data"] + sections_path + ['Text']
                    )
                    current_value_text_left_indent = get_by_path(
                        root=sections_dictionary,
                        items=["Sections_Data"] + sections_path + ['Text_Left_Indent']
                    )
                    set_by_path(
                        root=sections_dictionary,
                        items=["Sections_Data"] + sections_path + ['Text'],
                        value=current_value_text + [docpara.text]
                    )
                    set_by_path(
                        root=sections_dictionary,
                        items=["Sections_Data"] + sections_path + ['Text_Left_Indent'],
                        value=current_value_text_left_indent + [docpara.paragraph_format.left_indent]
                    )
                else:
                    # If section path does not exist, create it
                    all_section_paths.append(["Sections_Data"] + sections_path)
                    set_by_path(
                        root=sections_dictionary,
                        items=["Sections_Data"] + sections_path + ['Text'],
                        value=[docpara.text])
                    set_by_path(
                        root=sections_dictionary,
                        items=["Sections_Data"] + sections_path + ['Text_Left_Indent'],
                        value=[docpara.paragraph_format.left_indent])
                    set_by_path(
                        root=sections_dictionary,
                        items=["Sections_Data"] + sections_path + ['Raw_Text_Definitions'],
                        value={})
                    set_by_path(
                        root=sections_dictionary,
                        items=["Sections_Data"] + sections_path + ['Edited_Text_Definitions'],
                        value={})

            # Create terms and conditions lower level subsection dictionary for
            terms_conditions_sub_sections_dictionary = create_lower_level_terms_conditions_sections(
                sections_dictionary)

            # After splitting text into sections, find definitions within the text and add to Definitions
            # key within section key
            period_at_end_of_string_row = False
            period_at_end_of_string_row_definition_value_set = False
            period_at_end_of_string_row_definition_value = ""
            for total_section_path in all_section_paths:
                definition_term = ""
                definition_value = ""
                # Iterate through text within section finding definitions via regex patterns and add to
                # section in dictionary
                for string_row in get_by_path(
                        root=sections_dictionary,
                        items=total_section_path + ['Text']
                ):
                    # If a definition pattern is found go into definition statement
                    if re.search(
                            '^\"[^"]*\"[\s:]',
                            string_row.replace('”', '"').replace('“', '"').replace(u'\xa0', u' ').strip()
                    ):
                        # If definition definition_term is queued, append to definition_term string value
                        if definition_term == \
                                re.search('^\"[^"]*\"[\s:]',
                                          string_row.replace('”', '"').replace('“', '"').replace(u'\xa0',
                                                                                                 u' ').strip()).group().split(
                                    '"')[1].strip():
                            definition_value += string_row.replace('”', '"').replace('“', '"').replace(u'\xa0',
                                                                                                       u' ').strip()
                        else:
                            if len(definition_term) > 0:
                                # If definition definition_term is already in dictionary but is not queued, append
                                # to definition_term value list
                                if definition_term in get_by_path(root=sections_dictionary,
                                                                  items=total_section_path + [
                                                                      'Raw_Text_Definitions']).keys():
                                    current_value_text = get_by_path(root=sections_dictionary,
                                                                     items=total_section_path + [
                                                                         'Raw_Text_Definitions'] + [
                                                                               definition_term])
                                    set_by_path(
                                        root=sections_dictionary,
                                        items=total_section_path + ['Raw_Text_Definitions'] + [definition_term],
                                        value=current_value_text + [definition_value])

                                    set_by_path(
                                        root=sections_dictionary,
                                        items=total_section_path + ['Edited_Text_Definitions'] + [definition_term],
                                        value=self.EMEA_create_edited_definition_value(
                                            terms_conditions_sub_sections_dictionary,
                                            current_value_text + [definition_value]))

                                else:
                                    # If definition definition_term is not in dictionary start
                                    # definition_term value list
                                    # Only add if definition value is less than 2000 characters
                                    # otherwise save value up to first paragraph line that ended in periods
                                    if len(definition_value.split(" ")) >= 2000:
                                        if period_at_end_of_string_row_definition_value != "":
                                            definition_value = period_at_end_of_string_row_definition_value

                                    set_by_path(
                                        root=sections_dictionary,
                                        items=total_section_path + ['Raw_Text_Definitions'] + [definition_term],
                                        value=[definition_value])

                                    set_by_path(
                                        root=sections_dictionary,
                                        items=total_section_path + ['Edited_Text_Definitions'] + [definition_term],
                                        value=self.EMEA_create_edited_definition_value(
                                            terms_conditions_sub_sections_dictionary,
                                            [definition_value]))

                            # Clear definition_value as definition value has already been added
                            definition_value = ""
                            # Pull new definition term and value
                            definition_term = \
                                re.search('^\"[^"]*\"[\s:]',
                                          string_row.replace('”', '"').replace('“', '"').replace(u'\xa0',
                                                                                                 u' ').strip()).group().split(
                                    '"')[
                                    1].strip()
                            definition_value += \
                                re.split('^\"[^"]*\"[\s:]',
                                         string_row.replace('”', '"').replace('“', '"').replace(u'\xa0', u' ').strip())[
                                    1].strip()
                            period_at_end_of_string_row = False
                            period_at_end_of_string_row_definition_value_set = False
                            period_at_end_of_string_row_definition_value = ""
                    # Add to definition term until another definition is found
                    elif definition_term != "":
                        # Only add if definition value is less than 2000 characters
                        # otherwise save value up to first paragraph line that ended in periods
                        if len(definition_value.split(" ")) >= 2000:
                            if period_at_end_of_string_row_definition_value != "":
                                definition_value = period_at_end_of_string_row_definition_value
                                period_at_end_of_string_row_definition_value_set = True
                            else:
                                continue
                        else:
                            if not period_at_end_of_string_row:
                                try:
                                    if "." == definition_value.strip()[-1]:
                                        if not period_at_end_of_string_row:
                                            period_at_end_of_string_row_definition_value = definition_value
                                            period_at_end_of_string_row = True
                                except IndexError:
                                    continue
                            if not period_at_end_of_string_row_definition_value_set:
                                definition_value += " " + string_row.replace('”', '"').replace('“', '"').replace(
                                    u'\xa0',
                                    u' ')

                # Add last definition in section strings to dictionary
                if definition_term != "":
                    # Only add if definition value is less than 2000 characters
                    # otherwise save value up to first paragraph line that ended in periods
                    if len(definition_value.split(" ")) >= 2000:
                        if period_at_end_of_string_row_definition_value != "":
                            definition_value = period_at_end_of_string_row_definition_value
                            period_at_end_of_string_row_definition_value_set = True
                        else:
                            continue

                    set_by_path(
                        root=sections_dictionary,
                        items=total_section_path + ['Raw_Text_Definitions'] + [definition_term],
                        value=[definition_value])

                    set_by_path(
                        root=sections_dictionary,
                        items=total_section_path + ['Edited_Text_Definitions'] + [definition_term],
                        value=self.EMEA_create_edited_definition_value(terms_conditions_sub_sections_dictionary,
                                                                       [definition_value]))
        except Exception as e:
            logger.info(f"Found exception for doc {self.file_name}")
            logger.error(e)
            sections_dictionary = {"file_name": self.file_name,
                                   "Sections_Data": {"Raw_Text_Definitions": None}}

        sections_dictionary['Sections_Data'][
            'Terms_and_Conditions_Subsections'] = terms_conditions_sub_sections_dictionary
        return sections_dictionary

    def extract_US_docx_clo_sections_definitions(self):
        """
        Extract text info broken down by section and definitions from CLO EMEA docx files into dictionary

        :param word_doc_filepath: word doc path that needs text/definition extraction
        :return sections_dictionary: extract text dictionary
        :return all_section_paths: List of all section path lists
        """
        logger.info(f"\nExtracting text from: {self.file_name}")

        try:
            doc = Document(self.word_doc_filepath)
            # Extract Sections
            sections_dictionary = {"file_name": self.file_name,
                                   "Sections_Data": {}}

            main_section_key_list = []
            for idx, docpara in enumerate(doc.paragraphs):
                table_of_content_finder = re.findall(
                    '(?:^.+\t|^.+\t.+\t|^Section\s[0-9]+\.[0-9]+\t.+\t)[0-9]+$',
                    docpara.text
                )
                # Extract main sections from the table of contents of the word doc
                if table_of_content_finder and "toc 1" in docpara.style.name:
                    main_section_key_list.append(replace_whitespace_and_strip(docpara.text.rpartition('\t')[0]))
                # Extract main sections from the table of contents of the word doc
                if table_of_content_finder and "toc 2" in docpara.style.name:
                    section_match = re.findall('(?:^.+\t.+\t|^Section\s[0-9]+\.[0-9]+\t.+\t)', docpara.text.strip())
                    main_section_key_list.append(replace_whitespace_and_strip(section_match[0].strip()))

            all_section_paths = []
            current_indent_list = [0]
            sections_path = ["Initial_Section"]
            # Iterate through word document paragraphs text, finding sections then adding text to sections
            for idx, docpara in enumerate(doc.paragraphs):
                # If paragraph left_indent number exists update indent list and section path accordingly
                try:
                    if docpara.paragraph_format.left_indent:
                        index_of_section_indent = current_indent_list.index(docpara.paragraph_format.left_indent)
                        current_indent_list = current_indent_list[:index_of_section_indent + 1]
                        sections_path = sections_path[:index_of_section_indent + 1]
                    else:
                        pass
                # if left indent exists but is not in current_indent_list
                except ValueError:
                    pass

                def check_for_section_string_start(main_section_key_list, text):
                    matched_main_sections = []
                    toc_section_ending_finder = re.findall('\t[0-9]+$', text)
                    text_without_whitespace = replace_whitespace_and_strip(text, replacement=" ")
                    for main_section in main_section_key_list:
                        section_num_finder = re.findall(
                            '(:?^[0-9]+\.[0-9]+|^Section\s[0-9]+\.[0-9]+)',
                            main_section
                        )

                        if not section_num_finder:
                            # Find if paragraph starts with main section header
                            if text_without_whitespace.startswith(main_section) and not toc_section_ending_finder:
                                matched_main_sections.append(main_section)
                        else:
                            string_title_no_section_number_with_period = main_section.split(section_num_finder[0])[
                                                                             1].strip() + "."
                            # Find if paragraph starts with main section header
                            if text_without_whitespace.startswith(
                                    string_title_no_section_number_with_period) and not toc_section_ending_finder:
                                matched_main_sections.append(main_section)
                            elif text_without_whitespace.startswith(main_section) and not toc_section_ending_finder:
                                matched_main_sections.append(main_section)

                    return matched_main_sections

                # Find if paragraph is a main section header
                intersection_main_sections = check_for_section_string_start(main_section_key_list, docpara.text)

                # If first main section
                if intersection_main_sections:
                    # Remove section header from main section list to make sure not used twice
                    main_section_key_list.remove(intersection_main_sections[0])
                    # main_section_key = replace_whitespace_and_strip(docpara.text)
                    sections_path = [intersection_main_sections[0]]
                    current_indent_list = [docpara.paragraph_format.left_indent]

                # If the paragraph is not a section nor a subsection start
                else:
                    pass
                # If the section path already exists, append to it
                if get_by_path(
                        root=sections_dictionary,
                        items=["Sections_Data"] + sections_path
                ) != {}:
                    current_value_text = get_by_path(
                        root=sections_dictionary,
                        items=["Sections_Data"] + sections_path + ['Text']
                    )
                    current_value_text_left_indent = get_by_path(
                        root=sections_dictionary,
                        items=["Sections_Data"] + sections_path + ['Text_Left_Indent']
                    )
                    set_by_path(
                        root=sections_dictionary,
                        items=["Sections_Data"] + sections_path + ['Text'],
                        value=current_value_text + [docpara.text]
                    )
                    set_by_path(
                        root=sections_dictionary,
                        items=["Sections_Data"] + sections_path + ['Text_Left_Indent'],
                        value=current_value_text_left_indent + [docpara.paragraph_format.left_indent]
                    )
                else:
                    # If section path does not exist, create it
                    all_section_paths.append(["Sections_Data"] + sections_path)
                    set_by_path(
                        root=sections_dictionary,
                        items=["Sections_Data"] + sections_path + ['Text'],
                        value=[docpara.text])
                    set_by_path(
                        root=sections_dictionary,
                        items=["Sections_Data"] + sections_path + ['Text_Left_Indent'],
                        value=[docpara.paragraph_format.left_indent])
                    set_by_path(
                        root=sections_dictionary,
                        items=["Sections_Data"] + sections_path + ['Raw_Text_Definitions'],
                        value={})
                    set_by_path(
                        root=sections_dictionary,
                        items=["Sections_Data"] + sections_path + ['Edited_Text_Definitions'],
                        value={})

            # sections_dictionary_before_definitions = json.dumps(sections_dictionary)
            # Create terms and conditions lower level subsection dictionary for
            sub_sections_dictionary = create_lower_level_sections(sections_dictionary)
            # view_sub_sections_dictionary_json = json.dumps(sub_sections_dictionary)

            # After splitting text into sections, find definitions within the text and add to Definitions
            # key within section key
            period_at_end_of_string_row = False
            period_at_end_of_string_row_definition_value_set = False
            period_at_end_of_string_row_definition_value = ""
            for total_section_path in all_section_paths:
                definition_term = ""
                definition_value = ""
                # Iterate through text within section finding definitions via regex patterns and add to
                # section in dictionary
                for string_row in get_by_path(
                        root=sections_dictionary,
                        items=total_section_path + ['Text']
                ):
                    # If a definition pattern is found go into definition statement
                    if re.search(
                            '^\"[^"]*\"[\s:]',
                            string_row.replace('”', '"').replace('“', '"').replace(u'\xa0', u' ').strip()
                    ):
                        # If definition definition_term is queued, append to definition_term string value
                        if definition_term == \
                                re.search('^\"[^"]*\"[\s:]',
                                          string_row.replace('”', '"').replace('“', '"').replace(u'\xa0',
                                                                                                 u' ').strip()).group().split(
                                    '"')[1].strip():
                            definition_value += string_row.replace('”', '"').replace('“', '"').replace(u'\xa0',
                                                                                                       u' ').strip()
                        else:
                            if len(definition_term) > 0:
                                # If definition definition_term is already in dictionary but is not queued, append
                                # to definition_term value list
                                if definition_term in get_by_path(root=sections_dictionary,
                                                                  items=total_section_path + [
                                                                      'Raw_Text_Definitions']).keys():
                                    current_value_text = get_by_path(root=sections_dictionary,
                                                                     items=total_section_path + [
                                                                         'Raw_Text_Definitions'] + [
                                                                               definition_term])
                                    set_by_path(
                                        root=sections_dictionary,
                                        items=total_section_path + ['Raw_Text_Definitions'] + [definition_term],
                                        value=current_value_text + [definition_value])

                                    set_by_path(
                                        root=sections_dictionary,
                                        items=total_section_path + ['Edited_Text_Definitions'] + [definition_term],
                                        value=self.us_create_edited_definition_value(sub_sections_dictionary,
                                                                                     current_value_text + [
                                                                                         definition_value]))

                                else:
                                    # If definition definition_term is not in dictionary start
                                    # definition_term value list
                                    # Only add if definition value is less than 2000 characters
                                    # otherwise save value up to first paragraph line that ended in periods
                                    if len(definition_value.split(" ")) >= 2000:
                                        if period_at_end_of_string_row_definition_value != "":
                                            definition_value = period_at_end_of_string_row_definition_value

                                    set_by_path(
                                        root=sections_dictionary,
                                        items=total_section_path + ['Raw_Text_Definitions'] + [definition_term],
                                        value=[definition_value])

                                    set_by_path(
                                        root=sections_dictionary,
                                        items=total_section_path + ['Edited_Text_Definitions'] + [definition_term],
                                        value=self.us_create_edited_definition_value(sub_sections_dictionary,
                                                                                     [definition_value]))

                            # Clear definition_value as definition value has already been added
                            definition_value = ""
                            # Pull new definition term and value
                            definition_term = \
                                re.search('^\"[^"]*\"[\s:]',
                                          string_row.replace('”', '"').replace('“', '"').replace(u'\xa0',
                                                                                                 u' ').strip()).group().split(
                                    '"')[
                                    1].strip()
                            definition_value += \
                                re.split('^\"[^"]*\"[\s:]',
                                         string_row.replace('”', '"').replace('“', '"').replace(u'\xa0', u' ').strip())[
                                    1].strip()
                            period_at_end_of_string_row = False
                            period_at_end_of_string_row_definition_value_set = False
                            period_at_end_of_string_row_definition_value = ""
                    # Add to definition term until another definition is found
                    elif definition_term != "":
                        # Only add if definition value is less than 2000 characters
                        # otherwise save value up to first paragraph line that ended in periods
                        if len(definition_value.split(" ")) >= 2000:
                            if period_at_end_of_string_row_definition_value != "":
                                definition_value = period_at_end_of_string_row_definition_value
                                period_at_end_of_string_row_definition_value_set = True
                            else:
                                continue
                        else:
                            if not period_at_end_of_string_row:
                                try:
                                    if "." == definition_value.strip()[-1]:
                                        if not period_at_end_of_string_row:
                                            period_at_end_of_string_row_definition_value = definition_value
                                            period_at_end_of_string_row = True
                                except IndexError:
                                    continue
                            if not period_at_end_of_string_row_definition_value_set:
                                definition_value += " " + string_row.replace('”', '"').replace('“', '"').replace(
                                    u'\xa0', u' ')

                # Add last definition in section strings to dictionary
                if definition_term != "":
                    # Only add if definition value is less than 2000 characters
                    # otherwise save value up to first paragraph line that ended in periods
                    if len(definition_value.split(" ")) >= 2000:
                        if period_at_end_of_string_row_definition_value != "":
                            definition_value = period_at_end_of_string_row_definition_value
                            period_at_end_of_string_row_definition_value_set = True
                        else:
                            continue

                    set_by_path(
                        root=sections_dictionary,
                        items=total_section_path + ['Raw_Text_Definitions'] + [definition_term],
                        value=[definition_value])

                    set_by_path(
                        root=sections_dictionary,
                        items=total_section_path + ['Edited_Text_Definitions'] + [definition_term],
                        value=self.us_create_edited_definition_value(sub_sections_dictionary, [definition_value]))
            sections_dictionary['Sections_Data']['Extracted_Subsections'] = sub_sections_dictionary
        except Exception as e:
            logger.info(f"Found exception for doc {self.file_name}")
            logger.error(e)
            sections_dictionary = {"file_name": self.file_name,
                                   "Sections_Data": {"Edited_Text_Definitions": None}}

        return sections_dictionary


if __name__ == "__main__":
    # Example usage
    word_doc_path: str = os.path.join(r'/Users/m_nallabothula/Downloads/code/dscience-clo-gpt-rest/source_documents',
                                      r'clo-gpt-si',
                                      r'Orion CLO 2023-1 Ltd.DOCX')
    extractor = DefinitionExtractor(word_doc_path)
    sections_dict = extractor.extract_clo_data()
    logger.info(sections_dict)
