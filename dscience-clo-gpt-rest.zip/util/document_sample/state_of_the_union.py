txt_message = """About Company: 
S&P Global Ratings (previously Standard & Poor's and informally known as S&P) is an American credit rating agency (CRA) 
and a division of S&P Global that publishes financial research and analysis on stocks, bonds, and commodities. 
S&P is considered the largest of the Big Three credit-rating agencies, which also include Moody's Investors Service and Fitch Ratings.[2]
Its head office is located on 55 Water Street in Lower Manhattan, New York City.[3]

History: 
The company traces its history back to 1860, with the publication by Henry Varnum Poor of History of Railroads and Canals in the United States. 
This book compiled comprehensive information about the financial and operational state of U.S.
railroad companies. In 1868, Henry Varnum Poor established H.V. and H.W. Poor Co. with his son, Henry William Poor, and published two annually updated hardback guidebooks,
Poor's Manual of the Railroads of the United States and Poor's Directory of Railway Officials.
In 1906, Luther Lee Blake founded the Standard Statistics Bureau, with the view to providing financial information on non-railroad companies. 
Instead of an annually published book, Standard Statistics would use 5-by-7-inch cards, allowing for more frequent updates.[4]
In 1941, Paul Talbot Babson purchased Poor's Publishing and merged it with Standard Statistics to become Standard & Poor's Corp.
In 1966, the company was acquired by The McGraw-Hill Companies, extending McGraw-Hill into the field of financial information services.[4]
"""