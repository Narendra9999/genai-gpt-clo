from pymongo import MongoClient
import os
from util import logger

logger = logger.getlogger()


class MongoHandler:
    def __init__(self, mongo_db_user=None, mongo_db_pw=None, mongo_db_host=None, mongo_db_name=None):
        self.mongo_db_user = mongo_db_user
        self.mongo_db_pw = mongo_db_pw
        self.mongo_db_host = mongo_db_host
        self.mongo_db_name = mongo_db_name

        self.mongo_uri = f"mongodb://{self.mongo_db_user}:{self.mongo_db_pw}@{self.mongo_db_host}/"

        # Collection names
        self.emea_questions_collection_name = "clo-gpt.emea.questions"
        self.emea_responses_collection_name = "clo-gpt.emea.responses"
        self.us_questions_collection_name = "clo-gpt.us.questions"
        self.us_responses_collection_name = "clo-gpt.us.responses"
        self.feedback_collection_name = "clo-gpt.feedback"
        # Initialize MongoDB connection
        self._connect_to_db()

    def _connect_to_db(self):
        try:
            self.mongo_client = MongoClient(self.mongo_uri)
            self.db = self.mongo_client[self.mongo_db_name]
            self.emea_questions_collection = self.db[self.emea_questions_collection_name]
            self.emea_responses_collection = self.db[self.emea_responses_collection_name]
            self.us_questions_collection = self.db[self.us_questions_collection_name]
            self.us_responses_collection = self.db[self.us_responses_collection_name]
            self.feedback_collection = self.db[self.feedback_collection_name]

        except Exception as e:
            logger.error(f"Error connecting to MongoDB: {e}")
            raise e  # Rethrowing the exception or handle it as per your application's error handling policy.

    def get_active_questions(self, number_of_questions, region):
        query = {"Active Question (Y/N)": "Y"}
        projection = {"Question": 1, "_id": 0}
        collection = self.emea_questions_collection if region == 1 else self.us_questions_collection
        questions = []

        try:
            if number_of_questions == 10:
                questions = collection.find(query, projection)
            else:
                questions = collection.find()

            return list(questions)  # Convert cursor to list
        except Exception as e:
            logger.error(f"Error fetching active questions: {e}")

        return list(questions)

    def save_responses_to_mongodb(self, region, responses=None):
        if responses is None:
            responses = []
        collection = self.emea_responses_collection if region == 1 else self.us_responses_collection

        try:
            if responses:
                collection.insert_many(responses)
        except Exception as e:
            logger.error(f"Error saving responses: {e}")

    def save_feedback_to_mongodb(self, feedback_data):
        result = None

        if feedback_data:
            result = self.feedback_collection.insert_one(feedback_data)

        return result


if __name__ == "__main__":
    try:
        mongo_handler = MongoHandler()
        active_questions = mongo_handler.get_active_questions(10, region=1)
        mongo_handler.save_responses_to_mongodb(region=1, responses=[{"answer": "Yes"}])
    except Exception as e:
        logger.error("An error occurred in the main execution block", exc_info=True)