from elasticsearch import Elasticsearch, RequestsHttpConnection
from util import logger, env
import os

logger = logger.getlogger()

ES_INDEX = os.environ.get("OPENSEARCH_INDEX", "clo_document_usecase_clogpt_test_sections_recent_code")

ES_CLUSTER_CONFIG = {
    'HOST': r'dscience-int-es.dev.spratingsvpc.com',
    'PORT': 443,
    'SCHEME': 'https',
    'USER_NAME': env.opensearch_credentials[0],
    'PASSWORD': env.opensearch_credentials[1],
    'INDEX': ES_INDEX,
    'settings': {
        "index.number_of_shards": 3,
        "index.number_of_replicas": 0,
        "index.mapping.nested_objects.limit": 20000,
        "index.mapping.total_fields.limit": 20000,
        "analysis": {
            "normalizer": {
                "lowercase_normalizer": {
                    "type": "custom",
                    "filter": ["lowercase"]
                }
            }
        }
    },
    'mappings': {
        "properties": {
            "user_id": {
                "type": "text",
                "fields": {
                    "raw": {
                        "type": "keyword"
                    }
                }
            },
            "file_name": {
                "type": "text",
                "fields": {
                    "raw": {
                        "type": "keyword"
                    }
                }
            },
            "definitions": {
                "type": "nested",
                "properties": {
                    "definition_text": {"type": "text"},
                    "definition_term": {"type": "keyword",
                                        "normalizer": "lowercase_normalizer"}
                }
            },
            "sections": {
                "type": "nested",
                "properties": {
                    "section_text": {"type": "text"},
                    "section_term": {"type": "keyword",
                                     "normalizer": "lowercase_normalizer"}
                }
            }
        }
    }
}
# right now only 1 instance, when multiple instances, it is better to switch to Obj
# But since we are migrating to opensearch, not likely we will have one running ES and another running OP
USE_OPENSEARCH = False
es_index = ES_CLUSTER_CONFIG['INDEX']

def _get_elastic_search_client():
    # es_url = 'https://clo_document_search_user:tUWH7WpA0gB@@dscience-int-es.dev.spratingsvpc.com:443'
    es_url = f"{ES_CLUSTER_CONFIG['SCHEME']}://{ES_CLUSTER_CONFIG['USER_NAME']}:{ES_CLUSTER_CONFIG['PASSWORD']}@{ES_CLUSTER_CONFIG['HOST']}:{ES_CLUSTER_CONFIG['PORT']}"
    logger.info(es_url)

    es_client = Elasticsearch([es_url], use_ssl=False, verify_certs=False, connection_class=RequestsHttpConnection)

    return es_client

def init_es_client(opensearch_client=None):
    global USE_OPENSEARCH
    try:
        if opensearch_client is None:
            es_client = _get_elastic_search_client()
            USE_OPENSEARCH = False
        else:
            es_client = opensearch_client
            USE_OPENSEARCH = True

        if es_client.ping():
            logger.info(f'ES connection Established! {es_client}')
        else:
            raise ValueError("Connection failed")

        if not checkIndexPresent(es_client=es_client):
            create_index(es_client)

        return es_client

    except Exception as ex:
        logger.error(ex)

def create_index(es_client):
    # create ES index if not already exists
    try:
        if not checkIndexPresent(es_client):
            es_client.indices.create(index=es_index,
                                     body={'settings': ES_CLUSTER_CONFIG['settings'],
                                           'mappings': ES_CLUSTER_CONFIG['mappings']},
                                     ignore=400)
            logger.info(f'{es_index} created successfully\n')
        else:
            logger.info(str(es_index) + " exists")

    except Exception as es_create_ex:
        raise RuntimeError("INDEX CREATE ERROR:\t" + str(es_create_ex))


def delete_index(es_client):
    response = es_client.indices.delete(index=es_index, ignore=[400, 404])

    # Check if the deletion was successful
    if 'acknowledged' in response and response['acknowledged']:
        create_index(es_client)
        logger.info(f"Successfully cleared the {es_index}..")

        return True
    
    return False

def load_data(es_client, doc):
    res = None
    try:
        # logger.info(doc)
        # make the bulk call, and get a response
        if USE_OPENSEARCH:
            # opensearch does not support doc_type parameter
            res = es_client.index(index=ES_CLUSTER_CONFIG['INDEX'], body=doc, id=doc['file_name'],
                                  refresh=True, ignore=400)
        else:
            # for Elastic search, use existing parameters
            res = es_client.index(index=ES_CLUSTER_CONFIG['INDEX'], doc_type="_doc", body=doc, id=doc['file_name'],
                                  refresh=True, ignore=400)

        logger.info('indexing complete')
    except Exception as e:
        logger.error("\nERROR:", e)

    return res

def checkIndexPresent(es_client):
    return es_client.indices.exists(index=es_index)


def check_and_delete_index_es(es_client):
    """
        This method help to check and delete the existing index.
    """
    try:
        if checkIndexPresent(es_client):
            response = es_client.indices.delete(index=es_index, ignore=[400, 404])
            logger.info(f"response: {response}")
            # Check if the deletion was successful
            if 'acknowledged' in response and response['acknowledged']:
                create_index(es_client)
                logger.info(f"Successfully cleared the {es_index}..")

                return True
    except Exception as e:
        logger.error("\nERROR:", e)
        
    return False

def search_es(es_client, user_id, file_name, definitions, sections):
    user_query_body = {
        "query": {
            "bool": {
                "should": []
            }
        },
        "_source": False
    }

    # Add user_id and file_name terms if provided
    # if user_id:
    #     user_query_body["query"]["bool"]["must"].append({"term": {"user_id.raw": user_id}})
    # if file_name:
    #     user_query_body["query"]["bool"]["must"].append({"term": {"file_name.raw": file_name}})

    # Add nested queries for definitions if not empty
    if definitions:
        nested_definitions_queries = [{"term": {"definitions.definition_term": term}} for term in definitions]
        nested_definitions_query = {
            "nested": {
                "path": "definitions",
                "query": {
                    "bool": {
                        "should": nested_definitions_queries
                    }
                },
                "inner_hits": {"size": 20}
            }
        }
        user_query_body["query"]["bool"]["should"].append(nested_definitions_query)

    # Add nested queries for sections if not empty
    if sections:
        nested_sections_queries = [{"term": {"sections.section_term": term}} for term in sections]
        nested_sections_query = {
            "nested": {
                "path": "sections",
                "query": {
                    "bool": {
                        "should": nested_sections_queries
                    }
                },
                "inner_hits": {"size": 20}
            }
        }
        user_query_body["query"]["bool"]["should"].append(nested_sections_query)

    logger.info(f"user_query_body: {user_query_body}")

    results = es_client.search(index=ES_CLUSTER_CONFIG['INDEX'],
                               request_timeout=3000,
                               body=user_query_body)

    response = []

    if len(results['hits']['hits']) > 0:
        for hit in results['hits']['hits']:
            if 'inner_hits' in hit:
                for inner_hit in hit['inner_hits'].values():
                    for h in inner_hit['hits']['hits']:
                        r = {
                            'file_name': hit['_id'],
                            'term': h['_source']['definition_term'] if 'definition_term' in h['_source'] else h['_source']['section_term'],
                            'text': 'DEFINITION: ' + h['_source']['definition_text'] if 'definition_text' in h['_source'] else 'SECTION: '+ h['_source']['section_text']
                        }
                        response.append(r)
    else:
        definitions = list(set(definitions))
        if definitions:
            for definition in definitions:
                r = {'term': definition, 'text': ' NOT FOUND!',
                    'file_name': 'dummy_filename.docx'}
                response.append(r)
        
        sections = list(set(sections))
        if sections:
            for section in sections:
                r = {'term': section, 'text': ' NOT FOUND!',
                    'file_name': 'dummy_filename.docx'}
                response.append(r)


    logger.info(f"response: {response}")

    return response

