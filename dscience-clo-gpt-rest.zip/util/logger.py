import logging
import logging.config
import os

import yaml

debug_level = os.environ.get('DEBUG_LEVEL', 'DEBUG')

# Read logging.yaml file
try:
    with open(os.path.dirname(os.path.abspath(__file__)) + "/logging.yaml", 'r') as f:
        log_cfg = yaml.safe_load(f.read())
except Exception:
    raise

logging.config.dictConfig(log_cfg)


def getlogger():
    all_logger = logging.getLogger('all')
    all_logger.setLevel(logging.getLevelName(debug_level))
    return all_logger

