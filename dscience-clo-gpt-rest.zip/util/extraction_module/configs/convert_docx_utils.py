import logging
import os
from io import BytesIO

# from util.extraction_module.configs.base_config import dll


# the path below will need to be relative


def convert_word_to_text(doc_bytes):

    dirname = os.path.dirname(__file__)
    output_bytes = BytesIO()
    output_bytes.write(doc_bytes)
    output_bytes.seek(0)
    with open("local_doc_file.docx", "wb") as f:
         f.write(output_bytes.getbuffer())

    path_to_file = dirname + "\local_doc_file.docx"
    hard_coded_path = r"C:\Users\luke_kovar\OneDrive - S&P Global\Documents\My Files\Python\pyCharm_ADO_repos\genaiclo-wordextraction-rest\local_doc_file.docx"
    logging.info(f"path_to_file :: {path_to_file}")
#     dll.word_to_text(hard_coded_path)
    bytes_out = open(hard_coded_path, "rb")
    output_bytes_out = BytesIO()
    output_bytes_out.write(bytes_out.read())
    output_bytes_out.seek(0)
    bytes_out.close()
    os.remove(hard_coded_path)
    return output_bytes_out



