"""
EMEA CLO Document extraction functions for extracting text, definitions and structure from word documents
"""

import logging
import re

from util.extraction_module.configs.base_config import (
    emea_referenced_sections_extraction_regex,
    emea_referenced_sections_start_extraction_regex,
    emea_hyperlink_table_of_content_match_regex
)
from util.extraction_module.configs.extraction_utils import (
    get_by_path,
    delete_by_path, clean_text,
    find_referenced_sections, add_referenced_text,
)

__author__ = "Samuel miller"
__version__ = "0.1.0"
__email__ = "samuel.miller@spglobal.com"
__credits__ = ["S&P Global Ratings", "Ratings Technology: AA CogA", "Samuel Miller"]


def emea_create_single_edited_definition_value_recursively(
        lower_level_sections: dict,
        definition_value: str,
        previously_referenced_sections_string_list: list | None = None
) -> str:
    """
    Create edited definition value where referenced sections are added. This includes recursively finding referenced
    sections within referenced sections.

    :param lower_level_sections: sections dictionary with subsections nested
    :type lower_level_sections: dict
    :param definition_value: definition value which need to be potentially edited
    :type definition_value: str
    :param previously_referenced_sections_string_list: sections that have be queried to avoid infinite recursive loops
    :type previously_referenced_sections_string_list: list | None
    :return: The raw definition value if no referenced sections were found or the definition
    value with referenced sections added.
    :rtype: str
    """
    failed_to_extract_sections = set()

    if previously_referenced_sections_string_list is None:
        previously_referenced_sections_string_list = []

    # Search for referenced sections within definitions values
    edited_definition_value = definition_value
    # If a reference section exists in the text
    if re.search(emea_referenced_sections_extraction_regex,
                 clean_text(definition_value)):
        # Extract sections strings, sections top section numbers and sections headers
        referenced_sections, previously_referenced_sections_string_list = find_referenced_sections(
            definition_value,
            previously_referenced_sections_string_list,
            emea_referenced_sections_extraction_regex,
            emea_referenced_sections_start_extraction_regex
        )

        for (ref_sec_text, ref_sec_top_level, ref_sec_lower_levels_list) in referenced_sections:
            try:
                section_text_dict = {}
                # If in the referenced section there are top level section number and subsection references
                if len(ref_sec_lower_levels_list[:-1]) >= 1 and len(ref_sec_top_level) > 0:
                    referenced_section_lower_level_path = ref_sec_lower_levels_list[:-1]
                    referenced_section_path = [ref_sec_top_level] + [
                        f"({level})" for level in referenced_section_lower_level_path
                    ]
                    section_text_dict = get_by_path(
                        root=lower_level_sections,
                        items=referenced_section_path
                    )
                    # If these specific subsection cannot be found
                    if section_text_dict == {}:
                        # Searching for a path that does not exist creates an empty dictionary
                        # We will delete that dictionary here, so it does not lead improper outputs later
                        delete_by_path(lower_level_sections,
                                       items=referenced_section_path)
                        # If more than one subsection level down is referenced try to find one section up in level
                        if len(referenced_section_lower_level_path) > 1:
                            one_level_up_referenced_lower_level_section_path = ref_sec_lower_levels_list[:-2]
                            one_level_up_referenced_section_path = [ref_sec_top_level] + [
                                f"({level})" for level in one_level_up_referenced_lower_level_section_path
                            ]
                            section_text_dict = get_by_path(root=lower_level_sections,
                                                            items=one_level_up_referenced_section_path)
                            if section_text_dict == {}:
                                failed_to_extract_sections.update([str(referenced_section_path),
                                                                   str(one_level_up_referenced_section_path)])
                                delete_by_path(
                                    lower_level_sections,
                                    items=one_level_up_referenced_section_path
                                )
                        else:
                            entire_section_top_level_path = [ref_sec_top_level]
                            section_text_dict = get_by_path(
                                root=lower_level_sections,
                                items=entire_section_top_level_path
                            )
                            if section_text_dict == {}:
                                failed_to_extract_sections.add(str(ref_sec_text))
                                delete_by_path(lower_level_sections,
                                               items=entire_section_top_level_path)
                            else:
                                # Since the data science team wants all the sections referenced
                                # even if the output is very large, we will return the entire section.
                                # The data science team will work with this large piece of text to find
                                # the info within the edited definitions.
                                pass

                # If the top level number was in brackets and not extract via the ref_sec_top_level
                elif len(ref_sec_lower_levels_list) >= 1 and len(ref_sec_top_level) == 0:
                    ref_sec_top_level = ref_sec_lower_levels_list[0]
                    referenced_section_lower_level_path = ref_sec_lower_levels_list
                    referenced_section_path = [ref_sec_top_level] + [f"({level})" for level in
                                                                     referenced_section_lower_level_path[1:-1]]
                    section_text_dict = get_by_path(root=lower_level_sections,
                                                    items=referenced_section_path)
                    if section_text_dict == {}:
                        failed_to_extract_sections.add(str(referenced_section_path))
                        delete_by_path(
                            lower_level_sections,
                            items=referenced_section_path
                        )
                # Below is for when an entire section is referenced. This will lead to a huge amount of text
                # being added to the output and for this reason currently we simply print an error message.
                # This could be added back in if required.
                elif len(ref_sec_lower_levels_list) == 1 and len(ref_sec_top_level) > 0:
                    entire_section_top_level_path = [ref_sec_top_level]
                    section_text_dict = get_by_path(
                        root=lower_level_sections,
                        items=entire_section_top_level_path
                    )
                    if section_text_dict == {}:
                        failed_to_extract_sections.add(str(entire_section_top_level_path))
                        delete_by_path(
                            lower_level_sections,
                            items=entire_section_top_level_path
                        )
                    else:
                        # Since the data science team wants all the sections referenced
                        # even if the output is very large, we will return the entire section.
                        # The data science team will work with this large piece of text to find
                        # the info within the edited definitions.
                        pass
                else:
                    # If the section is not created in format that is referencable simply output the original definition
                    failed_to_extract_sections.add(str(ref_sec_text))

                edited_definition_value = add_referenced_text(
                    edited_definition_value,
                    section_text_dict,
                    lower_level_sections,
                    previously_referenced_sections_string_list,
                    ref_sec_text,
                    emea_referenced_sections_extraction_regex,
                    emea_create_single_edited_definition_value_recursively
                )

            except Exception as e:
                # If the section is not created in format that is referencable simply output the original definition
                logging.info(f"Failed to extract data for the definition referenced "
                             f"section {ref_sec_text} because of error: {e}")
                failed_to_extract_sections.add(str(ref_sec_text))
                # raise e

    # For debugging purposes to find sections that could be extracted
    # if failed_to_extract_sections:
    #     logging.info(f"Failed to extract sections: {failed_to_extract_sections}")

    return edited_definition_value


def is_toc_start(element_text: str) -> bool:
    """
    Check if the element text indicates the start of the Table of Contents.
    :param element_text: element text
    :type element_text: str
    :return: boolean indicating whether the element text indicates the start of the table of content
    :rtype: bool
    """
    return "table of contents" in element_text.lower()


def is_toc_entry(element_text: str, index: int) -> bool:
    """
    Check if the element text represents a Table of Contents entry.

    :param element_text: element text
    :type element_text: str
    :param index: index of the element text with table of contents
    :type index: int
    :return: boolean indicating if element text is present in the table of contents
    :rtype: bool
    """
    return index > 0 and re.match(emea_hyperlink_table_of_content_match_regex, element_text)
