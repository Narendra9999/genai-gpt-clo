"""
US CLO Document extraction functions for extracting text, definitions and structure from word documents
"""

import logging
import re
import xml.etree.ElementTree as Elem_Tree

import docx
from docx.document import Document
from docx.text.paragraph import Paragraph

from util.extraction_module.configs.base_config import (
    us_referenced_sections_extraction_regex,
    us_referenced_sections_start_extraction_regex,
    us_top_level_section_number_match_regex,
    us_top_level_section_article_number_match_regex, us_tab_match_regex,
    us_toc_section_ending_match_regex, us_hyperlink_xpath, us_word_docx_open_xml_namespace,
    us_word_docx_open_xml_namespace_bracket_enclosed, us_toc_xpath, us_paragraph_xpath, us_paragraph_style_xpath
)
from util.extraction_module.configs.extraction_utils import (
    replace_whitespace_and_strip, get_by_path, delete_by_path, clean_text,
    find_referenced_sections,
    add_referenced_text
)

__author__ = "Samuel miller"
__version__ = "0.1.0"
__email__ = "samuel.miller@spglobal.com"
__credits__ = ["S&P Global Ratings", "Ratings Technology: AA CogA", "Samuel Miller"]


def us_create_single_edited_definition_value_recursively(
        lower_level_sections: dict,
        definition_value: str,
        previously_referenced_sections_string_list: list | None = None
) -> str:
    """
    Create edited definition value where referenced sections are added. This includes recursively finding referenced
    sections within referenced sections.

    :param lower_level_sections: sections dictionary with subsections nested
    :type lower_level_sections: dict
    :param definition_value: definition value which need to be potentially edited
    :type definition_value: str
    :param previously_referenced_sections_string_list: sections that have be queried to avoid infinite recursive loops
    :type previously_referenced_sections_string_list: list | None
    :return: The raw definition value if no referenced sections were found or the definition
    value with referenced sections added.
    :rtype: str
    """
    failed_to_extract_sections = set()

    if previously_referenced_sections_string_list is None:
        previously_referenced_sections_string_list = []

    # Search for referenced sections within definitions values
    edited_definition_value = definition_value

    # If a reference section exists in the text
    if re.search(us_referenced_sections_extraction_regex,
                 clean_text(definition_value)):
        # Extract sections strings, sections top section numbers and sections headers
        referenced_sections, previously_referenced_sections_string_list = find_referenced_sections(
            definition_value,
            previously_referenced_sections_string_list,
            us_referenced_sections_extraction_regex,
            us_referenced_sections_start_extraction_regex
        )

        for (ref_sec_text, ref_sec_top_level, ref_sec_lower_levels_list) in referenced_sections:
            try:
                section_text_dict = {}
                # If in the referenced section there are top level section number and subsection references
                if len(ref_sec_lower_levels_list) >= 1 and len(ref_sec_top_level) > 0:
                    referenced_section_lower_level_path = ref_sec_lower_levels_list
                    referenced_section_path = [ref_sec_top_level] + [
                        f"({level})" for level in referenced_section_lower_level_path
                    ]
                    section_text_dict = get_by_path(
                        root=lower_level_sections,
                        items=referenced_section_path
                    )
                    # If these specific subsection cannot be found
                    if section_text_dict == {}:
                        # Searching for a path that does not exist creates an empty dictionary
                        # We will delete that dictionary here, so it does not lead improper outputs later
                        delete_by_path(lower_level_sections,
                                       items=referenced_section_path)
                        # If more than one subsection level down is referenced try to find one section up in level
                        if len(referenced_section_lower_level_path) > 1:
                            one_level_up_referenced_lower_level_section_path = ref_sec_lower_levels_list[:-1]
                            one_level_up_referenced_section_path = [ref_sec_top_level] + [
                                f"({level})" for level in one_level_up_referenced_lower_level_section_path
                            ]
                            section_text_dict = get_by_path(root=lower_level_sections,
                                                            items=one_level_up_referenced_section_path)
                            if section_text_dict == {}:
                                failed_to_extract_sections.update([str(referenced_section_path),
                                                                   str(one_level_up_referenced_section_path)])
                                delete_by_path(
                                    lower_level_sections,
                                    items=one_level_up_referenced_section_path
                                )
                        else:
                            entire_section_top_level_path = [ref_sec_top_level]
                            section_text_dict = get_by_path(
                                root=lower_level_sections,
                                items=entire_section_top_level_path
                            )
                            if section_text_dict == {}:
                                failed_to_extract_sections.add(str(ref_sec_text))
                                delete_by_path(lower_level_sections,
                                               items=entire_section_top_level_path)
                            else:
                                # Since the data science team wants all the sections referenced
                                # even if the output is very large, we will return the entire section.
                                # The data science team will work with this large piece of text to find
                                # the info within the edited definitions.
                                pass

                # Below is for when an entire section is referenced. This will lead to a huge amount of text
                # being added to the output and for this reason currently we simply print an error message.
                # This could be added back in if required.
                elif len(ref_sec_lower_levels_list) == 0 and ref_sec_text == ref_sec_top_level:
                    entire_section_top_level_path = [ref_sec_top_level]
                    section_text_dict = get_by_path(
                        root=lower_level_sections,
                        items=entire_section_top_level_path
                    )
                    if section_text_dict == {}:
                        failed_to_extract_sections.add(str(entire_section_top_level_path))
                        delete_by_path(
                            lower_level_sections,
                            items=entire_section_top_level_path
                        )
                    else:
                        # Since the data science team wants all the sections referenced
                        # even if the output is very large, we will return the entire section.
                        # The data science team will work with this large piece of text to find
                        # the info within the edited definitions.
                        pass
                else:
                    # If the section is not created in format that is referencable simply output the original definition
                    failed_to_extract_sections.add(str(ref_sec_text))

                edited_definition_value = add_referenced_text(
                    edited_definition_value,
                    section_text_dict,
                    lower_level_sections,
                    previously_referenced_sections_string_list,
                    ref_sec_text,
                    us_referenced_sections_extraction_regex,
                    us_create_single_edited_definition_value_recursively
                )

            except Exception as e:
                # If the section is not created in format that is referencable simply output the original definition
                logging.info(f"Failed to extract data for the definition referenced "
                             f"section {ref_sec_text} because of error: {e}")
                failed_to_extract_sections.add(str(ref_sec_text))
                # raise e

    # For debugging purposes to find sections that could be extracted
    # if failed_to_extract_sections:
    #     logging.info(f"Failed to extract sections: {failed_to_extract_sections}")

    return edited_definition_value


def extract_toc_text_via_docx_xml_xpath(doc: Document) -> dict:
    """
    Extract table of contents text via xml XPath expressions

    :param doc: docx document
    :type doc: docx.document.Document
    :return: dictionary with table of contents text and text style
    :rtype: dict
    """
    root_element = doc._element  # Access the raw XML element of the document
    xml_str = Elem_Tree.tostring(root_element, encoding="unicode")

    # Parse the XML string back into an ElementTree object for easy manipulation
    root = Elem_Tree.fromstring(xml_str)

    namespaces = {
        "w": us_word_docx_open_xml_namespace,  # Define the namespace
    }

    extracted_info = {}  # Dictionary to hold the extracted information

    # Counter to uniquely identify each paragraph
    paragraph_counter = 0

    # Iterate through each w:sdt element in the document
    for sdt in root.iter(f"{us_word_docx_open_xml_namespace_bracket_enclosed}sdt"):
        # Check for a w:docPartObj child with a specific w:docPartGallery value
        docpartobj = sdt.find(us_toc_xpath, namespaces)
        if docpartobj is not None:
            # Iterate through each paragraph (w:p) within the w:sdt
            for p in sdt.findall(us_paragraph_xpath, namespaces):
                paragraph_text = ""  # Initialize an empty string to accumulate text for the current paragraph
                for elem in p.iter():
                    if elem.tag == f"{us_word_docx_open_xml_namespace_bracket_enclosed}t":
                        paragraph_text += elem.text
                    elif elem.tag == f"{us_word_docx_open_xml_namespace_bracket_enclosed}tab":
                        paragraph_text += "\t"

                # Attempt to find the paragraph style
                pstyle = p.find(us_paragraph_style_xpath, namespaces)
                style_val = pstyle.get(
                    f"{us_word_docx_open_xml_namespace_bracket_enclosed}val") if pstyle is not None else None

                # Add the paragraph info to the dictionary
                extracted_info[paragraph_counter] = {
                    "text": paragraph_text,
                    "pStyle": style_val
                }

                paragraph_counter += 1  # Increment the counter after processing each paragraph

    return extracted_info


def process_table_of_contents(extracted_texts: dict) -> set:
    """
    Processes extracted table of content text and style into a main sections set

    :param extracted_texts: Dictionary of extracted table of contents text and style
    :type extracted_texts: dict
    :return: main sections set
    :rtype: set
    """
    previous_two_line_text_section_match = False
    main_section_key_set = set()

    # Preprocess to append None for pStyle of the next paragraph for easy access
    paragraph_styles = [extracted_texts[i]["pStyle"] for i in range(len(extracted_texts))]
    paragraph_styles.append(None)

    # Preprocess to append None for text of the next paragraph for easy access
    paragraph_text = [extracted_texts[i]["text"] for i in range(len(extracted_texts))]
    paragraph_text.append(None)

    for i, (current_text, current_style, next_text, next_style) in enumerate(
            zip(paragraph_text[:-1], paragraph_styles[:-1], paragraph_text[1:], paragraph_styles[1:])):
        current_text_stripped = current_text.strip()
        current_text_section_match = re.findall(
            us_top_level_section_article_number_match_regex,
            current_text_stripped
        )
        current_text_tab_match = re.findall(us_tab_match_regex, current_text_stripped)
        if next_text is not None:
            next_text_stripped = next_text.strip()
            two_line_text_stripped = current_text_stripped + " " + next_text_stripped
            two_line_text_stripped_section_match = re.findall(
                us_top_level_section_article_number_match_regex,
                two_line_text_stripped
            )
            next_text_tab_match = re.findall(us_tab_match_regex, next_text_stripped)
            next_text_section_match = re.findall(
                us_top_level_section_article_number_match_regex,
                next_text_stripped
            )
        else:
            next_text_stripped = None
            two_line_text_stripped = None
            two_line_text_stripped_section_match = None
            next_text_tab_match = None
            next_text_section_match = None

        if None in [
            next_text_stripped,
            two_line_text_stripped,
            two_line_text_stripped_section_match,
            next_text_tab_match,
            next_text_section_match
        ]:
            # Directly add the section based on style and condition
            if len(current_text_section_match) == 1:
                key_to_add = replace_whitespace_and_strip(
                    current_text_section_match[0].strip() if current_text_section_match else
                    current_text_stripped.rpartition("\t")[0])
                main_section_key_set.add(key_to_add)
                previous_two_line_text_section_match = False
            else:
                # Handle any non-standard case where a current_text_stripped is not found to be a full section
                previous_two_line_text_section_match = False
        # Handle two line TOC text accumulation
        elif (
                len(current_text_section_match) != 1
                and
                len(two_line_text_stripped_section_match) == 1
                and
                len(current_text_tab_match) != 0
                and
                len(next_text_tab_match) != 0
                and
                not previous_two_line_text_section_match
                and
                not next_text_section_match

        ):
            key_to_add = replace_whitespace_and_strip(two_line_text_stripped_section_match[0].strip())
            main_section_key_set.add(key_to_add)
            previous_two_line_text_section_match = True
        else:
            # Directly add the section
            if len(current_text_section_match) == 1:
                key_to_add = replace_whitespace_and_strip(
                    current_text_section_match[0].strip() if current_text_section_match else
                    current_text_stripped.rpartition("\t")[0])
                main_section_key_set.add(key_to_add)
                previous_two_line_text_section_match = False
            else:
                # Handle any non-standard case where
                # current_text_stripped is not found to be a full section for extraction
                previous_two_line_text_section_match = False

    return main_section_key_set


def check_for_section_string_start(
        main_section_key_set_final: set,
        docpara: Paragraph,
        bookmarks: dict
) -> list:
    """
    Check if the python docx document paragraph is the start of a main section

    :param main_section_key_set_final: Document main sections text set
    :type main_section_key_set_final: set
    :param docpara: python docx document paragraph object
    :type docpara: docx.text.paragraph.Paragraph
    :param bookmarks: Table of contents bookmark hyperlink metadata dictionary including bookmark anchor and raw
    text
    :type bookmarks: dict
    :return: List of all main sections found in the document paragraph
    :rtype: list
    """
    matched_main_sections = []
    if len(docpara._element.xpath(us_hyperlink_xpath)) > 0:
        if docpara._element.xpath(us_hyperlink_xpath)[0].anchor in bookmarks.keys():
            return matched_main_sections

    toc_section_ending_finder = re.findall(us_toc_section_ending_match_regex, docpara.text)
    text_without_whitespace = replace_whitespace_and_strip(docpara.text, replacement=" ")
    for main_section in main_section_key_set_final:
        section_num_finder = re.findall(us_top_level_section_number_match_regex, main_section)

        if not section_num_finder:
            # Find if paragraph starts with main section header
            if text_without_whitespace.startswith(main_section) and not toc_section_ending_finder:
                matched_main_sections.append(main_section)
        else:
            string_title_no_section_number_with_period = main_section.split(section_num_finder[0])[
                                                             1].strip().rstrip(".") + "."
            # Find if paragraph starts with main section header
            if text_without_whitespace.startswith(
                    string_title_no_section_number_with_period) and not toc_section_ending_finder:
                matched_main_sections.append(main_section)
            elif text_without_whitespace.startswith(main_section) and not toc_section_ending_finder:
                matched_main_sections.append(main_section)

    return matched_main_sections
