"""
Base configuration information for document extraction loaded from config file
"""
import os
import platform
import pathlib
import yaml
# if platform.system() in ["Linux", "Darwin"]:
#     from pythonnet import load
#     load("coreclr")
# import clr
# Get the current file's directory
current_dir = os.path.dirname(os.path.realpath(__file__))

# Add the DLL file reference
# clr.AddReference(os.path.join(current_dir, "myDll.dll"))

# noinspection PyUnresolvedReferences
# from myDll import DllTest


__author__ = "Samuel miller"
__version__ = "0.1.0"
__email__ = "samuel.miller@spglobal.com"
__credits__ = ["S&P Global Ratings", "Ratings Technology: AA CogA", "Samuel Miller"]

current_file_path = str(pathlib.Path(__file__).parent.resolve())

# DLL used for converting word elements for future parsing
# dll = DllTest()

# Load the YAML file
with open(f"{current_file_path}/config.yaml", "r") as file:
    config = yaml.safe_load(file)

# Regex expressions
us_referenced_sections_extraction_regex = config["regex"]["us"]["referenced_sections_extraction_regex"]
us_referenced_sections_start_extraction_regex = config["regex"]["us"]["referenced_sections_start_extraction_regex"]
us_top_level_section_number_match_regex = config["regex"]["us"]["top_level_section_number_match"]
us_top_level_number_match_regex = config["regex"]["us"]["top_level_number_match"]
us_toc_2_top_level_section_number_match_regex = config["regex"]["us"]["toc_2_top_level_section_number_match"]
us_top_level_section_article_number_match_regex = config["regex"]["us"]["top_level_section_article_number_match"]
us_stricter_top_level_section_article_number_match_regex = config["regex"]["us"]["stricter_top_level_section_article_number_match"]
us_top_level_section_article_number_plus_page_number_match_regex = config["regex"]["us"]["top_level_section_article_number_plus_page_number_match"]
us_stricter_top_level_section_article_number_plus_page_number_match_regex = config["regex"]["us"]["stricter_top_level_section_article_number_plus_page_number_match"]
us_tab_match_regex = config["regex"]["us"]["tab_match_regex"]
us_toc_section_ending_match_regex = config["regex"]["us"]["toc_section_ending_match"]

emea_referenced_sections_extraction_regex = config["regex"]["emea"]["referenced_sections_extraction_regex"]
emea_referenced_sections_start_extraction_regex = config["regex"]["emea"]["referenced_sections_start_extraction_regex"]
emea_starting_with_an_number_regex = config["regex"]["emea"]["starting_with_an_integer"]
emea_toc_1_table_of_content_match_regex = config["regex"]["emea"]["toc_1_table_of_content_match"]
emea_hyperlink_table_of_content_match_regex = config["regex"]["emea"]["hyperlink_table_of_content_match"]
emea_numeric_subsection_match_regex = config["regex"]["emea"]["numeric_subsection_match"]
emea_numeric_subsection_characteristics_match_regex = config["regex"]["emea"]["numeric_subsection_characteristics_match"]
emea_plus_sign_match_regex = config["regex"]["emea"]["plus_sign_match"]
emea_alpha_numeric_or_space_only_regex = config["regex"]["emea"]["alpha_numeric_or_space_only"]


both_one_or_more_whitespace_regex = config["regex"]["both"]["one_or_more_whitespace"]
both_one_or_more_spaces_regex = config["regex"]["both"]["one_or_more_spaces"]
both_text_with_parentheses_regex = config["regex"]["both"]["text_within_parentheses_keep_parentheses"]
both_text_within_parentheses_regex = config["regex"]["both"]["text_within_parentheses"]
both_definition_term_extraction_regex = config["regex"]["both"]["definition_term_extraction"]
both_find_subsection_details_regex = config["regex"]["both"]["find_subsection_details"]

#Xpath

us_hyperlink_xpath = config["xpath"]["us"]["hyperlink_xpath"]
us_word_docx_open_xml_namespace = config["xpath"]["us"]["word_docx_open_xml_namespace"]
us_word_docx_open_xml_namespace_bracket_enclosed = "{"+config["xpath"]["us"]["word_docx_open_xml_namespace"]+"}"
us_toc_xpath = config["xpath"]["us"]["toc_xpath"]
us_paragraph_xpath = config["xpath"]["us"]["paragraph_xpath"]
us_paragraph_style_xpath = config["xpath"]["us"]["paragraph_style_xpath"]

emea_r_rapped_xpath = config["xpath"]["emea"]["r_rapped_xpath"]
