"""
Functions shared between emea and us documents
"""
import operator
import re
from collections import Counter
from functools import reduce
from typing import Callable, Any
import warnings

import numpy as np
import pandas as pd
from docx.table import Table

__author__ = "Samuel miller"
__version__ = "0.1.0"
__email__ = "samuel.miller@spglobal.com"
__credits__ = ["S&P Global Ratings", "Ratings Technology: AA CogA", "Samuel Miller"]

from util.extraction_module.configs.base_config import (
    both_one_or_more_whitespace_regex, both_one_or_more_spaces_regex,
    both_definition_term_extraction_regex, both_text_with_parentheses_regex, both_text_within_parentheses_regex,
    both_find_subsection_details_regex
)


# Had to implement this change to source code to pull
# hyperlink emails: https://github.com/python-openxml/python-docx/issues/85#issuecomment-1010150776


def qa_dictionary_files(section_dictionary: dict, all_section_paths: list) -> pd.DataFrame:
    """
    Creates a qa output of the input text and definition extracted file


    :param section_dictionary: sectioned text and definition dictionary
    :type section_dictionary: dict
    :param all_section_paths: all section paths for review
    :type all_section_paths: list
    :return: quality analysis dataframe
    :rtype: pd.DataFrame
    """
    qa_df = pd.DataFrame()
    if section_dictionary["Sections_Data"] == "Failed_to_extract":
        df_row = {"file_name": [section_dictionary["file_name"]], "section": ["Failed_to_extract"],
                  "raw_text_definition_term": ["Failed_to_extract"], "raw_text_definition_value": ["Failed_to_extract"]}
        qa_df = pd.concat([qa_df, pd.DataFrame.from_dict(df_row)])
    else:
        if len(section_dictionary["Sections_Data"]) > 0:
            for total_section_path in all_section_paths:
                if len(get_by_path(section_dictionary, total_section_path + ["Raw_Text_Definitions"])) > 0:
                    for definition_term in get_by_path(section_dictionary,
                                                       total_section_path + ["Raw_Text_Definitions"]).keys():
                        for (raw_text_definition_value, edited_definition_value) in (
                                zip(get_by_path(section_dictionary,
                                                total_section_path + ["Raw_Text_Definitions"] + [definition_term]),
                                    get_by_path(section_dictionary,
                                                total_section_path + ["Edited_Text_Definitions"] + [definition_term])
                                    )
                        ):
                            df_row = {"file_name": [section_dictionary["file_name"]],
                                      "section": ["__".join(total_section_path)],
                                      "raw_text_definition_term": [definition_term],
                                      "raw_text_definition_value": [raw_text_definition_value],
                                      "raw_text_definition_word_count": [len(raw_text_definition_value.split(" "))],
                                      "edited_text_definition_value": [edited_definition_value],
                                      "edited_text_definition_word_count": [len(edited_definition_value.split(" "))]}
                        qa_df = pd.concat([qa_df, pd.DataFrame.from_dict(df_row)])
                else:
                    df_row = {"file_name": [section_dictionary["file_name"]],
                              "section": ["__".join(total_section_path)], "raw_text_definition_term": [np.nan],
                              "raw_text_definition_value": [np.nan], "raw_text_definition_word_count": [np.nan],
                              "edited_text_definition_value": [np.nan], "edited_text_definition_word_count": [np.nan]}
                    qa_df = pd.concat([qa_df, pd.DataFrame.from_dict(df_row)])

        else:
            df_row = {"file_name": [section_dictionary["file_name"]], "section": [np.nan],
                      "raw_text_definition_term": [np.nan], "raw_text_definition_value": [np.nan],
                      "raw_text_definition_word_count": [np.nan], "edited_text_definition_value": [np.nan],
                      "edited_text_definition_word_count": [np.nan]}
            qa_df = pd.concat([qa_df, pd.DataFrame.from_dict(df_row)])

        qa_df["Number_of_Sections_Total"] = len(qa_df["section"].unique())
        qa_df["Number_of_Raw_Text_Definitions_Total"] = len(qa_df["raw_text_definition_term"].unique())
        qa_df["Number_of_Raw_Text_Definitions_Per_Section"] = qa_df.groupby(["section"])[
            "raw_text_definition_term"].transform("count")
        qa_df["Number_of_Raw_Text_Definitions_Per_definition_term"] = qa_df.groupby(["raw_text_definition_term"])[
            "raw_text_definition_value"].transform("count")
    qa_df.sort_values(by=["file_name",
                          "section",
                          "raw_text_definition_term",
                          "edited_text_definition_value",
                          "raw_text_definition_word_count",
                          "edited_text_definition_word_count"], inplace=True)
    qa_df.reset_index(drop=True, inplace=True)
    return qa_df


def add_referenced_text(
        edited_definition_value: str,
        section_text_dict: dict,
        lower_level_sections: dict,
        previously_referenced_sections_string_list: list,
        ref_sec_text: str,
        referenced_sections_extraction_regex: str,
        create_single_edited_definition_value_recursively: Callable[[dict, str, list], str]
) -> str:
    """
    Adds referenced text to the raw definitions text

    :param edited_definition_value: definition value with referenced text added
    :type edited_definition_value: str
    :param section_text_dict: referenced text section found in lower level section dictionary
    :type section_text_dict: dict
    :param lower_level_sections: lower level section dictionary with main sections further broken down into subsections
    :type lower_level_sections: dict
    :param previously_referenced_sections_string_list: previously referenced sections to keep from infinite recursion
    :type previously_referenced_sections_string_list: list
    :param ref_sec_text: referenced section text
    :type ref_sec_text: str
    :param referenced_sections_extraction_regex: Regex to extract referenced sections from definitions strings
    :type referenced_sections_extraction_regex: str
    :param create_single_edited_definition_value_recursively: function for creating single edited definition value
    :type create_single_edited_definition_value_recursively: function for creating single edited definition value
    :return: definition value with referenced text added
    :rtype: str
    """
    # If a section reference was found in the lower_level_sections
    # the sourced dictionary will not be empty
    if section_text_dict != {}:
        # Concat all the found subsections into a string to be added to edited definition
        section_text_dict_text_value_strings = ". ".join(
            [str(item) for sublist in get_recursively(section_text_dict) for item in sublist])
        section_text_dict_text_value_strings = remove_unnecessary_periods(
            section_text_dict_text_value_strings
        )

        # If a referenced section in found within the referenced section text recursively pull
        # the reference section as-well
        if re.search(
                referenced_sections_extraction_regex,
                clean_text(section_text_dict_text_value_strings)
        ):
            section_text_dict_text_value_strings = create_single_edited_definition_value_recursively(
                lower_level_sections,
                section_text_dict_text_value_strings,
                previously_referenced_sections_string_list
            )

        # If referenced text found and ready to be added to the output
        if section_text_dict_text_value_strings != "":
            replacement_text = f". {ref_sec_text}: {section_text_dict_text_value_strings}"
            edited_definition_value = edited_definition_value + replacement_text
            edited_definition_value = remove_unnecessary_periods(edited_definition_value)

    return edited_definition_value


def get_by_path(root: dict, items: list) -> Any:
    """
    Access a nested object in root dictionary by item keys sequence.

    :param root: root dictionary
    :type root: dict
    :param items: list of dict keys
    :type items: list
    :return dictionary path output
    :rtype: dict
    """
    try:
        return reduce(operator.getitem, items, root)
    except KeyError:
        def _recurse(dic: dict, chain: list[str]):
            if len(chain) == 0:
                return
            if len(chain) == 1:
                dic[chain[0]] = {}
                return
            key, *new_chain = chain
            if key not in dic:
                dic[key] = {}
            _recurse(dic[key], new_chain)
            return

        _recurse(root, items)

        return reduce(operator.getitem, items, root)


def delete_by_path(root: dict, items: list) -> dict:
    """
    Recursively removes the specified key and its value from the nested dictionary
    based on the entire path of keys.

    :param root: root dictionary
    :rtype root: dict
    :param items: list of dict keys
    :type items: list
    :return dictionary with path deleted
    :rtype: dict
    """
    if not items:
        return root

    current_key = items[0]
    if current_key in root:
        if len(items) == 1:
            del root[current_key]
        else:
            delete_by_path(root[current_key], items[1:])


def set_by_path(root: dict, items: list, value: Any) -> None:
    """
    Set a value in a nested object in root by item sequence.

    :param root: root dictionary
    :type root: dict
    :param items: list of dict keys
    :type items: list
    :param value: value to be set in path
    :type value: Any
    :return: adds value to the nested items path of the root dictionary
    :rtype: None
    """
    get_by_path(root, items[:-1])[items[-1]] = value


def replace_whitespace_and_strip(string: str, replacement=" ") -> str:
    """
    Replace whitespace in string with replacement text and strip trailing/preceding whitespace

    :param string: string for whitespace to be replaced
    :type string: str
    :param replacement: string whitespace replacement text
    :type replacement: str
    :return: stripped string with whitespace replaced
    :rtype cleaned_string: str
    """
    # Replace all runs of whitespace with a single space
    string = re.sub(both_one_or_more_whitespace_regex, replacement, string)

    # Replace all runs of whitespace with a single space and strip trailing/preceding whitespace
    cleaned_string = re.sub(both_one_or_more_spaces_regex, replacement, string).strip()

    return cleaned_string


def get_recursively(search_dict: dict, field: str = "Text") -> list:
    """
    Takes a dict with nested lists and dicts,
    and searches all dicts for a key of the field
    provided. Append the values of this key to output list.

    :param search_dict: dict to search recursively
    :type search_dict: dict
    :param field: dict key who's values you want to collect
    :type field: str
    :return: list of values with the field as a key in the dict
    :rtype: list
    """
    fields_found = []

    for key, value in search_dict.items():

        if key == field:
            fields_found.append(value)

        elif isinstance(value, dict):
            results = get_recursively(value, field)
            for result in results:
                fields_found.append(result)

        elif isinstance(value, list):
            for item in value:
                if isinstance(item, dict):
                    more_results = get_recursively(item, field)
                    for another_result in more_results:
                        fields_found.append(another_result)

    return fields_found


def remove_unnecessary_periods(text: str) -> str:
    """
    Removes unnecessary periods from string

    :param text: piece of text to be modified
    :type text: str
    :return: modified string with unnecessary periods removed
    :rtype: str
    """
    return text.replace(". .", ".").replace("..", ".")


def clean_text(text) -> str:
    """
    Clean the given text by replacing special quotation marks and trimming whitespace.

    :param text: text to be cleaned
    :type text: str
    :return: cleaned text
    :rtype: str
    """
    return text.replace('”', '"').replace('“', '"').replace(u'\xa0', u' ').strip()


def extract_section_details(section_str: str, referenced_sections_start_extraction_regex: str) -> list:
    """
    Extract details from a section string into a list

    :param section_str: section string
    :type section_str: str
    :param referenced_sections_start_extraction_regex: referenced sections start regex
    :type referenced_sections_start_extraction_regex: str
    :return: list of extracted referenced section details
    [referenced section string, top level section number, subsections in brackets broken into a list]
    :rtype: list
    """
    section_details = [section_str]
    try:
        # Extract the top level section number, ignoring subsections
        section_details.append(
            re.findall(
                referenced_sections_start_extraction_regex,
                re.sub(
                    both_text_within_parentheses_regex,
                    "",
                    section_str
                ).strip())[0])
    except IndexError:
        section_details.append("")  # Use an empty string if the section number is missing

    # Extract subsection bracket data into list and append to section details
    section_details.append(re.findall(both_text_with_parentheses_regex, section_str))

    return section_details


def find_referenced_sections(definition_value: str,
                             previously_referenced_sections: list,
                             referenced_sections_extraction_regex: str,
                             referenced_sections_start_extraction_regex: str) -> tuple[list[list], list]:
    """
    Find and return referenced sections within the given definition value string.

    :param definition_value: definition value
    :type definition_value: str
    :param previously_referenced_sections: previously referenced sections
    :type previously_referenced_sections: list
    :param referenced_sections_extraction_regex: regex pattern for extracting sections references
    :type referenced_sections_extraction_regex: str
    :param referenced_sections_start_extraction_regex: regex pattern for extracting start of sections references
    :type referenced_sections_start_extraction_regex: str
    :return: a tuple of referenced sections and previously reference section
    :rtype: tuple
    """
    cleaned_text = clean_text(definition_value)
    referenced_sections = []
    for match in re.findall(referenced_sections_extraction_regex, cleaned_text):
        if match not in previously_referenced_sections:
            referenced_sections.append(extract_section_details(match, referenced_sections_start_extraction_regex))
            previously_referenced_sections.append(match)
    return referenced_sections, previously_referenced_sections


def add_definitions_to_section_dictionary(sections_dictionary: dict,
                                          total_section_path: list,
                                          definition_term: str,
                                          raw_definition_value: list,
                                          edited_definitions_value: list) -> None:
    """
    Adds raw and reference added edited definitions to sections dictionary

    :param sections_dictionary: dictionary with document extracted text broken down by section
    :type sections_dictionary: dict
    :param total_section_path: key path to section where to save definitions in the sections dictionary
    :type total_section_path: list
    :param definition_term: term to be added to the sections dictionary
    :type definition_term: str
    :param raw_definition_value: raw definition value extracted from document text within specific section
    :type raw_definition_value: list
    :param edited_definitions_value: edited definition value with referenced sections added
    :type edited_definitions_value: list
    :return: Added definitions and edited definitions to sections dictionary
    :rtype: None
    """
    # Add raw definition to section dictionary
    set_by_path(
        root=sections_dictionary,
        items=total_section_path + ["Raw_Text_Definitions"] + [definition_term],
        value=raw_definition_value
    )
    # Add edited reference added definition to section dictionary
    set_by_path(
        root=sections_dictionary,
        items=total_section_path + ["Edited_Text_Definitions"] + [definition_term],
        value=edited_definitions_value
    )


def get_text_by_path(sections_dict: dict, path: list) -> Any:
    """
    Retrieve 'Text' key values from the sections dictionary based on the provided path.

    :param sections_dict: sections dictionary for Text key to be retrieved from
    :type sections_dict: dict
    :param path: key path for Text key to be retrieved from
    :type path: list
    :return: values of Text key from sections dictionary at key path specified in path
    :rtype: Any
    """
    return get_by_path(root=sections_dict, items=path + ["Text"])


def extract_term_and_value(text: str) -> tuple[str | None, str | None]:
    """
    Use regex to find and extract a definition term and its value from the given text.

    :param text: Text to extract definition term and value from
    :type text: Text to extract definition term and value from
    :return: A tuple containing the term and its definition value. The term is a string or None,
             and the definition value is a string or None.
    :rtype: (str | None, str | None)
    """
    cleaned_text = clean_text(text)
    match = re.search(both_definition_term_extraction_regex, cleaned_text)
    if match:
        term = match.group().split('"')[1].strip()
        value = cleaned_text.split(match.group(), 1)[-1].strip()
        return term, value

    return None, None


def update_subsection_metadata(text: str,
                               left_indent: int | None,
                               indentation_levels: list,
                               sections_path: list,
                               index_of_section_indent: int) -> tuple[list, str, int, list]:
    """
    Update the subsection metadata according to the current paragraphs text and indentation

    :param text: paragraphs text
    :type text: str
    :param left_indent: paragraphs left indentation
    :type left_indent: int | None
    :param indentation_levels: indentation list for each of the current levels
    :type indentation_levels: list
    :param sections_path: dictionary key path for the current subsection level
    :type sections_path: list
    :param index_of_section_indent: int index of the current section indent. -1 when it has not been assigned yet
    :type index_of_section_indent: int
    :return: Subsection metadata including updated sections_path, sub_section_value, index_of_section_indent and
    indentation_levels
    :rtype: tuple
    """
    # Find parenthesis enclosed or numeric start of lines to pull subsection keys
    sub_section_keys = re.findall(both_find_subsection_details_regex, text.strip())
    if len(sub_section_keys) > 0:
        sub_section_value = text.strip().split(sub_section_keys[0])[1].strip()
        # If indent is None that simply add to current indent levels values
        if left_indent is None:
            sub_section_value = text
        else:
            try:
                index_of_section_indent = indentation_levels.index(left_indent)
                indentation_levels = indentation_levels[:index_of_section_indent + 1]
                sections_path = sections_path[:index_of_section_indent] + [sub_section_keys[0]]
            # If indent does not exist in indentation levels
            except ValueError:
                # If indent is not None then add indent to indent levels and add section key to path
                indentation_levels.append(left_indent)
                sections_path.append(sub_section_keys[0])
    else:
        # If no subsection keys in line text
        try:
            index_of_section_indent = indentation_levels.index(left_indent)
            indentation_levels = indentation_levels[:index_of_section_indent + 1]
            sections_path = sections_path[:index_of_section_indent + 1]
            sub_section_value = text
        # If indent does not exist in indentation levels
        except ValueError:
            # If indent is None that simply add to current indent levels values
            if left_indent is None:
                sub_section_value = text
            else:
                # If indent is not None then this is a bullet or indented text
                indentation_levels.append(left_indent)
                sections_path.append("Bullets_Or_Indented_Text")
                sub_section_value = text

    return sections_path, sub_section_value, index_of_section_indent, indentation_levels


def append_period_ending_para_to_list(str_para: str, period_at_end_of_str_para_list: list) -> list | list[str]:
    """
    If the string paragraph ends with a period, append to the period at the end of str para list. Otherwise,
    return the period at the end of str para list unchanged.

    :param str_para: paragraph string from document
    :type str_para: str
    :param period_at_end_of_str_para_list: List of text paragraphs that end in a period
    :type period_at_end_of_str_para_list: list
    :return: List of text paragraphs that end in a period with added str paragraph
    if it ends in a period
    :rtype: list | list[str]
    """
    if str_para == "":
        return period_at_end_of_str_para_list
    elif "." == str_para.strip()[-1]:
        return period_at_end_of_str_para_list + [str_para]
    else:
        return period_at_end_of_str_para_list


def split_with_delimiter(string: str, delimiter: str) -> tuple[str, str]:
    """
    Split a string on a delimiter into two parts. It adds the delimiter to the end of the first part. If the delimiter
    is found multiple times, it concats the other parts together with this delimiter to create the second part.

    :param string: string to be split
    :type string: str
    :param delimiter: delimiter to split the string
    :type delimiter: str
    :return: A tuple containing the first part and the second part
    :rtype: tuple[str, str]
    """
    # Split the string using the delimiter
    parts = string.split(delimiter)

    # Check if the string actually contains the delimiter to avoid IndexError
    if len(parts) > 1:
        # Concatenate the delimiter to the first part
        first_part = parts[0] + delimiter
    else:
        # If the delimiter is not found, return the original string
        first_part = string
        second_part = ""
        return first_part, second_part

    # If delimiter exists and splits string, add delimiter
    second_part = delimiter.join(parts[1:])

    return first_part, second_part


def trim_to_sentence(
        text: str,
        max_character_limit: int
) -> str:
    """
    Trim a string to a maximum number of characters. Attempt to trim to a sentence end.

    :param text: text string to trim
    :type text: str
    :param max_character_limit: maximum number of characters to trim to
    :type max_character_limit: int
    :return: string trimmed to maximum number of characters
    :rtype: str
    """

    if len(text) <= max_character_limit:
        return text
    else:
        # Find the first occurrence from right of period or semicolon within
        # max_character_limit number to keep the sentence intact
        max_character_cut_string = text[:max_character_limit]
        period_index = max_character_cut_string.rfind(".")
        semicolon_index = max_character_cut_string.rfind(";")
        # Was a period or semicolon found within the max_character_limit
        if period_index != -1 or semicolon_index != -1:
            # Include the period or semicolon and everything before it
            return max_character_cut_string[:max(period_index, semicolon_index) + 1]
        else:
            # If no character was found, cut at the max character limit and add ... on end
            # to indicate text was trimmed to limit
            return max_character_cut_string[:-3] + "..."


def trim_to_period_ending_paragraph_or_sentence_within_max_character(
        value: str,
        max_characters: int,
        period_at_end_of_str_para_list: list = None
) -> str:
    """
    Split the input string value on a delimiter via paragraphs which end in a period starting with the first
    occurring paragraph in the string value that ends with period. If it cannot find a delimited first part value with
    a character count less than or equal to max_characters, it creates a string from the value to last sentence
    that is withing the max_characters count. By last sentence, it finds the first occurrence from the left of a period
    or semicolon.

    :param value: string value to be split within the max character count
    :type value: str
    :param max_characters: maximum number of characters allowed in the trimmed output string
    :type max_characters: int
    :param period_at_end_of_str_para_list: list of paragraphs within value string that end in a period
    :type period_at_end_of_str_para_list: list
    :return: string value trimmed to within the max character count
    :rtype: str
    """
    if period_at_end_of_str_para_list is not None:
        # period_at_end_of_str_para_list could be flipped with slice [::-1] to pull largest value delimited split
        # allowed but found first instance of period ending paragraph usually houses the entire definitions context
        for delimiter_para in period_at_end_of_str_para_list:
            delimiter_para_first_part, delimiter_para_second_part = split_with_delimiter(value, delimiter_para)
            # If the total number of characters is within the limit, return the first part value
            if len(delimiter_para_first_part) <= max_characters:
                return delimiter_para_first_part
            else:
                continue

    return trim_to_sentence(text=value, max_character_limit=max_characters)


def trim_value_if_needed(value: str,
                         max_characters: int = 20000,
                         period_at_end_of_str_para_list: list | None = None) -> str:
    """
    Trim the input string value if it exceeds the max character count, trimming to the first paragraph ending in a
    period if period_at_end_of_str_para_list is not none or last full sentence within the max character limit

    :param value: value to trim to the max character count
    :type value: str
    :param max_characters: maximum number of characters to trim value input string to
    :type max_characters: int
    :param period_at_end_of_str_para_list: list of paragraph strings within the value that end in a period
    :type period_at_end_of_str_para_list: list | None
    :return: string value trimmed to within the max character count
    :rtype: str
    """
    value = clean_text(value).strip()

    # If the total number of characters is within the limit, return the original value
    if len(value) <= max_characters:
        return value

    # Attempt to trim to sentence if possible
    result = trim_to_period_ending_paragraph_or_sentence_within_max_character(
        value,
        max_characters,
        period_at_end_of_str_para_list
    )

    return result


def create_edited_definition_value(
        sub_sections_dictionary: dict,
        definition_value_list: list,
        create_single_edited_definition_value_recursively_func: Callable[[dict, str, list | None], str]
) -> list:
    """
    Create edited definition values list where referenced sections are added

    :param sub_sections_dictionary: sections dictionary with subsections nested
    :param definition_value_list: definition values list which need to be potentially edited
    :param create_single_edited_definition_value_recursively_func: function to create single edited definition value
    :type create_single_edited_definition_value_recursively_func: Callable[[dict, str, list | None], str]
    :return: The raw definition value if no referenced sections were found or
    the definition value with referenced sections added to string.
    """
    if len(sub_sections_dictionary) == 0:
        return definition_value_list
    else:
        top_level_section = list(sub_sections_dictionary.keys())[0]
        # Nested subsections
        lower_level_sections = sub_sections_dictionary[top_level_section]
        edited_definition_value_list = []

        for definition_value in definition_value_list:
            # Search for referenced sections within definitions values
            edited_definition_value = create_single_edited_definition_value_recursively_func(
                lower_level_sections,
                definition_value
            )

            # Trim edited definitions value to last sentence within max character limit
            edited_definition_value_trimmed = trim_value_if_needed(
                value=edited_definition_value
            )

            edited_definition_value_list.append(edited_definition_value_trimmed)

        return edited_definition_value_list


def add_to_section_dictionary(
        sections_dictionary: dict,
        sections_path: list,
        docpara_text: str,
        docpara_left_indent: int | None,
        all_section_paths: list,
        para_or_tbl: bool,
        tbl_dictionary: dict | None
) -> None:
    """
    Add sections date to sections_dictionary and append new sections paths to all_section_paths list

    :param sections_dictionary: Sections dictionary with extracted text split into sections
    :type sections_dictionary: dict
    :param sections_path: list of dictionary keys to section path where document paragraph text should be added
    :type sections_path: list
    :param docpara_text: str extracted from docx document paragraph object to be added to sections dictionary
    :type docpara_text: str
    :param docpara_left_indent: left indent int extracted from docx document paragraph object, table is currently None
    :type docpara_left_indent: int | None
    :param all_section_paths: list of all section key paths that have been added to sections dictionary
    :type all_section_paths: list
    :param para_or_tbl: True/False differentiating between table & paragraph True = Paragraph False = Table
    :type para_or_tbl: bool
    :param tbl_dictionary: dictionary that holds all tables in a section in dict format
    :type tbl_dictionary: dict | None
    :return: add to sections_dictionary and sections_path from outer scope list without returning anything
    :rtype: None
    """
    # If the section path already exists, append to it
    if get_by_path(root=sections_dictionary, items=["Sections_Data"] + sections_path) != {}:
        current_value_text = get_by_path(root=sections_dictionary,
                                         items=["Sections_Data"] + sections_path + ["Text"])
        current_value_text_left_indent = get_by_path(root=sections_dictionary,
                                                     items=["Sections_Data"] + sections_path + ["Text_Left_Indent"])
        current_raw_table_dictionary = get_by_path(root=sections_dictionary,
                                                   items=["Sections_Data"] + sections_path + ["Raw_Tables"])
        set_by_path(root=sections_dictionary,
                    items=["Sections_Data"] + sections_path + ["Text"],
                    value=current_value_text + [docpara_text])
        set_by_path(root=sections_dictionary,
                    items=["Sections_Data"] + sections_path + ["Text_Left_Indent"],
                    value=current_value_text_left_indent + [docpara_left_indent])

        if not para_or_tbl:
            key = list(tbl_dictionary.keys())[0]
            if key in list(current_raw_table_dictionary.keys()):
                current_raw_table_dictionary[key].append(tbl_dictionary[key][0])
            else:
                current_raw_table_dictionary[key] = tbl_dictionary[key]
            set_by_path(root=sections_dictionary,
                        items=["Sections_Data"] + sections_path + ["Raw_Tables"],
                        value=current_raw_table_dictionary)
    else:
        # If section path does not exist, create it
        all_section_paths.append(["Sections_Data"] + sections_path)
        set_by_path(root=sections_dictionary,
                    items=["Sections_Data"] + sections_path + ["Text"],
                    value=[docpara_text])
        set_by_path(root=sections_dictionary,
                    items=["Sections_Data"] + sections_path + ["Text_Left_Indent"],
                    value=[docpara_left_indent])
        set_by_path(root=sections_dictionary,
                    items=["Sections_Data"] + sections_path + ["Raw_Text_Definitions"], value={})
        set_by_path(root=sections_dictionary,
                    items=["Sections_Data"] + sections_path + ["Edited_Text_Definitions"], value={})
        set_by_path(root=sections_dictionary,
                    items=["Sections_Data"] + sections_path + ["Raw_Tables"], value={})
        if not para_or_tbl:
            set_by_path(root=sections_dictionary,
                        items=["Sections_Data"] + sections_path + ["Raw_Tables"],
                        value=tbl_dictionary)


def create_or_add_to_subsections_dictionary(
        output_dict: dict,
        top_level_section_key: str,
        sections_path: list,
        sub_section_value: str
) -> None:
    """
    Create or add to output subsections dictionary based upon if path is new or already exists in dictionary

    :param output_dict: output subsections dictionary to edit
    :type output_dict: dict
    :param top_level_section_key: dictionary key for the location of the top level section
    :type top_level_section_key: str
    :param sections_path: section path to where to save the subsection string
    :type sections_path: list
    :param sub_section_value: subsection value to save to path
    :type sub_section_value: str
    :return: output dictionary with added value
    :rtype: None
    """
    # If subsection path exists add text to the current subsection text list
    if get_by_path(root=output_dict,
                   items=[top_level_section_key] + sections_path + ["Text"]) != {}:
        current_value_text = get_by_path(root=output_dict,
                                         items=[top_level_section_key] + sections_path + ["Text"])
        set_by_path(root=output_dict, items=[top_level_section_key] + sections_path + ["Text"],
                    value=current_value_text + [sub_section_value])
    else:
        # If subsection path doesn't exist, create subsection and set text to list
        set_by_path(root=output_dict, items=[top_level_section_key] + sections_path + ["Text"],
                    value=[sub_section_value])


def save_definition(
        sections_dict: dict,
        path: list,
        definition_term: str,
        definition_value: str,
        sub_sections_dict: dict,
        period_at_end_of_str_para: list | None,
        create_single_edited_definition_value_recursively_func: Callable[[dict, str, list | None], str]
) -> None:
    """
    Save the extracted definition term and its value into the sections dictionary.

    :param sections_dict: sections dictionary
    :type sections_dict: dict
    :param path: dictionary key path to save definition term and its value into
    :type path: list
    :param definition_term: definition term
    :type definition_term: str
    :param definition_value: definition value
    :type definition_value: str
    :param sub_sections_dict: subsections dictionary to extract referenced text from
    :type sub_sections_dict: dict
    :param period_at_end_of_str_para: list of paragraphs in definition value that end in a period
    :type period_at_end_of_str_para: list | None
    :param create_single_edited_definition_value_recursively_func: Function to added referenced text to
    definition value recursively
    :type create_single_edited_definition_value_recursively_func: Callable[[dict, str, list | None], str]
    :return: Added definitions and edited definitions to sections dictionary
    :rtype: None
    """

    value = trim_value_if_needed(value=definition_value, period_at_end_of_str_para_list=period_at_end_of_str_para)
    if definition_term not in get_by_path(
            root=sections_dict,
            items=path + ["Raw_Text_Definitions"]
    ).keys():
        raw_definition_value = [value]
    else:
        current_value_text = get_by_path(
            root=sections_dict,
            items=path + ["Raw_Text_Definitions"] + [definition_term]
        )
        raw_definition_value = current_value_text + [value]

    add_definitions_to_section_dictionary(
        sections_dict,
        path,
        definition_term,
        raw_definition_value=raw_definition_value,
        edited_definitions_value=create_edited_definition_value(
            sub_sections_dict,
            raw_definition_value,
            create_single_edited_definition_value_recursively_func
        )
    )


def extract_definitions_from_sections(
        sections_dictionary: dict,
        sub_sections_dictionary: dict,
        all_section_paths: list,
        create_single_edited_definition_value_recursively_func: Callable[[dict, str, list | None], str]
) -> None:
    """
    Extracts definitions from sections dictionary and adds them to sections_dictionary along with
    edited definitions that uses the sub_sections_dictionary to add referenced text to the definitions
    :param sections_dictionary: sections dictionary
    :type sections_dictionary: list
    :param sub_sections_dictionary: subsections dictionary to pull references from
    :type sub_sections_dictionary: dict
    :param all_section_paths: all section paths that were added to the sections dictionary
    :type all_section_paths: list
    :param create_single_edited_definition_value_recursively_func: Function to create edited definitions
    :type create_single_edited_definition_value_recursively_func: Callable[[dict, str, list | None], str]
    :return: sections_dictionary with extract definitions and edited definitions added
    :rtype: None
    """
    # After splitting text into sections, find definitions within the text and add to Definitions
    # key within section key
    period_at_end_of_str_para_list = []
    for total_section_path in all_section_paths:
        current_definition_term, current_definition_value = "", ""
        # Iterate through text within section finding definitions via regex patterns and add to
        # section in dictionary
        for str_para in get_text_by_path(sections_dictionary, total_section_path):
            new_definition_term, new_definition_value = extract_term_and_value(str_para)
            # If a definition pattern is found start extracting definition
            if new_definition_term is not None:
                if current_definition_term != "" and current_definition_term != new_definition_term:
                    save_definition(sections_dictionary,
                                    total_section_path,
                                    current_definition_term,
                                    current_definition_value,
                                    sub_sections_dictionary,
                                    period_at_end_of_str_para_list,
                                    create_single_edited_definition_value_recursively_func)
                    period_at_end_of_str_para_list = []
                    current_definition_value = new_definition_value
                    period_at_end_of_str_para_list = append_period_ending_para_to_list(
                        clean_text(current_definition_value), period_at_end_of_str_para_list)
                else:
                    current_definition_value += " " + new_definition_value
                    period_at_end_of_str_para_list = append_period_ending_para_to_list(clean_text(str_para),
                                                                                       period_at_end_of_str_para_list)
                current_definition_term = new_definition_term
            else:
                current_definition_value += " " + clean_text(str_para) if current_definition_term else ""
                period_at_end_of_str_para_list = append_period_ending_para_to_list(clean_text(str_para),
                                                                                   period_at_end_of_str_para_list) if \
                    current_definition_term else []
        if current_definition_term != "":
            save_definition(sections_dictionary,
                            total_section_path,
                            current_definition_term,
                            current_definition_value,
                            sub_sections_dictionary,
                            period_at_end_of_str_para_list,
                            create_single_edited_definition_value_recursively_func)
            period_at_end_of_str_para_list = []


def clean_up_tables_columns(table_dictionary: dict) -> dict:
    """
    :param table_dictionary: a dictionary with tables in it
    :type table_dictionary:dict
    :return cleaned_dict: dict object with cleaned up columns
    :rtype: dict
    """
    # for item in list(table_dictionary.values()):
    cleaned_dict = {}
    for num, item in enumerate(table_dictionary.values()):
        single_table_dict = {}
        key = "table" + str(num)
        c = Counter(item["headers"]).most_common(1)
        pct_of_list = int(c[0][1]) / int(len(item["headers"]))
        if pct_of_list > .5 and len(item["rows"]) > 0:
            single_table_dict["headers"] = item["rows"][0]
            single_table_dict["rows"] = item["rows"][1:]
            cleaned_dict[key] = single_table_dict
        else:
            cleaned_dict[key] = item
    return cleaned_dict


def extract_table_data(table_object: Table) -> pd.DataFrame:
    """
    Takes a table_object and extracts cells and assigns to rows/columns
    :param table_object: Table object from a docx table
    :type table_object: docx table object
    :return: dataframe from table object
    :rtype: pd.dataframe
    """
    rows = [(cell.text for cell in row.cells) for row in table_object.rows]
    columns, rows = list(rows[0]), list(rows[1:])
    # If the table has no rows, return an empty dataframe since still need headers text saved in output
    if rows:
        return pd.DataFrame(columns=columns, data=rows)
    else:
        return pd.DataFrame(columns=columns)


def create_table_dict(df: pd.DataFrame) -> dict:
    """
    Takes a dataframe and converts into json dict output, rearranging columns and column names
    :param df: df to be converted into a json output dict
    :type df: pd.DataFrame
    :return: dict of df object
    :rtype: dict
    """
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        json_dict = df.to_dict(orient="tight")

    columns = ["index", "headers", "rows", "index_names", "column_names"]
    table_dict = dict(zip(columns, list(json_dict.values())))
    del table_dict["index"]
    del table_dict["index_names"]
    del table_dict["column_names"]
    return table_dict


def generate_table_key(paragraph_text: str, index_num: int) -> str:
    """
    Takes most recent paragraph tag before this table to create key of this dict
    :param paragraph_text: most recent paragraph tag in str format
    :type paragraph_text: str
    :param index_num: index position of paragraph/table block in for loop
    :type index_num: int
    :return: str of key for dict of json output
    :rtype: str
    """
    text_key = paragraph_text.strip().split("\n")[-1].strip("\n")
    if len(text_key) < 1:
        text_key = f"generic_table_title_{index_num}"
    return text_key


def format_table_output(table_dict: dict, text_key: str) -> str:
    """
    Takes in a dictionary and key for dictionary and turns into text to be inserted into json output
    :param table_dict: dictionary with column and all rows of one table from docx object
    :type table_dict: dict
    :param text_key: most recent paragraph tag in str format used as key for dict
    :type text_key: str
    :return: str to be inserted into json output 'text' for each section
    :rtype: str
    """
    output_str = f"Table: {text_key}:\n"
    final_header = len(table_dict[text_key][0]["headers"]) - 1
    for num, i in enumerate(table_dict[text_key][0]["headers"]):
        if i:
            i = str(i).replace("\n", "").replace("\t", "")
        if num == final_header:
            output_str += f"{i}\n"
        else:
            output_str += f"{i}\t"
    for num, row in enumerate(table_dict[text_key][0]["rows"]):
        final_row = len(row) - 1
        for rnum, r in enumerate(row):
            if r:
                r = str(r).replace("\n", "").replace("\t", "")
            if rnum == final_row:
                output_str += f"{r}\n"
            else:
                output_str += f"{r}\t"
    return output_str
