"""
Word Table extraction from docx library
"""

from collections import Counter
import logging
import pandas as pd
from docx.table import Table
from docx.text.paragraph import Paragraph
from docx import Document
from io import BytesIO

__author__ = "Luke Kovar"
__version__ = "0.1.0"
__email__ = "luke.kovar@spglobal.com"
__credits__ = ["S&P Global Ratings", "Ratings Technology: AA CogA", "Luke Kovar"]

from util.extraction_module.configs.extraction_utils import extract_table_data, create_table_dict, generate_table_key, format_table_output

logger = logging.getLogger(__name__)


def docx_table_extraction(
        table_object: Table,
        paragraph_text: str,
        final_table_dict: dict,
        index_num: int
) -> tuple[str, dict]:
    """
    Takes a table object from docx, and creates dictionary for it and text str to insert into section text
    :param table_object: dictionary with column and all rows of one table from docx object
    :type table_object: docx table object
    :param paragraph_text: most recent paragraph tag in str format
    :type paragraph_text: str
    :param final_table_dict: dictionary with all tables for a specific section
    :type final_table_dict: dict
    :param index_num: index position of paragraph/table block in for loop
    :type index_num: int
    :return: (str of text to insert into section 'text' | dictionary that has table in dictionary format)
    :rtype: tuple[str, dict]
    """
    df = extract_table_data(table_object)
    table_dict = create_table_dict(df)
    text_key = generate_table_key(paragraph_text, index_num)
    final_table_dict[text_key] = [table_dict]
    output_str = format_table_output(final_table_dict, text_key)
    return output_str, final_table_dict


def docx_table_and_paragraph_extraction(doc_object):
    """
    This function extracts table and turns output into json output from an
    entire docuemnt by iterrating through all paragraph/table blocks

    :param doc_object: doc object that contains all paragraphs/tables from one doc
    :type doc_object: class docx.document.Document
    :return: final_table_dict that returns json output of table
    :rtype: dict
    """
    output_bytes = BytesIO()
    output_bytes.write(doc_object)
    output_bytes.seek(0)
    doc = Document(output_bytes)
    final_table_dict = {}
    previous_columns = ()
    previous_key = ""
    table_num = 1
    paragraph_text = ""
    para_or_table = doc.iter_inner_content()
    for block in para_or_table:
        if isinstance(block, Table):
            table_data = []
            rows = []
            # look into cell.text, get entire value of cell rather than row potentially (if possible)
            for i, row in enumerate(block.rows):
                text = (cell.text for cell in row.cells)
                if i == 0:
                    columns = tuple(text)
                    continue
                rows.append(tuple(text))
            new_df = pd.DataFrame(columns=columns, data=rows)
            new_json_dict = new_df.to_dict(orient="tight")
            new_columns = ["index", "headers", "rows", "index_names", "column_names"]
            updated_dict = dict(zip(new_columns, list(new_json_dict.values())))

            del updated_dict["index"]
            del updated_dict["index_names"]
            del updated_dict["column_names"]
            text_key = paragraph_text.strip().split("\n")[-1]
            final_table_dict[text_key] = updated_dict
            table_num += 1
        elif isinstance(block, Paragraph):
            paragraph_text += "\n" + block.text
        else:
            print("neither")

    return final_table_dict


def clean_up_tables_columns(table_dictionary):
    """
    :param table_dictionary: a dictionary with tables in it
    :type table_dictionary:dict
    :return cleaned_dict: dict object with cleaned up columns
    :rtype: dict
    """
    # for item in list(table_dictionary.values()):
    cleaned_dict = {}
    for num, item in enumerate(table_dictionary.values()):
        single_table_dict = {}
        key = "table" + str(num)
        c = Counter(item["headers"]).most_common(1)
        pct_of_list = int(c[0][1]) / int(len(item["headers"]))  # new logic for majority, keep thinking on this
        # if c[0][1] == len(item['headers']):
        if pct_of_list > .5 and len(item["rows"]) > 0:
            print(item["rows"])
            single_table_dict["headers"] = item["rows"][0]
            single_table_dict["rows"] = item["rows"][1:]
            cleaned_dict[key] = single_table_dict
        else:
            cleaned_dict[key] = item

    return cleaned_dict
