"""
EMEA CLO Document extraction functions for extracting text, definitions and structure from word documents
"""
import os
import re
import time
import docx

from docx.document import Document
from docx.table import Table
from docx.text.paragraph import Paragraph

from util.extraction_module.word_table_extraction import docx_table_extraction
from util.extraction_module.configs.base_config import (
    emea_toc_1_table_of_content_match_regex, emea_r_rapped_xpath,
    emea_numeric_subsection_match_regex, emea_numeric_subsection_characteristics_match_regex,
    emea_plus_sign_match_regex, emea_alpha_numeric_or_space_only_regex, emea_starting_with_an_number_regex
)
from util.extraction_module.configs.extraction_utils_emea import (is_toc_start, is_toc_entry,
                                             emea_create_single_edited_definition_value_recursively)
from util.extraction_module.configs.extraction_utils import (
    replace_whitespace_and_strip,
    add_to_section_dictionary,
    extract_definitions_from_sections, update_subsection_metadata, create_or_add_to_subsections_dictionary
)

from util import logger
logger = logger.getlogger()

def extract_table_of_contents_and_header_styles(
        doc: Document,
        eligibility_criteria_header_text: str
) -> tuple[set, str]:
    """
    Extract the main section headers from the table of contents and eligibility criteria header style
    :param doc: docx document
    :type doc: docx.document.Document
    :param eligibility_criteria_header_text: text of the eligibility criteria header
    :type eligibility_criteria_header_text: str
    :return: Tuple containing the main section headers and eligibility criteria header text style
    :rtype: tuple[set, str]
    """
    eligibility_criteria_text_style = "Not Assigned"
    main_section_key_set = set()
    for idx, docpara in enumerate(doc.paragraphs):
        # Extract the eligibility_criteria text style if assigned for subsection extraction later
        if eligibility_criteria_header_text == docpara.text.strip() and not docpara.runs[0].italic:
            eligibility_criteria_text_style = docpara.style.name

        table_of_content_finder = re.findall(emea_toc_1_table_of_content_match_regex, docpara.text)
        # Extract main sections from the table of contents of the Word doc
        if table_of_content_finder and "toc 1" in docpara.style.name:
            main_section_key_set.add(replace_whitespace_and_strip(docpara.text.split("\t")[0]))

    return main_section_key_set, eligibility_criteria_text_style


def extract_hyperlink_table_of_contents(doc: Document, main_section_keys: set) -> set:
    """
    Extracts hyperlink-based Table of Contents entries from `doc` into `main_section_keys`.
    :param doc: docx document object
    :type doc: Document
    :param main_section_keys: main sections of document
    :type main_section_keys: set
    :return: update main sections of the document
    :rtype: set
    """
    if not main_section_keys:
        toc_started = False
        saving_toc = False
        entry_index = 0
        previous_text = ""

        # extract body elements
        body_elements = doc._body._body
        # extract those wrapped in <w:r> tag
        text_elements = body_elements.xpath(emea_r_rapped_xpath)

        for element in text_elements:
            element_text = element.text

            if is_toc_start(element_text):
                toc_started = True
                continue

            if toc_started and element_text == "\t":
                saving_toc = True

            if saving_toc:
                if entry_index == 0:
                    main_section_keys.add(replace_whitespace_and_strip(previous_text))
                    entry_index += 1
                else:
                    if is_toc_entry(element_text, entry_index):
                        toc_entry = replace_whitespace_and_strip(element_text)
                        if toc_entry not in main_section_keys:
                            main_section_keys.add(toc_entry)
                        else:
                            break
            previous_text = element_text

    return main_section_keys


def extract_top_level_sections(
        doc: Document,
        sections_dictionary: dict,
        main_section_key_set: set,
        eligibility_criteria_text_style: str
) -> list:
    """
    Extract text from the docx document into top level sections added to the outer scope sections_dictionary along
    with all section paths found into a list of lists

    :param doc: docx document
    :type doc: docx.document.Document
    :param sections_dictionary: Main dictionary where text, sections and definitions will be houses from document
    extraction.
    :type sections_dictionary: dict
    :param main_section_key_set: Set of all main sections found in document
    :type main_section_key_set: set
    :param eligibility_criteria_text_style: eligibility criteria text style
    :type eligibility_criteria_text_style: str
    :return: Append to sections_dictionary in the outer scope and create all_section_paths list of list which
    contains all dictionary keys section paths
    :rtype: list
    """
    index_of_main_sections = 0
    all_section_paths = []
    current_indent_list = [0]
    sections_path = ["Initial_Section"]
    main_top_level_section_style = "un_assigned"
    table_title_text = ""
    final_table_dict = {}
    # Iterate through word document paragraphs text, finding sections then adding text to sections
    for idx, para_table in enumerate(doc.iter_inner_content()):
        if isinstance(para_table, Table):
            test_output_str, final_table_dict = docx_table_extraction(para_table, table_title_text,
                                                                      final_table_dict, idx)
            table_title_text = ""
            add_to_section_dictionary(sections_dictionary, sections_path, test_output_str, None, all_section_paths,
                                      False,
                                      final_table_dict)
        elif isinstance(para_table, Paragraph):
            table_title_text += "\n" + para_table.text
            # If paragraph left_indent number exists update indent list and section path accordingly
            try:
                if para_table.paragraph_format.left_indent:
                    index_of_section_indent = current_indent_list.index(para_table.paragraph_format.left_indent)
                    current_indent_list = current_indent_list[:index_of_section_indent + 1]
                    sections_path = sections_path[:index_of_section_indent + 1]
            # if left indent exists but is not in current_indent_list
            except ValueError:
                pass

            # Find if paragraph is a main section header
            intersection_main_sections = main_section_key_set.intersection(
                {replace_whitespace_and_strip(para_table.text, replacement=" ")})

            # If first main section
            if intersection_main_sections and index_of_main_sections < 1:
                # Remove section header from main section list to make sure not used twice
                main_section_key_set.remove(list(intersection_main_sections)[0])
                main_section_key = replace_whitespace_and_strip(para_table.text)
                sections_path = [main_section_key]
                current_indent_list = [para_table.paragraph_format.left_indent]
                main_top_level_section_style = para_table.style.name
                index_of_main_sections += 1

            # If not first main section
            elif intersection_main_sections and index_of_main_sections >= 1:
                if main_top_level_section_style == para_table.style.name:
                    main_section_key_set.remove(list(intersection_main_sections)[0])
                    main_section_key = replace_whitespace_and_strip(para_table.text)
                    sections_path = [main_section_key]
                    current_indent_list = [para_table.paragraph_format.left_indent]
                    index_of_main_sections += 1

            # If not a main section search if it is numeric subsection
            elif re.findall(emea_numeric_subsection_match_regex, para_table.text):
                # Review if paragraph has subsection format characteristics
                if (
                        (len(re.findall(emea_numeric_subsection_characteristics_match_regex,
                                        para_table.text.split(re.findall(
                                            emea_numeric_subsection_match_regex,
                                            para_table.text
                                        )[0]
                                                              )[1]
                                        )
                             ) == 0)
                        and
                        ("toc" not in para_table.style.name)
                        and
                        (len(
                            re.findall(
                                emea_plus_sign_match_regex,
                                para_table.text.split(
                                    re.findall(
                                        emea_numeric_subsection_match_regex,
                                        para_table.text
                                    )[0]
                                )[1]
                            )
                        ) == 0)
                        and
                        para_table.paragraph_format.left_indent
                ):
                    # Add subsection to current_indent_list and sections_path
                    sub_section_key = replace_whitespace_and_strip(para_table.text)
                    try:
                        index_of_section_indent = current_indent_list.index(para_table.paragraph_format.left_indent)
                        # Subsection level is stopped at level 3 since it is not extractable past this level
                        if len(sections_path[:index_of_section_indent] + [sub_section_key]) < 3:
                            # If left indent exists in index_of_section_indent
                            current_indent_list = current_indent_list[:index_of_section_indent + 1]
                            sections_path = sections_path[:index_of_section_indent] + [sub_section_key]
                    except ValueError:
                        # Subsection level is stopped at level 3 since it is not extractable past this level
                        if len(sections_path + [sub_section_key]) < 3:
                            # If subsection does not exist with this indent, add newly to list
                            current_indent_list.append(para_table.paragraph_format.left_indent)
                            sections_path.append(sub_section_key)

            # If not a main section, nor numeric subsection, search if paragraph style is
            # same as eligibility criteria subsection header text style
            elif para_table.style.name == eligibility_criteria_text_style:
                # Add subsection to current_indent_list and sections_path if it is only alpa numeric or space
                if len(re.findall(emea_alpha_numeric_or_space_only_regex, para_table.text)):
                    sub_section_key = replace_whitespace_and_strip(para_table.text)
                    indent = 1
                    try:
                        index_of_section_indent = current_indent_list.index(indent)
                        # Subsection level is stopped at level 3 since it is not extractable past this level
                        if len(sections_path[:index_of_section_indent] + [sub_section_key]) < 3:
                            # If left indent exists in index_of_section_indent
                            current_indent_list = current_indent_list[:index_of_section_indent + 1]
                            sections_path = sections_path[:index_of_section_indent] + [sub_section_key]
                    except ValueError:
                        # Subsection level is stopped at level 3 since it is not extractable past this level
                        if len(sections_path + [sub_section_key]) < 3:
                            # If subsection does not exist with this indent, add newly to list
                            current_indent_list.append(indent)
                            sections_path.append(sub_section_key)

            # If the paragraph is not a section nor a subsection added placeholder pass statement for review
            else:
                pass
            add_to_section_dictionary(sections_dictionary, sections_path, para_table.text,
                                      para_table.paragraph_format.left_indent, all_section_paths, True, None)
        else:
            pass
    return all_section_paths


def create_emea_lower_level_terms_conditions_sections(sections_dictionary: dict) -> dict:
    """
    Take sections dictionary and output terms and conditions section dictionary with subsections nested for
    emea documents

    :param sections_dictionary: sections dictionary
    :type sections_dictionary: dict
    :return: terms and conditions section with subsections nested in dictionary
    :rtype: dict
    """

    output_dict = {}
    index_of_section_indent = -1
    # Identify the specific key(s) for "Terms and Conditions" sections
    terms_conditions_keys = [key for key in sections_dictionary["Sections_Data"].keys() if
                             "terms and conditions" in key.lower()]

    # Validate there's exactly one matching section
    if len(terms_conditions_keys) == 0:
        logger.info(f"Could not find terms and conditions subsections since no section had a "
                     f"lowercase title of terms and conditions.")
        return output_dict
    if len(terms_conditions_keys) > 1:
        raise (
            ValueError(f"terms_conditions_keys must find 1 singular key for lower level data "
                       f"extraction of terms and conditions section")
        )

    terms_conditions_section_key = terms_conditions_keys[0]
    terms_conditions_dict = sections_dictionary["Sections_Data"][terms_conditions_section_key]
    for terms_condition_section in list(terms_conditions_dict):
        if terms_condition_section in ["Text", "Text_Left_Indent", "Raw_Text_Definitions",
                                       "Edited_Text_Definitions", "Raw_Tables"]:
            continue

        indentation_levels, sections_path = [], []
        for idx, (text, left_indent) in enumerate(
                zip(terms_conditions_dict[terms_condition_section]["Text"],
                    terms_conditions_dict[terms_condition_section]["Text_Left_Indent"])
        ):
            if idx == 0:
                # Extract only the numeric value of the top level section for easier indexing of conditions
                sections_path = [re.findall(emea_starting_with_an_number_regex, replace_whitespace_and_strip(text))[0]]
                indentation_levels = [left_indent]
                sub_section_value = text
            else:
                (sections_path,
                 sub_section_value,
                 index_of_section_indent,
                 indentation_levels) = update_subsection_metadata(
                    text,
                    left_indent,
                    indentation_levels,
                    sections_path,
                    index_of_section_indent
                )

            create_or_add_to_subsections_dictionary(
                output_dict,
                terms_conditions_section_key,
                sections_path,
                sub_section_value
            )

    return output_dict


def extract_emea_docx_clo_sections_definitions(word_doc_filepath: str) -> tuple:
    """
    Extract text info broken down by section and definitions from CLO EMEA docx files into dictionary

    :param word_doc_filename: word doc filename that needs text/definition extraction
    :type word_doc_filename: str
    :param word_doc_bytes: word doc bytes that need text/definition extraction
    :type word_doc_bytes: IO[bytes]
    :return: extract text dictionary
    :return: List of all section path lists
    """
    start_time = time.time()
    logger.info(f"\nExtracting text from: {word_doc_filepath}")
    word_doc_filename = os.path.basename(word_doc_filepath)
    try:
        # Parse docx into memory via docx library for text extraction
        doc = docx.Document(word_doc_filepath)
        # Create sections_dictionary to add extracted sectioned text and definitions
        sections_dictionary = {"file_name": word_doc_filename, "Sections_Data": {}}

        # Use regex and python docx styles to extract ToC headers along with Eligibility Criteria header text style
        main_section_key_set, eligibility_criteria_text_style = extract_table_of_contents_and_header_styles(
            doc,
            eligibility_criteria_header_text="Eligibility Criteria"
        )

        # If the table of contents is in hyperlink format python docx cannot extract text
        # For this reason, use xpath to manually extract tab of contents via xml elements
        # if no main sections are found from the above function
        main_section_key_set = extract_hyperlink_table_of_contents(doc, main_section_key_set)

        # Log if no main sections found for future review
        if len(main_section_key_set) == 0:
            logger.info(f"No main sections found in the document: {word_doc_filename}")

        # Extract top level sections text to allow for future sectioning of text in output dictionary
        # Sections_dictionary is appended to within the below function
        all_section_paths = extract_top_level_sections(
            doc,
            sections_dictionary,
            main_section_key_set,
            eligibility_criteria_text_style
        )

        # Create terms and conditions lower level subsection dictionary for definition referenced text to be added
        # to edited definitions
        try:
            terms_conditions_sub_sections_dictionary = create_emea_lower_level_terms_conditions_sections(
                sections_dictionary
            )
        except Exception as e:
            logger.info(f"Failed to extract terms_conditions_sub_sections_dictionary "
                         f"based on the following error: {e}")
            terms_conditions_sub_sections_dictionary = {}

        if len(terms_conditions_sub_sections_dictionary) == 0:
            logger.info(f"No terms and conditions sub-sections found for file {word_doc_filename}. "
                         "For this reason the edited definition will be identical to the original definitions")

        # Add raw Terms and Conditions Subsections dictionary into lower level of sections dictionary
        sections_dictionary["Sections_Data"][
            "Extracted_Subsections"] = terms_conditions_sub_sections_dictionary

        # Extract definitions from top level sections_dictionary and then create edited definitions
        # from referenced text found in terms_conditions_sub_sections_dictionary
        extract_definitions_from_sections(
            sections_dictionary,
            terms_conditions_sub_sections_dictionary,
            all_section_paths,
            emea_create_single_edited_definition_value_recursively
        )

    except Exception as e:
        logger.error(f"Found exception for doc {word_doc_filepath}")
        logger.error(e)
        sections_dictionary = {"file_name": word_doc_filename,
                               "Sections_Data": None}

    if sections_dictionary['Sections_Data'] is not None:
        logger.info(f"Successfully extracted {word_doc_filepath}")

    end_time = time.time()
    elapsed_time = end_time - start_time
    logger.info(f"Total time for extract_us_docx_clo_sections_definitions function: {elapsed_time} seconds")

    return sections_dictionary
