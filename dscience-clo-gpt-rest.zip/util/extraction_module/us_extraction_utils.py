"""
US CLO Document extraction functions for extracting text, definitions and structure from word documents
"""
import os
import re
import time
import docx

from docx.document import Document
from docx.table import Table
from docx.text.paragraph import Paragraph

from util.extraction_module.word_table_extraction import docx_table_extraction
from util.extraction_module.configs.base_config import (
    us_hyperlink_xpath, us_top_level_section_article_number_plus_page_number_match_regex,
    us_stricter_top_level_section_article_number_plus_page_number_match_regex,
    us_stricter_top_level_section_article_number_match_regex, us_toc_2_top_level_section_number_match_regex,
    us_top_level_section_article_number_match_regex, us_top_level_section_number_match_regex,
    us_top_level_number_match_regex
)
from util.extraction_module.configs.extraction_utils import (
    replace_whitespace_and_strip, get_by_path, set_by_path, add_to_section_dictionary,
    extract_definitions_from_sections, update_subsection_metadata, create_or_add_to_subsections_dictionary
)
from util.extraction_module.configs.extraction_utils_us import (
    extract_toc_text_via_docx_xml_xpath, process_table_of_contents,
    check_for_section_string_start, us_create_single_edited_definition_value_recursively
)

from util import logger

logger = logger.getlogger()

def extract_docx_toc_from_docpartgallery_xpath_tag(doc: Document) -> set:
    """
    Extract the main sections from table of contents of a docx via the open xml using xpath queries

    :param doc: docx Document
    :type doc: docx.document.Document
    :return: set of main sections from table of contents of a docx
    :rtype: set
    """

    extracted_table_of_contents_texts = extract_toc_text_via_docx_xml_xpath(doc)
    process_table_of_contents_main_section_key_set = process_table_of_contents(extracted_table_of_contents_texts)

    return process_table_of_contents_main_section_key_set


def extract_table_of_contents_sections_regex_style_and_bookmarks(doc: Document) -> tuple[set, dict]:
    """
    Extract table of contents sections via regex, text style and bookmark hyperlinks tags from a Word docx
    :param doc: docx document
    :type doc: docx.document.Document
    :return: tuple of table of
    :rtype: tuple[set, dict]
    """
    main_section_key_set = set()
    bookmarks = {}
    for idx, docpara in enumerate(doc.paragraphs):
        # Find paragraphs that are hyperlinks
        hyperlinks_found_in_paragragh = docpara._element.xpath(us_hyperlink_xpath)

        # Find paragraphs that loosely fit a table of contents regex pattern for further toc styling review
        table_of_content_finder = re.findall(
            us_top_level_section_article_number_plus_page_number_match_regex,
            docpara.text)

        # Find paragraphs that fit a very strict table of contents regex
        stricter_table_of_content_finder = re.findall(
            us_stricter_top_level_section_article_number_plus_page_number_match_regex,
            docpara.text)

        if len(stricter_table_of_content_finder) > 0:
            if idx < 600:
                section_match = re.findall(
                    us_stricter_top_level_section_article_number_match_regex,
                    docpara.text)
                main_section_key_set.add(replace_whitespace_and_strip(section_match[0].strip()))
            if idx >= 600:
                logger.info(
                    f"Please review paragraph idx >= 600 table_of_content_finder: {stricter_table_of_content_finder} "
                    f"||| paragraph_index: {idx}. "
                    f"This table of contents text will not be extracted as it is too far into the document")

        # Extract main sections from the table of contents of the Word doc
        if table_of_content_finder and "toc 1" in docpara.style.name:
            main_section_key_set.add(replace_whitespace_and_strip(docpara.text.rpartition("\t")[0]))
        # Extract main sections from the table of contents of the Word doc
        elif table_of_content_finder and "toc 2" in docpara.style.name:
            section_match = re.findall(
                us_toc_2_top_level_section_number_match_regex, docpara.text.strip())
            main_section_key_set.add(replace_whitespace_and_strip(section_match[0].strip()))

        elif hyperlinks_found_in_paragragh:
            for single_hyperlink_element in hyperlinks_found_in_paragragh:
                if single_hyperlink_element.anchor:
                    table_of_content_finder = re.findall(
                        us_top_level_section_article_number_plus_page_number_match_regex,
                        single_hyperlink_element.text)
                    if len(table_of_content_finder) == 1:
                        # If the section path already exists, append to it
                        if get_by_path(root=bookmarks,
                                       items=[single_hyperlink_element.anchor, "bookmark_anchor_text"]) != {}:
                            current_bookmark_text = get_by_path(root=bookmarks, items=[single_hyperlink_element.anchor,
                                                                                       "bookmark_anchor_text"])
                            set_by_path(root=bookmarks, items=[single_hyperlink_element.anchor, "bookmark_anchor_text"],
                                        value=current_bookmark_text + [single_hyperlink_element.text])
                        else:
                            # If section path does not exist, create it
                            set_by_path(root=bookmarks, items=[single_hyperlink_element.anchor, "bookmark_anchor_text"],
                                        value=[single_hyperlink_element.text])
                    elif len(table_of_content_finder) == 0:
                        pass
                    else:
                        raise Exception(f"Bookmark {single_hyperlink_element.anchor} had more than one "
                                        f"table of content section found. Please review above logic in code.")

    for bookmark_name in bookmarks.keys():
        joined_bookmark_archor_text = " ".join(bookmarks[bookmark_name]["bookmark_anchor_text"])
        section_match = re.findall(us_top_level_section_article_number_match_regex,
                                   joined_bookmark_archor_text.strip())
        if section_match:
            main_section_key_set.add(replace_whitespace_and_strip(section_match[0].strip()))

    return main_section_key_set, bookmarks


def extract_text_into_top_level_sections(
        doc: Document,
        sections_dictionary: dict,
        main_section_key_set_final: set,
        bookmarks: dict
) -> list:
    """
    Extract text from the docx document into top level sections added to the outer scope sections_dictionary along
    with all section paths found into a list of lists

    :param doc: docx document
    :type doc: docx.document.Document
    :param sections_dictionary: Main dictionary where text, sections and definitions will be houses from document
    extraction.
    :type sections_dictionary: dict
    :param main_section_key_set_final: Set of all main sections found in document
    :type main_section_key_set_final: set
    :param bookmarks: Table of contents bookmark hyperlink metadata dictionary including bookmark anchor and raw
    text
    :type bookmarks: dict
    :return: Append to sections_dictionary in the outer scope and create all_section_paths list of list which
    contains all dictionary keys section paths
    :rtype: list
    """
    all_section_paths = []
    current_indent_list = [0]
    sections_path = ["Initial_Section"]
    table_title_text = ""

    # Iterate through word document paragraphs text, finding sections then adding text to sections
    for idx, para_table in enumerate(doc.iter_inner_content()):
        final_table_dict = {}
        if isinstance(para_table, Table):
            test_output_str, final_table_dict = docx_table_extraction(para_table, table_title_text,
                                                                      final_table_dict, idx)
            table_title_text = ""
            add_to_section_dictionary(sections_dictionary, sections_path, test_output_str, None, all_section_paths,
                                      False, final_table_dict)
        elif isinstance(para_table, Paragraph):
            table_title_text += "\n" + para_table.text
            # If paragraph left_indent number exists update indent list and section path accordingly
            try:
                if para_table.paragraph_format.left_indent:
                    index_of_section_indent = current_indent_list.index(para_table.paragraph_format.left_indent)
                    current_indent_list = current_indent_list[:index_of_section_indent + 1]
                    sections_path = sections_path[:index_of_section_indent + 1]
            # if left indent exists but is not in current_indent_list
            except ValueError:
                pass

            # Find if paragraph includes a main section header
            intersection_main_sections = check_for_section_string_start(main_section_key_set_final, para_table,
                                                                        bookmarks)

            # If first main section
            if len(intersection_main_sections) == 1:
                # Remove section header from main section set to make sure not used twice
                main_section_key_set_final.remove(intersection_main_sections[0])
                sections_path = [intersection_main_sections[0]]
                current_indent_list = [para_table.paragraph_format.left_indent]
            elif len(intersection_main_sections) > 1:
                logger.info(f"More than one main section found for paragraph. "
                             f"Make sure to fix logic moving forwards. "
                             f"Will use first found section.")
                # Remove section header from main section set to make sure not used twice
                main_section_key_set_final.remove(intersection_main_sections[0])
                sections_path = [intersection_main_sections[0]]
                current_indent_list = [para_table.paragraph_format.left_indent]
            add_to_section_dictionary(sections_dictionary, sections_path, para_table.text,
                                      para_table.paragraph_format.left_indent, all_section_paths, True, None)
        else:
            pass
    return all_section_paths


def create_lower_level_sections(sections_dictionary: dict) -> dict:
    """
    Take sections dictionary and output subsections dictionary which breaks the sections dictionary into
    subsections such as level lists

    :param sections_dictionary: sections dictionary
    :return: sections dictionary with subsections nested in dictionary
    """

    output_dict = {}
    index_of_section_indent = -1
    sections_dictionary_section_data = sections_dictionary["Sections_Data"]
    for section_data_section in list(sections_dictionary_section_data):
        if (
                section_data_section not in ["Text",
                                             "Text_Left_Indent",
                                             "Raw_Text_Definitions",
                                             "Edited_Text_Definitions",
                                             "Raw_Tables"]
                and
                re.findall(us_top_level_section_number_match_regex, section_data_section)
        ):
            indentation_levels = []
            sections_path = []
            for idx, (text, left_indent) in enumerate(
                    zip(sections_dictionary_section_data[section_data_section]["Text"],
                        sections_dictionary_section_data[section_data_section]["Text_Left_Indent"])
            ):
                if idx == 0:
                    # Extract the top level section for easier indexing in future
                    sections_path = [
                        re.findall(
                            us_top_level_section_number_match_regex,
                            section_data_section
                        )[0]
                    ]
                    if re.findall(us_top_level_number_match_regex, sections_path[0]):
                        sections_path[0] = "Section " + sections_path[0]
                    indentation_levels = [left_indent]
                    sub_section_value = text
                else:
                    (sections_path,
                     sub_section_value,
                     index_of_section_indent,
                     indentation_levels) = update_subsection_metadata(
                        text,
                        left_indent,
                        indentation_levels,
                        sections_path,
                        index_of_section_indent
                    )

                create_or_add_to_subsections_dictionary(
                    output_dict,
                    "Section_Data",
                    sections_path,
                    sub_section_value
                )

    return output_dict


def extract_us_docx_clo_sections_definitions(
        word_doc_filepath: str
) -> tuple:
    """
    Extract text info broken down by section and definitions from CLO US docx files into dictionary

    :param word_doc_filename: word doc filename that needs text/definition extraction
    :type word_doc_filename: str
    :param word_doc_bytes: word doc bytes that need text/definition extraction
    :type word_doc_bytes: IO[bytes]
    :return: extract text dictionary
    :return: List of all section path lists
    """
    start_time = time.time()
    logger.info(f"\nExtracting text from: {word_doc_filepath}")
    word_doc_filename = os.path.basename(word_doc_filepath)
    try:
        # Parse docx into memory via docx library for text extraction
        doc = docx.Document(word_doc_filepath)
        # Create sections_dictionary to add extracted sectioned text and definitions
        sections_dictionary = {"file_name": word_doc_filename, "Sections_Data": {}}

        # Pull table of contents sections via a mixture of regex, styling, xml bookmark tags
        (main_section_key_set_initial_pull,
         bookmarks) = extract_table_of_contents_sections_regex_style_and_bookmarks(doc)

        # Extract table of contents from xpath via xml tag w:docPartObj//w:docPartGallery[@w:val="Table of Contents"]
        process_table_of_contents_main_section_key_set = extract_docx_toc_from_docpartgallery_xpath_tag(doc)

        # Union current main sections found with the extracted table of contents sections
        main_section_key_set_final = main_section_key_set_initial_pull.union(
            process_table_of_contents_main_section_key_set)

        # Log if no main sections found for future review
        if len(main_section_key_set_final) == 0:
            logger.info(f"No main sections found in the document: {word_doc_filename}")

        # Extract top level sections text to allow for future sectioning of text in output dictionary
        # Sections_dictionary is appended to within the below function
        all_section_paths = extract_text_into_top_level_sections(
            doc,
            sections_dictionary,
            main_section_key_set_final,
            bookmarks
        )

        # Create lower level subsection dictionary to allow for definition referenced text to be added
        # to edited definitions
        try:
            sub_sections_dictionary = create_lower_level_sections(sections_dictionary)
        except Exception as e:
            logger.info(f"Failed to extract subsection dictionary based on the following error: {e}")
            sub_sections_dictionary = {}
            # raise e

        if len(sub_sections_dictionary) == 0:
            logger.info(f"No sub-sections found for file {word_doc_filename}. "
                         "For this reason the edited definition will be identical to the original definitions")

        # Add raw subsections dictionary into lower level of sections dictionary
        sections_dictionary["Sections_Data"]["Extracted_Subsections"] = sub_sections_dictionary

        # Extract definitions from top level sections_dictionary and then create edited definitions
        # from referenced text found in sub_sections_dictionary
        extract_definitions_from_sections(
            sections_dictionary,
            sub_sections_dictionary,
            all_section_paths,
            us_create_single_edited_definition_value_recursively
        )

    except Exception as e:
        logger.error(f"Found exception for doc {word_doc_filepath}")
        logger.error(e)
        sections_dictionary = {"file_name": word_doc_filename,
                               "Sections_Data": None}

    if sections_dictionary['Sections_Data'] is not None:
        logger.info(f"Successfully extracted {word_doc_filepath}")

    end_time = time.time()
    elapsed_time = end_time - start_time
    logger.info(f"Total time for extract_us_docx_clo_sections_definitions function: {elapsed_time} seconds")

    return sections_dictionary