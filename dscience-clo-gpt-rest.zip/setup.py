"""The setup script."""
from os import path
from setuptools import find_packages, setup

setup_requirements = []
install_requirements = []


test_requirements = ['pytest>=3', ]
here = path.abspath(path.dirname(__file__))

# Get the long description from the README file
with open(path.join(here, 'README.md')) as f:
    long_description = f.read()
setup(
    author="DataScience_COE@spglobal.com",
    author_email='DataScience_COE@spglobal.com',
    python_requires='>=3.9',
    classifiers=[
        'Development Status :: 2 - Pre-Alpha',
        'Intended Audience :: Developers',
        'Natural Language :: English',
        'Programming Language :: Python :: 3.6',
        'Programming Language :: Python :: 3.7',
        'Programming Language :: Python :: 3.8',
    ],
    description="This is a reference implementation for Python based application to deploy as Kubernetes cronjob.",
    long_description=long_description,
    include_package_data=True,
    keywords='dscience-clo-gpt-rest',
    name='dscience-clo-gpt-rest',
    packages=find_packages(include=['util', 'util.*', 'src', 'src.*', 'source_documents']),
    py_modules=['app','rootdir','app_fastapi'],
    setup_requires=setup_requirements,
    install_requires=install_requirements,
    test_suite='tests',
    tests_require=test_requirements,
    url='https://spglobal.visualstudio.com/ratingsproducts/_git/dscience-clo-gpt-rest',
    version='1.0',
    zip_safe=True

)
