from fastapi import UploadFile, File, Form, HTTPException, status, Request, FastAPI
from fastapi.responses import StreamingResponse, JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from util import env, logger
from util.s3utils import  uploadFilesToS3
from src.model_functions import download_model_to_workspace
from src.ingestion import DBIngestion, query_parser, convert_es_context_to_response, s3_file_manager

from src.private_gpt import QAndAModel, download_model_to_path
from src.nlp_config import cuda_show_memory_usage, cuda_memory_info
import pandas as pd
import re
import requests
import os
import boto3
import sys
import uvicorn
import subprocess
from ast import literal_eval
from fastapi.encoders import jsonable_encoder
from io import BytesIO
from datetime import datetime
import torch.multiprocessing as mp

print(f"Platform is: {sys.platform}")

# rebuild LlamaCPP --- work around ----
if sys.platform.startswith('darwin'):
    CMAKE_LLAMA_CPP="CMAKE_ARGS=\"-DLLAMA_METAL=on\" FORCE_CMAKE=1 pip install --upgrade --force-reinstall llama-cpp-python --no-cache-dir"
    print("Skip build for Metal Platform, if needed use this: {CMAKE_LLAMA_CPP}")
    # os.system(CMAKE_LLAMA_CPP)
else:
    CMAKE_LLAMA_CPP = "CMAKE_ARGS=\"-DLLAMA_CUBLAS=on\" FORCE_CMAKE=1 pip install --upgrade --force-reinstall llama-cpp-python --no-cache-dir"
    print(f"Running: {CMAKE_LLAMA_CPP}")
    os.system(CMAKE_LLAMA_CPP)

logger = logger.getlogger()

app = FastAPI(debug=True)

logger.info("getting into ingestion!")
ingest = DBIngestion()
logger.info("came out of ingestion!")

logger.info("getting into QAndAModel!")
qaObject = QAndAModel()
logger.info("came out of QAndAModel!")

mongo_handler = env.mongo_con   

# s3_client = boto3.client('s3')
# global_s3_bucket_name = env.global_s3_bucket_name
# use this so that we have a single place to enable AWS authentication to run locally
s3_client = s3_file_manager.s3_client
global_s3_bucket_name = s3_file_manager.bucket_name

documents_s3_loc = env.documents_s3_loc
CHROMADB = env.CHROMADB
CLO_USER = env.CLO_USER
RUN_BATCH_JOB = env.RUN_BATCH_JOB


# CORS settings
origins = [
    "http://localhost:8080",
    "http://0.0.0.0:8080",
    "https://poc-dscience-chatbot-ui-dev.faas.dev.spratingsvpc.com",
    ]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get('/ready')
async def ready():
    logger.info("requested /ready")
    msg = {"Message": "Ready"}
    return msg

@app.post("/system_execute")
async def execute_command(command: str):
    try:
        result = subprocess.check_output(command, shell=True, stderr=subprocess.STDOUT)
        return {"output": result.decode('utf-8')}
    except subprocess.CalledProcessError as e:
        raise HTTPException(status_code=500, detail=e.output.decode('utf-8'))

def post_process_date(answer, date_format='%d-%b-%Y'):
    """
    Convert dates found in the answer to a consistent format.

    Args:
    - answer (str): Input string containing dates.
    - date_format (str): Desired output date format.

    Returns:
    - str: Formatted dates separated by commas.
    """
    # Validate input type
    if not isinstance(answer, str):
        logger.error("Invalid input type. Expected string.")
        return []

    # Define regex pattern for date extraction
    date_pattern = re.compile(
        r'\b(?:\d{1,2} (?:January|February|March|April|May|June|July|August|September|October|November|December) \d{4}|(?:January|February|March|April|May|June|July|August|September|October|November|December) \d{1,2}, \d{4})\b')

    formatted_dates = set()
    for date_str in date_pattern.findall(answer):
        try:
            dt = datetime.strptime(date_str, '%B %d, %Y' if ',' in date_str else '%d %B %Y')
            formatted_date = dt.strftime(date_format)
            formatted_dates.add(formatted_date)
        except ValueError:
            logger.error(f"Error parsing date: {date_str}")

    return ','.join(formatted_dates)


def post_process_yesno(answer, sentence_pattern=None):
    """
    Split the answer into first sentence and the rest of the sentences.

    Args:
    - answer (str): Input string containing sentences.
    - sentence_pattern (str): Optional custom regex pattern for sentence splitting.

    Returns:
    - str: Formatted string with the first sentence followed by rest of the sentences.
    """
    if not isinstance(answer, str):
        logger.error("Invalid input type. Expected string.")
        return ""

    # Use default sentence splitting pattern if not provided
    sentence_pattern = sentence_pattern or re.compile(r'(?<!\w\.\w.)(?<![A-Z][a-z]\.)(?<=\.|\?)\s')

    sentences = sentence_pattern.split(answer)
    first_sentence = sentences[0]
    rest_sentences = '\n'.join(sentences[1:]) if len(sentences) > 1 else ''
    return f"{first_sentence}\n\n{rest_sentences}\n"


def contains_date(text):
    """
    Check if the text contains any date information.

    Args:
    - text (str): The input text to be checked.

    Returns:
    - bool: True if the text contains date information, False otherwise.
    """
    # Define regex pattern for date extraction
    date_pattern = re.compile(
        r'\b(?:\d{1,2} (?:January|February|March|April|May|June|July|August|September|October|November|December) \d{4}|(?:January|February|March|April|May|June|July|August|September|October|November|December) \d{1,2}, \d{4})\b')

    # Search for dates in the text
    match = date_pattern.search(text)

    # If a match is found, return True; otherwise, return False
    return bool(match)


def post_processing(answer):
    if contains_date(answer):
        print(answer)
        return post_process_date(answer)
    elif 'Yes' in answer or 'No' in answer:
        return post_process_yesno(answer)

    return answer


def format_string(data):
    data = literal_eval(str(data))
    if isinstance(data, list):
        formatted_string = "SOURCE DOCUMENTS:\n"

        for item in data:
            formatted_string += f"DOCUMENT NAME: {item['doc_name']}\n"
            formatted_string += f"SOURCE CONTENT: {item['source_content']}\n\n"

        return formatted_string
    else:
        return data

def check_which_region_file(file_name):
    first_9_chars = file_name[:9]

    # First 9 characters are 8 number characters followed by an underscore for EMEA docs
    if re.match(r'^\d+_.*', first_9_chars):
        return 1

    return 0

def create_column_if_not_present(df, column_name):
    if column_name not in df.columns:
        df[column_name] = ''

    return df


def get_source_context_for_openai(source_context):
    formatted_string = ''
    for item in source_context:
        formatted_string += f"{item['source_content']} \n"

    return formatted_string


def compare_llm_answers(llm2_answer, openai_answer):
    # Check for None or empty string values
    if not llm2_answer or not openai_answer:
        return False

    llm2_answer_lower = llm2_answer.lower()
    openai_answer_lower = openai_answer.lower()

    # Check for exact match
    if llm2_answer_lower == openai_answer_lower:
        return True

    # Check for exact match of 'Yes' or 'No '
    elif 'yes' in llm2_answer_lower and 'yes' in openai_answer_lower:
        return True
    elif 'no ' in llm2_answer_lower and 'no ' in openai_answer_lower:
        return True

    # Check if either string is contained within the other
    elif llm2_answer_lower in openai_answer_lower or openai_answer_lower in llm2_answer_lower:
        return True

    # No match found
    return False


# Helper function to handle chat queries
def handle_chat_query(user_query, username=CLO_USER, file_name=None, is_batch_job=False):
    try:
        # Log user query
        logger.info(f'User Query: {user_query}')

        # Clean user query by removing extra whitespaces
        # user_query = ' '.join(user_query.split())

        # Parse query to determine route type and parameters
        try:
            query_route_type, definitions_list, sections_list = query_parser(user_query)
            logger.info(f'Query route type: {query_route_type}')
        except Exception as e:
            logger.error(f"Error occurred while parsing query: {str(e)}")
            raise

        # Handle different query route types
        try:
            if query_route_type in [1, 2]:
                # Search in Elasticsearch based on username, file_name, and query parameters
                try:
                    es_responses = ingest.search_into_es(username, file_name, definitions_list, sections_list)
                except Exception as e:
                    logger.error(f"Error occurred while searching in Elasticsearch: {str(e)}")
                    raise

                if es_responses:
                    # Route type 1: Directly convert ES context to response
                    if query_route_type == 1:
                        return convert_es_context_to_response(es_responses, user_query)

                    # Route type 2: Query LLM with ES context if LLM is available
                    elif query_route_type == 2 and qaObject.llm is not None and es_responses[0][
                        'file_name'] != 'dummy_filename.docx':
                        # user_query = user_query.replace(":", ",") if ':' in user_query else user_query
                        # Strip the text after the first colon if present
                        user_query = user_query.split(":", 1)[1].strip() if ':' in user_query else user_query
                        user_query = user_query.strip()

                        # user_query = user_query.split(":", 1)[-1].strip()
                        response = qaObject.query_llm_with_es_context(es_responses, user_query, is_batch_job)
                        # response['answer'] = post_processing(response['answer'])
                        return response

            if qaObject.llm is not None:
                user_query = user_query.replace(":", ",") if ':' in user_query else user_query
                # Strip the text after the first colon if present
                # user_query = user_query.split(":", 1)[1].strip() if ':' in user_query else user_query
                user_query = user_query.strip()
                response = qaObject.send_topk_ranked_chunks_to_llm(user_query, is_batch_job)
                # response['answer'] = post_processing(response['answer'])
                return response

            # Default response if query route type is not recognized or LLM is not available
            return {"query": user_query, "answer": 'Answer not found!!', "source": None, "status": 400,
                    "retrieval_time": 0}

        except Exception as e:
            logger.error(f"An error occurred while handling query route types: {str(e)}")
            raise

    except Exception as e:
        logger.error(f"An unexpected error occurred: {str(e)}")
        return {"query": user_query, "answer": 'An error occurred while processing the query.', "source": None,
                "status": 500, "retrieval_time": 0}

@app.post("/gpt/chat_batch_job")
async def perform_chat_job(file: UploadFile = File(...)):
    user_id = CLO_USER
    file_name = os.path.basename(file.filename)

    try:
        if not file_name:
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="No document file found")

        logger.info(f"Received file {file_name} from user {user_id}")

        contents = await file.read()
        # Reset the file pointer to the beginning of the file
        await file.seek(0)

        logger.info(f"File {file_name} successfully read")

        #refresh_success = ingest.ingest_into_both_dbs(user_id, file_name, contents) and qaObject.refresh_db()
        refresh_success1 = ingest.ingest_into_both_dbs(user_id, file_name, contents)
        if CHROMADB:
            refresh_success2 = qaObject.refresh_db()
        else:
            refresh_success2 = qaObject.op_refresh_db(user_id)

        if refresh_success1 and refresh_success2:
            logger.info(f"Refreshed databases after uploading file {file_name}")
            region = check_which_region_file(file_name=file_name)

            responses = generate_mongo_responses(user_id, file_name, region, 124)
            # excel_file = await generate_excel_file(user_id, file_name)

            if responses:
                mongo_handler.save_responses_to_mongodb(region, responses=responses)

                excel_file_df = pd.DataFrame(responses)
                # excel_file_df = excel_file_df.iloc[:, :-2]

                excel_bytes = BytesIO()
                with pd.ExcelWriter(excel_bytes, engine='xlsxwriter') as writer:
                    excel_file_df.to_excel(writer, index=False, sheet_name=file_name)

                excel_bytes.seek(0)
                
                results_file_name = os.path.splitext(os.path.basename(file_name))[0] + '_' + datetime.now().strftime("%Y%m%d:%I%M%p") + '_results.xlsx'
                logger.info(f"Excel file generated successfully for file {results_file_name}")
                return StreamingResponse(
                    BytesIO(excel_bytes.getvalue()),
                    media_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                    headers={"Content-Disposition": f"attachment; filename={results_file_name}"}
                )
            else:
                logger.warning(f"Failed to generate Excel file for file {file_name}")
                return JSONResponse(
                    content={"filename": file_name, "message": "Mongo failed to generate responses!"},
                    status_code=status.HTTP_424_FAILED_DEPENDENCY)
        else:
            logger.warning(f"Failed to refresh databases for uploaded file {file_name}")
            return JSONResponse(
                content={"filename": file_name, "message": "failed to refresh DB "},
                status_code=status.HTTP_424_FAILED_DEPENDENCY)

    except Exception as ex:
        logger.error(f"Error occurred while processing file {file_name}: {str(ex)}")
        return JSONResponse(content={"filename": file_name, "message": str(ex)},
                            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR)


@app.post('/gpt/chat_through_excel')
async def get_chat_through_excel(query: dict):
    user_query = query.get('query')
    file_name = query.get('file_name')
    user_id = CLO_USER

    logger.info(f"Requested /gpt/chat_through_excel service with query {user_query}, {file_name}, {user_id}")
    return handle_chat_query(user_query, user_id, file_name, True)

def remove_chars(string):
    # Define characters to remove
    chars_to_remove = {'"', '(', ')'}

    # Use generator expression to filter out unwanted characters
    cleaned_string = ''.join(char for char in string if char not in chars_to_remove)

    return cleaned_string

def modify_user_query_based_on_sections_definitions(sections: str, definitions: str, user_query: str) -> str:
    try:
        sections_list = sections.split('||')
        definitions_list = definitions.split('||')

        modified_user_query = ''

        if sections_list:
            modified_user_query += 'sections='
            for section in sections_list:
                section = remove_chars(section)
                modified_user_query += f'"{section.strip()}" or '
            modified_user_query = modified_user_query[:-4] + '# '

        if definitions_list:
            modified_user_query += 'definitions='
            for definition in definitions_list:
                definition = remove_chars(definition)
                modified_user_query += f'"{definition.strip()}" or '
            modified_user_query = modified_user_query[:-4] + '# '
        
        modified_user_query += f': {user_query}'
        return modified_user_query
    except Exception as e:
        logger.error(f"An error occurred while modifying user query: {e}")
        return None

@app.post('/gpt/chat_through_excel_updated')
async def get_chat_through_excel(query: dict):
    try:
        user_query = query.get('query')
        file_name = query.get('file_name')
        sections = query.get('sections')
        definitions = query.get('definitions')
        user_id = query.get('user_id')

        if user_id is None:
            user_id = CLO_USER

        modified_user_query = modify_user_query_based_on_sections_definitions(sections, definitions, user_query)
        if modified_user_query:
            logger.info(f"Requested /gpt/chat_through_excel service with query {user_query}, {file_name}, {user_id}")
            return handle_chat_query(modified_user_query, user_id, file_name, True)
        else:
            return {"error": "An error occurred while processing the request."}
    except Exception as e:
        logger.error(f"An error occurred: {e}")
        return {"error": "An error occurred while processing the request."}

@app.post('/gpt/chat')
async def get_chat(query: dict):
    user_query = query.get('query')
    username = CLO_USER

    logger.info(f"Requested /gpt/chat service with query {user_query}")
    return handle_chat_query(user_query, username, None, False)


@app.post('/gpt/index_es')
async def index_a_file_into_es(file: UploadFile = File(...), user_id: str = Form(...)):
    try:
        if (user_id != CLO_USER):
            # we want to detect where we use diff user
            logger.error(f"index_a_file_into_es, user_id: {user_id}")
            user_id = CLO_USER
        contents = await file.read()
        # Reset the file pointer to the beginning of the file
        await file.seek(0)

        file_location = ingest.save_the_file(user_id, file.filename, contents)

        es_res = None
        if file_location is not None:
            es_res = ingest.index_into_es(user_id, file_location)
        es_bool = False

        if '_shards' in es_res and 'failed' in es_res['_shards']:
            es_bool = es_res['_shards']['failed'] == 0

        if es_bool:
            return JSONResponse(content={"message": f"Search result: \n{jsonable_encoder(es_res)}"},
                                status_code=status.HTTP_200_OK)
        else:
            return JSONResponse(content={"message": f"Search result failed: \n{jsonable_encoder(es_res)}"},
                                status_code=status.HTTP_424_FAILED_DEPENDENCY)
    except Exception as ex:
        logger.error(ex)
        return JSONResponse(content={"filename": file.filename,
                                     "message": str(ex)},
                            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR)

@app.post('/gpt/ingest_to_es')
async def index_a_file_into_es(file: UploadFile = File(...)):  # noqa: F811
    try:
        user_id = CLO_USER
        contents = await file.read()
        # Reset the file pointer to the beginning of the file
        await file.seek(0)
        
        file_location = ingest.save_the_file(user_id, file.filename, contents)

        es_res = None
        if file_location is not None:
            es_res = ingest.index_into_es(user_id, file_location)
        es_bool = False

        if '_shards' in es_res and 'failed' in es_res['_shards']:
            es_bool = es_res['_shards']['failed'] == 0

        if es_bool:
            return JSONResponse(content={"message": f"Search result: \n{jsonable_encoder(es_res)}"},
                                status_code=status.HTTP_200_OK)
        else:
            return JSONResponse(content={"message": f"Search result failed: \n{jsonable_encoder(es_res)}"},
                                status_code=status.HTTP_424_FAILED_DEPENDENCY)
    except Exception as ex:
        logger.error(ex)
        return JSONResponse(content={"filename": file.filename,
                                     "message": str(ex)},
                            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR)

@app.post('/gpt/search_es')
async def search_query_in_es(user_query: str = Form(...), user_id: str = Form(...), file_name: str = Form(...)):
    try:
        if user_id != CLO_USER:
            # we want to detect where we use diff user
            logger.error(f"search_query_in_es, user_id: {user_id}")
            user_id = CLO_USER

        _, definitions_list, sections_list = query_parser(user_query)
        res = ingest.search_into_es(user_id, file_name, definitions_list, sections_list)

        if res:
            return JSONResponse(content={"message": f"Search result: \n{jsonable_encoder(res)}"},
                                status_code=status.HTTP_200_OK)
        else:
            return JSONResponse(content={"message": f"Search result failed: \n{jsonable_encoder(res)}"},
                                status_code=status.HTTP_424_FAILED_DEPENDENCY)

    except Exception as ex:
        return JSONResponse(content={"message": str(ex)},
                            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR)


@app.get('/gpt/sys_command')
async def install_sys_command(sys_command: str):
    try:
        import os
        logger.info(f"Received os command: {sys_command}")
        os.system(f"{sys_command}")
        return "Executed"
    except Exception as ex:
        return ex


@app.post("/gpt/upload_to_S3")
async def upload_to_s3(file: UploadFile = File(...), user_id: str = Form(...)):
    file_name = os.path.basename(file.filename)
    if user_id != CLO_USER:
        # we want to detect where we use diff user
        logger.error(f"upload_to_s3, user_id: {user_id}")
        user_id = CLO_USER
    try:
        if not file_name:
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="No document file found")

        logger.info(f"Received file {file_name} from user {user_id}")
        contents = await file.read()
        # Reset the file pointer to the beginning of the file
        await file.seek(0)
        logger.info(f"File {file_name} successfully read")

        if s3_client is not None:
            s3_key = documents_s3_loc + f"{user_id}/{file_name}" if user_id else documents_s3_loc + file_name
            s3_client.upload_fileobj(BytesIO(contents), global_s3_bucket_name, s3_key)
            logger.info(f"Successfully uploading file {file_name} to S3")

        #refresh_success = ingest.ingest_into_both_dbs(user_id, file_name, contents) and qaObject.refresh_db()
        refresh_success1 = ingest.ingest_into_both_dbs(user_id, file_name, contents)
        if CHROMADB:
            refresh_success2 = qaObject.refresh_db()
        else:
            refresh_success2 = qaObject.op_refresh_db(user_id)

        if refresh_success1 and refresh_success2:
            logger.info(f"Refreshed databases after uploading file {file_name}")

            if RUN_BATCH_JOB:
                region = check_which_region_file(file_name=file_name)

                responses = generate_mongo_responses(user_id, file_name, region, 10)
                # excel_file = await generate_excel_file(user_id, file_name)

                if responses:
                    mongo_handler.save_responses_to_mongodb(region, responses=responses)
                    excel_file_df = pd.DataFrame(responses)

                    excel_bytes = BytesIO()
                    with pd.ExcelWriter(excel_bytes, engine='xlsxwriter') as writer:
                        # to_excel have a limit of 31 characters for the sheet name
                        excel_file_df.to_excel(writer, index=False, sheet_name=file_name[:31] )

                    excel_bytes.seek(0)

                    results_file_name = os.path.splitext(os.path.basename(file_name))[0] + '_' + datetime.now().strftime("%Y%m%d:%I%M%p") + '_results.xlsx'
                    logger.info(f"Excel file generated successfully for file {results_file_name}")
                    return StreamingResponse(
                        BytesIO(excel_bytes.getvalue()),
                        media_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                        headers={"Content-Disposition": f"attachment; filename={results_file_name}"}
                    )
            return JSONResponse(content={"filename": file_name,
                                         "message": "Document upload successful, ingested data and refreshed DB "},
                                status_code=status.HTTP_200_OK)
        else:
            logger.warning(f"Failed to refresh databases after uploading file {file_name}")
            return JSONResponse(
                content={"filename": file_name, "message": "Document upload successful but failed to refresh DB "},
                status_code=status.HTTP_424_FAILED_DEPENDENCY)

    except Exception as ex:
        logger.error(f"Error occurred while processing file {file_name}: {str(ex)}")
        return JSONResponse(content={"filename": file_name, "message": str(ex)},
                            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR)


def run_azure_endpoint(selected_context, question):
    url = 'https://10.173.18.4/openai/deployments/gpt-35-turbo-16k/chat/completions?api-version=2023-05-15'
    headers = {"Content-Type": "application/json", "api-key": '10a91bf98cd347bd963bf7acc78dcfe0'}

    system_context = ("Answer the user's Question based on only the Context provided. Keep the answer concise and "
                      "non-repetitive.")

    user_prompt = f"""CONTEXT: {selected_context} \n Question: {question}"""

    data = {
        "messages":
            [
                {"role": "system", "content": system_context},
                {"role": "user", "content": user_prompt},
            ]
    }
    try:
        response = requests.post(url, headers=headers, json=data, timeout=25, verify=False)
        if response.status_code == 200:
            return response.json()
    except Exception as ex:
        logger.error(f'4k Model is NOT working for https://rating-nonprod-useast2.openai.azure.com {ex}')


def generate_mongo_responses(user_id, file_name, region, number_of_questions):
    if user_id != CLO_USER:
        # we want to detect where we use diff user
        logger.error(f"generate_mongo_responses, user_id: {user_id}")
        user_id = CLO_USER

    active_questions = mongo_handler.get_active_questions(number_of_questions, region=region)

    # Add extra keys to each document
    responses = []
    for doc in active_questions:
        question = str(doc.get('Question', '')).strip(' \n\t').replace('"', "'")
        if question:
            response = handle_chat_query(question, user_id, file_name, True)
            logger.info(f"isinstance(response, dict): {isinstance(response, dict)}")
            if isinstance(response, dict):
                source_context = response.get('source', '')
                source_context_for_openai = get_source_context_for_openai(source_context)
                openai_answer = run_azure_endpoint(source_context_for_openai, question)['choices'][0]['message'][
                    'content']
                llm2_answer = response.get('answer', '')
                doc.update({
                    "user": user_id,
                    "Document Name": file_name,
                    # "Answer": post_processing(llm2_answer),
                    "Answer": llm2_answer,
                    "Source Context": source_context,
                    "Analyst Feedback: Correct Answer (Y or N)": "",
                    "Analyst Feedback: Answer Comments": "",
                    "Analyst Feedback: Correct Source Context (Y or N)": "",
                    "Analyst Feedback: Source Context Comments": "",
                    "openAI Answer": openai_answer,
                    "compare_Answer_with_openAI": compare_llm_answers(llm2_answer, openai_answer),
                })
                responses.append(doc)

    return responses


def generate_excel_file(user_id, file_name):
    try:
        if user_id != CLO_USER:
            # we want to detect where we use diff user
            logger.error(f"generate_excel_file, user_id: {user_id}")
            user_id = CLO_USER
        logger.info(f"Generating Excel file for file {file_name}")

        excel_file_path = f"/home/appusr/dscience-clo-gpt-rest/qa_questions/{'EMEA' if check_which_region_file(file_name) == 1 else 'US'}_Questions_Q12024.xlsx"
        if not os.path.exists(excel_file_path):
            logger.warning(f"Excel file {excel_file_path} not found")
            return None

        original_df = pd.read_excel(excel_file_path, sheet_name=1)
        df = original_df.sample(n=10, random_state=1)
        required_columns = ['Document Name', 'Answer', 'Source Context', 'Analyst Feedback: Correct Answer (Y or N)',
                            'Analyst Feedback: Answer Comments', 'Analyst Feedback: Correct Source Context (Y or N)',
                            'Analyst Feedback: Source Context Comments']

        for column in required_columns:
            if column not in df.columns:
                df[column] = ''

        for index, row in df.iterrows():
            question = str(row.get('Question', '')).strip(' \n\t').replace('"', "'")
            if question:
                response = handle_chat_query(question, user_id, file_name, True)
                df.at[index, 'Document Name'] = file_name
                logger.info(f"isinstance(response, dict): {isinstance(response, dict)}")
                if isinstance(response, dict):
                    df.at[index, 'Answer'] = response.get('answer', '')
                    source_context = response.get('source', '')
                    source_context_for_openai = get_source_context_for_openai(source_context)
                    df.at[index, 'Source Context'] = format_string(source_context)
                    openai_answer = run_azure_endpoint(source_context_for_openai, question)['choices'][0]['message'][
                        'content']
                    df.at[index, 'openAI_Answer'] = openai_answer
        excel_bytes = BytesIO()
        with pd.ExcelWriter(excel_bytes, engine='xlsxwriter') as writer:
            df.to_excel(writer, index=False, sheet_name=os.path.splitext(file_name)[0])

        excel_bytes.seek(0)

        results_file_name = os.path.splitext(os.path.basename(file_name))[0] + '_' + datetime.now().strftime("%Y%m%d:%I%M%p") + '_results.xlsx'
        logger.info(f"Excel file generated successfully for file {results_file_name}")
        return StreamingResponse(
            BytesIO(excel_bytes.getvalue()),
            media_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            headers={"Content-Disposition": f"attachment; filename={results_file_name}"}
        )
    except Exception as ex:
        logger.error(f"Error occurred while generating Excel file for file {file_name}: {ex}")
        return None


@app.post("/gpt/ingest_to_vector_db")
async def ingest_doc_to_vector_db(file: UploadFile = File(...)):
    user_id = CLO_USER
    try:
        contents = await file.read()
        # Reset the file pointer to the beginning of the file
        await file.seek(0)
        file_name = os.path.basename(file.filename)

        _ = ingest.save_the_file(user_id, file_name, contents)
        if CHROMADB:
            ingest_success = ingest.ingest_data_to_vector_db()
            refresh_success = qaObject.refresh_db()
        else:
            ingest_success = ingest.op_ingest_data_to_vector_db(user_id)
            refresh_success = qaObject.op_refresh_db(user_id)

        if ingest_success and refresh_success:
            return JSONResponse(content={"filename": file_name,
                                         "message": "Ingested doc and refreshed vectorDB "},
                                status_code=status.HTTP_200_OK)
        else:
            return JSONResponse(content={"filename": file_name,
                                         "message": "Failed to ingest doc to vector DB."},
                                status_code=status.HTTP_424_FAILED_DEPENDENCY)

    except Exception as ex:
        return JSONResponse(content={"filename": file.filename,
                                     "message": str(ex)},
                            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR)


@app.get('/gpt/documents_list')
async def documents_list_in_s3(user_id: str):  # noqa: F811
    document_list = []
    if user_id != CLO_USER:
        # we want to detect where we use diff user
        logger.error(f"documents_list_in_s3, user_id: {user_id}")
        user_id = CLO_USER
    try:
        if user_id:
            response = s3_client.list_objects_v2(
                Bucket=global_s3_bucket_name,
                Prefix=documents_s3_loc + user_id + '/')

            for content in response.get('Contents', []):
                document_list.append(content['Key'])
                logger.info(os.path.split(content["Key"])[-1])

            return JSONResponse(content={"documents": document_list, "user_id": user_id},
                                status_code=status.HTTP_200_OK
                                )
        else:
            return JSONResponse(content={"message": str("Please provide the user1")},
                                status_code=status.HTTP_401_UNAUTHORIZED
                                )
    except Exception as ex:
        logger.error(ex)
        return JSONResponse(content={"message": str(ex)},
                            status_code=status.HTTP_400_BAD_REQUEST
                            )

@app.get('/gpt/documents_list_from_vector_db')
async def show_documents_list(user_id: str):
    document_list = []
    if user_id != CLO_USER:
        # we want to detect where we use diff user
        logger.error(f"show_documents_list, user_id: {user_id}")
        user_id = CLO_USER
    try:
        if user_id:
            document_list = ingest.op_get_document_embeddings_list(user_id)

            return JSONResponse(content={"documents": document_list, "user_id": user_id},
                                status_code=status.HTTP_200_OK
                                )
        else:
            return JSONResponse(content={"message": str("Please login with USER ID")},
                                status_code=status.HTTP_401_UNAUTHORIZED
                                )
    except Exception as ex:
        logger.error(ex)
        return JSONResponse(content={"message": str(ex)},
                            status_code=status.HTTP_400_BAD_REQUEST
                            )


@app.delete('/gpt/delete_document')
async def delete_document(user_id: str, document_name: str):
    try:
        if user_id != CLO_USER:
            # we want to detect where we use diff user
            logger.error(f"delete_document, user_id: {user_id}")
            user_id = CLO_USER
        if user_id and document_name:

            if not env.local_model:
                s3_key = documents_s3_loc + user_id + '/' + document_name
                s3_client.delete_object(Bucket=global_s3_bucket_name, Key=s3_key)
            # Call the delete_document_embeddings method to remove embeddings
            if CHROMADB:
                ingest.delete_document_embeddings(document_name, user_id)
            else:
                ingest.op_delete_document_embeddings(document_name, user_id)

            return JSONResponse(
                content={"message": f"Document '{document_name}' deleted successfully for user '{user_id}'"},
                status_code=status.HTTP_200_OK)
        else:
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST,
                                detail="Please provide both user ID and document name")
    except Exception as ex:
        logger.error(ex)
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(ex))


@app.delete('/gpt/delete_all_documents')
async def delete_all_documents_for_user(user_id: str):
    try:
        if user_id != CLO_USER:
            # we want to detect where we use diff user
            logger.error(f"delete_all_documents_for_user, user_id: {user_id}")
            user_id = CLO_USER
        deleted_count = 0
        if user_id:
            if not env.local_model:
                prefix = documents_s3_loc + user_id + '/'
                response = s3_client.list_objects_v2(Bucket=global_s3_bucket_name, Prefix=prefix)

                for content in response.get('Contents', []):
                    s3_client.delete_object(Bucket=global_s3_bucket_name, Key=content['Key'])
                    deleted_count += 1
                logger.info("deleting all embeddings from persist directory")

            is_keyworddb_deleted = ingest.delete_es_index()
   
            if CHROMADB:
                is_vectordb_deleted = ingest.delete_all_embeddings()
            else:
                is_vectordb_deleted = ingest.op_delete_all_embeddings(user_id)

            if is_vectordb_deleted and is_keyworddb_deleted:
                return JSONResponse(content={"message": f"{deleted_count} documents deleted successfully for user '{user_id}'"},
                                status_code=status.HTTP_200_OK)
            elif not is_vectordb_deleted and not is_keyworddb_deleted:
                return JSONResponse(content={"message": f"Failed to delete document in VectorDB and KeywordDB successfully for user '{user_id}'"},
                                status_code=status.HTTP_406_NOT_ACCEPTABLE)
            elif not is_vectordb_deleted and is_keyworddb_deleted:
                return JSONResponse(content={"message":  f"Failed to delete document in VectorDB successfully for user '{user_id}'"},
                                status_code=status.HTTP_406_NOT_ACCEPTABLE)
            elif is_vectordb_deleted and not is_keyworddb_deleted:
                return JSONResponse(content={"message": f"Failed to delete document in KeywordDB successfully for user '{user_id}'"},
                                status_code=status.HTTP_406_NOT_ACCEPTABLE)

        else:
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Please provide a user ID")
    except Exception as ex:
        logger.error(ex)
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(ex))


@app.post('/gpt/save_feedback')
async def save_feedback(request: Request):
    try:
        feedback_data = await request.json()
        result = mongo_handler.save_feedback_to_mongodb(feedback_data)
        logger.info("Feedback saved successfully")
        return {"message": "Feedback saved successfully", "feedback_id": str(result.inserted_id)}
    except Exception as e:
        return {"message": "Failed to save feedback", "error": str(e)}


@app.post('/gpt/azure_openai')
async def get_azure_openai_chat(query: dict):
    try:
        logger.info(f"requested /gpt/chat service with query: {query['query']}")
        from src.llm_azure_open_ai import azure_open_end_to_end_model_flow
        output = azure_open_end_to_end_model_flow(query)
        return output
    except Exception as ex:
        logger.error(ex)

@app.post('/gpt/set_batch_job')
async def set_batch_job(state: bool | None = None):
    global RUN_BATCH_JOB
    try:
        if state is not None:
            RUN_BATCH_JOB = state
        logger.info(f"set_batch_job, RUN_BATCH_JOB={RUN_BATCH_JOB}")
    except Exception as ex:
        logger.error(ex)
    return {"message": f"RUN_BATCH_JOB: {str(RUN_BATCH_JOB)}"}

@app.post('/gpt/download_model_from_hf')
async def test_download_model_to_path(m_path: str, repo_id: str, filename:str):
    try:
        logger.info(f"test_download_model_to_path m_path:{m_path}, {repo_id}, {filename}")
        file = download_model_to_path(m_path, repo_id, filename)
        logger.info(f"download_model_to_path returns {file}")
        return JSONResponse(content={"message": f"Downloaded to {file}"},
                            status_code=status.HTTP_200_OK)
    except Exception as ex:
        logger.error(ex)
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(ex))

@app.get('/gpt/load_model')
async def load_model(m_path: str, m_type: str, m_name: str | None = None, num_gpu_layer: int | None = None):
    if qaObject.load_model(m_path, m_name, m_type, num_gpu_layer):
        return {"response": "Successfully run the model. Ready to use now.."}
    else:
        return {"response": "Failed run the model..."}

@app.get('/gpt/upload_files_to_s3')
async def upload_files_to_s3(local_file_or_dir, remote_dir):
    "remote_dir is exclude the target file/dir"
    if uploadFilesToS3(s3_client, global_s3_bucket_name, remote_dir, local_file_or_dir):
        return {"response": "Successfully uploaded files"}
    else:
        return {"response": "Failed to upload all files"}

@app.get('/gpt/download_model_from_s3_to_workspace')
async def download_model_from_s3_to_workspace(model_file_path, model_name):
    if download_model_to_workspace(model_file_path, model_name):
        return {"response": "Successfully downloaded files"}
    else:
        return {"response": "Failed to download all files"}


@app.get('/gpt/cuda_show_memory_usage')
async def show_memory(clear_memory:bool | None = None):

    if clear_memory is True:
        cuda_memory_info()

    cuda_show_memory_usage()
    return JSONResponse(content={"message": "done"},
                        status_code=status.HTTP_200_OK)




if __name__ == "__main__":
    if sys.platform.startswith('win'):
        logger.info("Testing locally on Windows")
        uvicorn.run("app_fastapi:app", host="0.0.0.0", port=8080, timeout_keep_alive=1500, workers=1)
    else:
        mp.set_start_method('forkserver', force=True)
        uvicorn.run("app_fastapi:app", host="0.0.0.0", port=8080, timeout_keep_alive=1500, workers=1)

