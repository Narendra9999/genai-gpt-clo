# Python  Kubernetes cronjob
This is a reference implementation for Python based application to deploy as Kubernetes cronjob.

- Python 3.6
- cx_Oracle


# Steps to Run in local Docker environmnet
[Requires Docker engine and local docker registry]

1. Clone the repo in local directory 
    ```
    git clone https://spglobal.visualstudio.com/ratingsproducts/_git/serverless-reference-python-cron-impl

    change directory to serverless-reference-python-cron-impl
    ```
   
2. Build/Push Docker Image
    ```
    docker build -t serverless-reference-python-cron .
    docker tag serverless-reference-python-cron localhost:5000/serverless-reference-python-cron
    docker push localhost:5000/serverless-reference-python-cron
    ```
3. Run in docker
    docker run --env-file=env.txt serverless-reference-python-cron

# Steps to Run in local Kubernetes cluster environmnet

--Requires Docker engine ,local docker registry and local Kubernetes cluster( Minikube can be used to setup local single-node Kubernetes cluster)


1. Clone the repo in local directory 
    ```    
    git clone https://spglobal.visualstudio.com/ratingsproducts/_git/serverless-reference-python-cron-impl
    ```
2. Change directory to serverless-reference-python-cron-impl

3. Build/Push Docker Image
    ```
    docker build -t serverless-reference-python-cron .
    docker tag serverless-reference-python-cron localhost:5000/serverless-reference-python-cron
    docker push localhost:5000/serverless-reference-python-cron
    ```

4. Create a configmap/secrets

    ```   
    kubectl delete configmaps serverless-reference-python-cron-configmap
    kubectl create -f ./config/dev.yaml


    kubectl delete secrets serverless-reference-python-cron-secrets
    kubectl create -f ./config/secret.yaml	

    ```
5. Create a cronjob
    ```
    kubectl delete cronjob serverless-reference-python-cron
    kubectl create -f service.yaml
    ```
6. check the pod logs
    ```
    kubectl  logs `kubectl get pods|grep serverless-reference-python-cron|awk 'BEGIN{ FS=OFS=" " } {print $1}'`
   
    ```

# Dockerize the Application

Build zip file
   
    python setup.py sdist --format zip
   


CI/CD pipeline will be building the docker image for your application based on the contents of Dockerfile.

# Environment Specific Configs using ConfigMaps

Environment specific configs defined in dev.yaml / qa.yaml / prod.yaml etc, will be provided to your application as environment variables/volume mounts.


![](https://matthewpalmer.net/kubernetes-app-developer/articles/configmap-diagram.gif)

## How to access Application Logs
- [Dev Logs](https://splunksearch.mge.spratingsvpc.com/en-US/app/search/search?q=search%20index%3Ddev%20container_name%3D%22actrss-aphubretryexceptions-cron%22)
- [QA Logs](https://splunksearch.mge.spratingsvpc.com/en-US/app/search/search?q=search%20index%3Dqa%20container_name%3D%22actrss-aphubretryexceptions-cron%22)

More details about Observability can be [found here](https://spglobal.visualstudio.com/ratingsproducts/_git/ServerlessReference?path=%2Fdoc%2Ftopic%2Fobservability.md&_a=preview)


How to contribute
-----------
Please check out [docs\CONTRIBUTING.md](docs\CONTRIBUTING.md) for guidance on how you can contribute to this repo. Pull requests are welcome and encouraged! 