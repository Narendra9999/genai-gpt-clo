import subprocess
import sys

import ast
import os
import torch

os.environ['LLAMA_CUBLAS'] = '1'
# os.environ["PYTORCH_CUDA_ALLOC_CONF"] = "max_split_size_mb:1024"
# os.environ['OPENBLAS_NUM_THREADS'] = '1'
# based on blog : https://clearlinux.org/blogs-news/improving-python-numpy-performance-kubernetes-using-clear-linux-os
# os.environ['OMP_NUM_THREADS'] = '10'
# os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'

CUDA_STATUS = torch.cuda.is_available()
print(f"CUDA STATUS: {CUDA_STATUS}")
if CUDA_STATUS:
    CUDA_DEVICE_COUNT = torch.cuda.device_count()
    print(f"Available cuda device count {CUDA_DEVICE_COUNT} ")
    print(os.system("nvidia-smi"))
    torch.zeros(1).cuda()
    subprocess.check_call([sys.executable, "-m", "pip", "install", "pysqlite3-binary"])
    __import__("pysqlite3")
    sys.modules["sqlite3"] = sys.modules.pop("pysqlite3")
    print("system configured with SQL-lite3")

LLM_DEFAULT_USER = os.environ.get("LLM_DEFAULT_USER", "sop_gpt_default")

from pathlib import Path
from rootdir import ROOT_DIR
from util.common_functions import create_dir_if_not_exist, delete_dir_if_exist
from util import logger, local_env
from util.document_init_sample.spgi_about import txt_message

logger = logger.getlogger()

MOUNT_DIR = os.environ.get("MOUNT_PATH", ROOT_DIR)
create_dir_if_not_exist(MOUNT_DIR)  # checking mount location /opt/poc OR  root directory
local_model = os.environ.get("MODEL_LOCAL", True)
if not local_model:
    downloads_path = os.path.join(str(MOUNT_DIR), "models")
else:
    downloads_path = str(Path.home() / "Downloads")
local_model = ast.literal_eval(str(local_model).lower().capitalize())
model_download_s3 = os.environ.get("MODEL_DOWNLOAD_S3", local_env.model_download_s3)
model_download_s3 = ast.literal_eval(str(model_download_s3).lower().capitalize())
MODEL_TYPE = os.environ.get("MODEL_TYPE", local_env.model_type)
MODEL_NAME = os.environ.get("MODEL_NAME", local_env.model_name)
MODEL_QT_FILE_NAME = os.environ.get("MODEL_Qt_NAME", local_env.model_qt_file_name)
MODEL_DIR_LOC = os.environ.get("MODEL_DOWNLOAD_FILE_LOC", downloads_path)
EMBEDDINGS_MODEL_DIR = os.environ.get("EMBEDDINGS_MODEL_DIR", os.path.join(str(downloads_path), "embedding_models"))
MODEL_FILE_PATH = os.path.join(MODEL_DIR_LOC, MODEL_NAME)
SOURCE_DIRECTORY = os.environ.get("SOURCE_DIRECTORY", os.path.join(str(MOUNT_DIR), "source_documents"))
PERSIST_DIRECTORY = os.environ.get("PERSIST_DIRECTORY", os.path.join(str(MOUNT_DIR), "db"))
DELETE_MOUNT_DB = os.environ.get("DELETE_MOUNT_DB", False)
DELETE_MOUNT_DB = ast.literal_eval(str(DELETE_MOUNT_DB).lower().capitalize())
logger.info(f"DELETE_MOUNT_DB Marked.. {DELETE_MOUNT_DB}")

os.environ["HF_HOME"] = MODEL_DIR_LOC
os.environ["XDG_CACHE_HOME"] = os.path.join(MODEL_DIR_LOC, "xdb")
os.environ["SENTENCE_TRANSFORMERS_HOME"] = os.path.join(MODEL_DIR_LOC, "sentence_transformers")
os.environ['HUGGINGFACE_HUB_CACHE'] = os.path.join(MODEL_DIR_LOC, "huggingface")

global_s3_bucket_name = os.environ.get("global_s3_bucket_name", local_env.global_s3_bucket_name)
model_s3_file_loc = os.environ.get("model_s3_loc", "data/machinelearning/private_gpt/models/v1/")
documents_s3_loc = os.environ.get("documents_s3_loc", "data/machinelearning/sop-gpt/uploads/")
EMBEDDINGS_MODEL_NAME = os.environ.get("EMBEDDINGS_MODEL_NAME", local_env.embedding_model_name)
MODEL_N_CTX = int(os.environ.get("MODEL_N_CTX", local_env.model_n_ctx))
MAX_TOKEN = int(os.environ.get("MAX_TOKEN", local_env.max_token))
MODEL_N_BATCH = int(os.environ.get("MODEL_N_BATCH", local_env.model_n_batch))
MODEL_N_THREADS = int(os.environ.get("MODEL_N_THREADS", local_env.model_n_threads))
TARGET_SOURCE_CHUNKS = int(os.environ.get("TARGET_SOURCE_CHUNKS", local_env.target_source_chunk))
chunk_size = int(os.environ.get("CHUNK_SIZE", local_env.chunk_size))
chunk_overlap = int(os.environ.get("CHUNK_OVERLAP", local_env.chunk_overlap))
TEMPERATURE = int(os.environ.get("TEMPERATURE", local_env.temperature))


def delete_old_files():
    try:
        delete_dir_if_exist(os.path.join(PERSIST_DIRECTORY))
        create_dir_if_not_exist(os.path.join(PERSIST_DIRECTORY))
        delete_dir_if_exist(os.path.join(os.path.join(SOURCE_DIRECTORY)))
        create_dir_if_not_exist(os.path.join(os.path.join(SOURCE_DIRECTORY)))
        return True
    except Exception as ex:
        logger.error(ex)


if DELETE_MOUNT_DB:
    logger.info(f"DELETE_MOUNT_DB Marked.. {DELETE_MOUNT_DB}, Hence removing the existing memory/source document")
    delete_old_files()
else:
    logger.info(f"Persisting the existing DB memory at {PERSIST_DIRECTORY}...")

delete_dir_if_exist(MODEL_DIR_LOC)  # cleaning the existing models
delete_dir_if_exist(EMBEDDINGS_MODEL_DIR)  # cleaning the existing models
create_dir_if_not_exist(MODEL_DIR_LOC)  # creating model dir if not exist
create_dir_if_not_exist(EMBEDDINGS_MODEL_DIR)  # cleaning the existing models
create_dir_if_not_exist(PERSIST_DIRECTORY)  # checking persistence directory
create_dir_if_not_exist(SOURCE_DIRECTORY)  # checking source directory i.e. document folder
create_dir_if_not_exist(os.path.join(SOURCE_DIRECTORY, LLM_DEFAULT_USER))  # for default user
with open(str(os.path.join(SOURCE_DIRECTORY, LLM_DEFAULT_USER, "about_spgi.txt")), "w") as file:
    file.write(txt_message)

from chromadb.config import Settings
CHROMA_SETTINGS = Settings(
    # chroma_db_impl='duckdb+parquet',
    # persist_directory=PERSIST_DIRECTORY,
    anonymized_telemetry=False,
    is_persistent=True,
)

# Connect to OpenSearch
from opensearchpy import OpenSearch
ELASTIC_AUTH_USER = 'YCrG6yNg20rLB6Dn'
ELASTIC_AUTH_PASS = 'ge5!5TXe1&5_+!WK_Epm&1L4-'
ELASTIC_HOST = 'dscience-chatgpt-int-os.dev.spratingsvpc.com'
opensearch_credentials = (ELASTIC_AUTH_USER, ELASTIC_AUTH_PASS)
opensearch_host_url = "https://" + ELASTIC_HOST
opensearch_client = OpenSearch(hosts=[{"host": ELASTIC_HOST, "port": 443}],
                               http_auth=opensearch_credentials, use_ssl=True, verify_certs=False,
                               ssl_assert_hostname=False,
                               ssl_show_warn=False, )

CHROMADB = os.environ.get("CHROMADB", False)
CHROMADB = ast.literal_eval(str(CHROMADB).lower().capitalize())

logger.info(f"local_model: {local_model}")
logger.info(f"model_download_s3: {model_download_s3}")
logger.info(f"documents_s3_loc: {documents_s3_loc}")

logger.info(f"MODEL_NAME: {MODEL_NAME}")
logger.info(f"MODEL_FOLDER: {MODEL_DIR_LOC}")
logger.info(f"MODEL_FILE_PATH: {MODEL_FILE_PATH}")

logger.info(f"global_s3_bucket_name: {global_s3_bucket_name}")
logger.info(f"model_s3_file_loc: {model_s3_file_loc}")

logger.info(f"SOURCE_DIRECTORY: {SOURCE_DIRECTORY}")
logger.info(f"PERSIST_DIRECTORY: {PERSIST_DIRECTORY}")
logger.info(f"MODEL_TYPE: {MODEL_TYPE}")
logger.info(f"EMBEDDINGS_MODEL_NAME: {EMBEDDINGS_MODEL_NAME}")
logger.info(f"MODEL_N_CTX: {MODEL_N_CTX}")
logger.info(f"MAX_TOKEN: {MAX_TOKEN}")
logger.info(f"MODEL_N_BATCH: {MODEL_N_BATCH}")
logger.info(f"MODEL_N_THREADS: {MODEL_N_THREADS}")
logger.info(f"TARGET_SOURCE_CHUNKS: {TARGET_SOURCE_CHUNKS}")
logger.info(f"chunk_size: {chunk_size}")
logger.info(f"chunk_overlap: {chunk_overlap}")
logger.info(f"CHROMADB:{CHROMADB}")
