import ast
import os
import shutil
from util import logger
logger = logger.getlogger()


def create_dir_if_not_exist(path_dir):
    try:
        if not os.path.exists(path_dir):
            os.makedirs(path_dir)
            logger.info(f"PATH/Folder Location Created  : {path_dir}")
        else:
            logger.info(f"PATH ALREADY EXIST : {path_dir}")
    except Exception as ex:
        logger.error(ex)


def delete_dir_if_exist(path_dir):
    if os.path.exists(path_dir):
        shutil.rmtree(path_dir)
        logger.info(f"Removed the existing mount {path_dir} to avoid any catch files ")
    else:
        logger.info(f"{path_dir}  : No such directory ..  ")


def delete_file_by_name(path_dir, file_name):
    file_path = os.path.join(path_dir, file_name)
    logger.info(f"SOURCE DOCUMENT FILE PATH {file_path}")
    try:
        if os.path.isfile(str(file_path)):
            os.remove(str(file_path))
            logger.info(f"File '{file_name}' deleted successfully from source folder {path_dir}.")
        else:
            logger.warning(f"File '{file_name}' not founded source folder {path_dir}.")
    except Exception as e:
        logger.error(f"An error occurred: {e}")

def process_child_object(jsonobj):
    """
    Process the child object within the input dictionary.
    Parameters:
    - obj (dict): Input dictionary containing key-value pairs.
    Returns:
    - dict: Processed dictionary with child objects modified.
    """
    for key, value in jsonobj.items():
        if isinstance(value, str):
            try:
                # Convert the string to a dictionary
                child_dict = ast.literal_eval(value)
                if isinstance(child_dict, dict):
                    # If obj[key] is a string, convert it to a dictionary
                    current_dict = ast.literal_eval(jsonobj[key]) if isinstance(jsonobj[key], str) else jsonobj[key]
                    # Merge the dictionaries
                    jsonobj[key] = {**child_dict, **current_dict}
            except (SyntaxError, ValueError):
                pass
    return jsonobj