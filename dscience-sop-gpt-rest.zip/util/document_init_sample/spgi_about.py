txt_message = """About Company: S&P Global Inc., together with its subsidiaries, provides credit ratings, benchmarks, 
analytics, and workflow solutions in the global capital, commodity, and automotive markets. It operates through six 
segments: S&P Global Ratings, S&P Dow Jones Indices, S&P Global Commodity Insights, S&P Global Market Intelligence, 
S&P Global Mobility, and S&P Global Engineering Solutions. The S&P Global Ratings segment operates as an independent 
provider of credit ratings, research, and analytics, offering investors and other market participants information, 
ratings, and benchmarks. The S&P Dow Jones Indices segment is an index provider that maintains various valuation and 
index benchmarks for investment advisors, wealth managers, and institutional investors. The S&P Global Commodity 
Insights segment provides information and benchmark prices for the commodity and energy markets. The S&P Global 
Market Intelligence segment offers multi-asset-class data and analytics integrated with purpose-built workflow 
solutions. This segment offers Desktop, a product suite that provides data, analytics, and third-party research; Data 
and Advisory Solutions for research, reference data, market data, derived analytics, and valuation services; 
Enterprise Solutions, software and workflow solutions; and Credit & Risk Solutions for selling Ratings' credit 
ratings and related data and research. The S&P Global Mobility segment provides solutions serving the full automotive 
value chain, including vehicle manufacturers (OEMs), automotive suppliers, mobility service providers, retailers, 
consumers, and finance and insurance companies. The S&P Global Engineering Solutions segment offers engineering 
standards and related technical knowledge, including product design to provide information and insight to design 
products, optimize engineering projects and outcomes, solve technical problems, and address complex supply chain 
issues. S&P Global Inc. was founded in 1860 and is head office is located on 55 Water Street in Lower Manhattan, 
New York City.[3]
 
S&P Global (previously Standard & Poor's and informally known as S&P) is an American credit rating agency (CRA) and a 
division of S&P Global that publishes financial research and analysis on stocks, bonds, and commodities. S&P is 
considered the largest of the Big Three credit-rating agencies, which also include Moody's Investors Service and 
Fitch Ratings.

History: The company traces its history back to 1860, with the publication by Henry Varnum Poor of History of 
Railroads and Canals in the United States. This book compiled comprehensive information about the financial and 
operational state of U.S. railroad companies. In 1868, Henry Varnum Poor established H.V. and H.W. Poor Co. with his 
son, Henry William Poor, and published two annually updated hardback guidebooks, Poor's Manual of the Railroads of 
the United States and Poor's Directory of Railway Officials. In 1906, Luther Lee Blake founded the Standard 
Statistics Bureau, with the view to providing financial information on non-railroad companies. Instead of an annually 
published book, Standard Statistics would use 5-by-7-inch cards, allowing for more frequent updates.[4] In 1941, 
Paul Talbot Babson purchased Poor's Publishing and merged it with Standard Statistics to become Standard & Poor's 
Corp. In 1966, the company was acquired by The McGraw-Hill Companies, extending McGraw-Hill into the field of 
financial information services.[4]
"""