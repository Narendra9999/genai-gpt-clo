import boto3
from botocore.config import Config
from botocore.exceptions import ClientError
import os
from os import path
from util import env, logger

logger = logger.getlogger()

class S3FileManager:
    def __init__(self, bucket_name):
        self.s3_client = boto3.client('s3')
        self.bucket_name = bucket_name

    def get_fileFromS3Bucket(self, cloud_file_loc, cloud_file_name, download_location, delete_from_pod=False):
        logger.info("In get_fileFromS3Bucket")
        cloud_file_path = os.path.join(cloud_file_loc, cloud_file_name)

        try:
            logger.info("CloudFilePath ::::" + cloud_file_path)
            logger.info("CloudFileLocation ::::" + cloud_file_loc)
            logger.info("CloudFileName ::::" + cloud_file_name)
            logger.info("DownloadLocation ::::" + download_location)

            download_file_path = os.path.join(download_location, cloud_file_name)

            logger.info("Download full path ::::" + download_file_path)

            if delete_from_pod and os.path.exists(download_file_path):
                os.remove(download_file_path)

            if os.path.exists(download_file_path):
                logger.info(f"File Already exists at {download_file_path} ")
                return True
            else:
                logger.info(f"Downloading file from S3={cloud_file_path}")
                try:
                    self.s3_client.download_file(self.bucket_name, cloud_file_path, download_file_path)
                    logger.info(f"File fetched from S3={cloud_file_path}")
                    return True
                except Exception as e:
                    logger.info(f"Error in downloading. Error Description={e}")
                    raise Exception(f"Error in downloading. Error Description={e}")

        except Exception as e:
            logger.error('Error occured while Fetching file from S3', str(e))
            return False

    def get_filesFromS3Bucket(self, cloud_files_loc, download_files_loc=''):
        logger.info("In get_filesFromS3Bucket")
        logger.info(f"Downloading files from {cloud_files_loc} location to {download_files_loc}.")

        try:
            # List objects in the S3 bucket
            response = self.s3_client.list_objects_v2(Bucket=self.bucket_name, Prefix=cloud_files_loc)
            # Iterate over each object in the bucket
            for obj in response.get('Contents'):
                # Get the object key
                object_key = obj['Key']
                file_name = os.path.basename(object_key)
                logger.info(f"S3 -> File Name ->  : {file_name} In Queue .. ")
                if not file_name.startswith('.'):
                    download_file_path = os.path.join(download_files_loc, file_name)

                    if os.path.exists(download_file_path):
                        logger.info(f"{file_name} already exists at {download_file_path} ")
                    else:
                        logger.info(f"Downloading file {file_name}")
                        try:
                            self.s3_client.download_file(self.bucket_name, object_key, download_file_path)
                        except Exception as e:
                            e_msg = f"Error in downloading {file_name}. Error Description={e}"
                            logger.info(e_msg)
                            raise Exception(e_msg)

            return True

        except Exception as e:
            logger.error('Error occurred while Fetching file from S3', str(e))

        return False