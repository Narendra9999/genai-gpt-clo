import logging
import logging.config
import os

import yaml

from util import config

# Read logging.yaml file
try:
    with open(os.path.dirname(os.path.abspath(__file__)) + "/logging.yaml", 'r') as f:
        log_cfg = yaml.safe_load(f.read())
except Exception:
    raise

logging.config.dictConfig(log_cfg)


def getlogger():
    all_logger = logging.getLogger('all')
    all_logger.setLevel(logging.getLevelName(config.debug_level))
    return all_logger

