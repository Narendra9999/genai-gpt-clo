from pymongo import MongoClient

def get_mongo_client():
    mongo_client = MongoClient("mongodb://dsciencegenai_user:DgenAi_992@mongo-dev-1-clu1.dev.spratingsvpc.com:27060/")
    db = mongo_client["dsciencegenai"]
    feedback_collection = db["user-feedback"]
    return feedback_collection
