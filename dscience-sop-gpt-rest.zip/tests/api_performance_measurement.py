# import requests
# import json
# import time
# from datetime import datetime
#
# import pandas as pd
# import random
#
# # https://dscience-aqv-gpt-rest.caas.dev.spratingsvpc.com/docs
# # https://dscience-aqv-gpt-rest-pod-1.caas.dev.spratingsvpc.com/docs
# # https://dscience-aqv-gpt-rest-pod-2.caas.dev.spratingsvpc.com/docs
#
# existing_df = pd.read_excel('api_performance_outcome.xlsx')
# print(existing_df.columns)
#
# pod_details = ['', '-pod-1', '-pod-2']
# global_data = []
#
# questions = ["what is nato ?",
#              "what does Current Pay Obligation mean?",
#              "what does senior secured loan mean?",
#              "Can you tell me the definition of CCC Collateral Obligation?",
#              "what does Discount Obligation mean?"]
#
#
# def tst_post_gpt_chat():
#     # URL of the POST API
#     for pod_id in pod_details:
#         api_gpt_chat = f"https://dscience-aqv-gpt-rest{pod_id}.caas.dev.spratingsvpc.com/gpt/chat"
#         headers = {'Content-Type': 'application/json'}
#         post_data_json = {"query": random.choice(questions)}
#         now_info = datetime.now().strftime("%d:%m:%Y:%H:%M:%S")
#         start_time = time.time()
#         response = requests.post(api_gpt_chat, data=json.dumps(post_data_json), headers=headers)
#         end_time = time.time()
#         elapsed_time = end_time - start_time
#
#         pod_dic = {"time_stamp": now_info,
#                    "query": post_data_json,
#                    "api_details": api_gpt_chat,
#                    "pod_id": pod_id,
#                    "headers": headers,
#                    "elapsed_time": elapsed_time,
#                    "api_time": response.elapsed.total_seconds(),
#                    "response": response.json()}
#
#         global_data.append(pod_dic)
#
#
# def tst_get_gpt_refresh():
#     for pod_id in pod_details:
#         api_gpt_refresh = f"https://dscience-aqv-gpt-rest{pod_id}.caas.dev.spratingsvpc.com/gpt/refresh"
#         for _user_id_ in ['admin', 'user1', 'user2']:
#             headers = {'user-id': _user_id_}
#             now_info = datetime.now().strftime("%d:%m:%Y:%H:%M:%S")
#             start_time = time.time()
#             response = requests.get(api_gpt_refresh, headers=headers)
#             end_time = time.time()
#             elapsed_time = end_time - start_time
#
#             pod_dic = {"time_stamp": now_info,
#                        "query": '/gpt/refresh',
#                        "api_details": api_gpt_refresh,
#                        "pod_id": pod_id,
#                        "headers": headers,
#                        "elapsed_time": elapsed_time,
#                        "api_time": response.elapsed.total_seconds(),
#                        "response": response.json()}
#             global_data.append(pod_dic)
#
#
# # Example usage:
# if __name__ == "__main__":
#     # JSON data to send in the POST API
#
#     # # Measure GET API performance
#     tst_get_gpt_refresh()
#
#     # Measure POST API performance
#     tst_post_gpt_chat()
#
#     df = pd.DataFrame(global_data)
#     print(df)
#     print(df.columns)
#     # for appending df2 at the end of df1
#     existing_df = existing_df.append(df, ignore_index=False)
#     existing_df.to_excel('api_performance_outcome.xlsx')
#     print(existing_df)