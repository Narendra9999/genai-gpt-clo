from util.connect import Connect
from util import logger, config

logger = logger.getlogger()

# Get Database Connection
logger.info('Get Database Connection')

db_connection = Connect(config.db_user, config.db_password, config.db_service_name, config.db_hostname,
                        config.db_port,
                        config.max_connection, config.min_connection, config.connection_increment,
                        config.spr_app_secret_hc_vault_base_url, config.spr_app_secret_hc_vault_token,
                        config.spr_shelf_id)
# Execute Sql
logger.info('Execute Sql')

db_connection.execute("""
            SELECT first_name, last_name
            FROM core.employees
            WHERE employee_id = :eid""", {'eid': 'PRK5149'})

result = db_connection.fetchone()
print(result)

# Release Connection
db_connection.release()

# Close Connection
db_connection.close()
