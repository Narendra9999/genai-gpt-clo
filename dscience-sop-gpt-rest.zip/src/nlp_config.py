import os
import os
import gc
import torch
import psutil
from util.env import EMBEDDINGS_MODEL_NAME, EMBEDDINGS_MODEL_DIR
from langchain.embeddings import HuggingFaceEmbeddings, HuggingFaceInstructEmbeddings, HuggingFaceBgeEmbeddings


def cuda_cache_clean_up():
    if torch.cuda.is_available():
        with  torch.no_grad():
            torch.cuda.empty_cache()
        print("Cleared the GPU cache memory...")
    else:
        print("No CUDA available")


def cuda_memory_info():
    try:
        cuda_cache_clean_up()
        print("GPU MEMORY ", torch.cuda.get_device_properties(0).total_memory)
        print("SYSTEM MEMORY ", psutil.virtual_memory().available)
        gc.collect()
    except Exception as ex:
        print(ex)


if torch.cuda.is_available():
    model_kwargs = {'device': 'cuda'}
else:
    os.environ["TOKENIZERS_PARALLELISM"] = "false"
    model_kwargs = {'device': 'cpu'}

encode_kwargs = {'normalize_embeddings': True}  # set True to compute cosine similarity

if EMBEDDINGS_MODEL_NAME == 'jinaai/jina-embeddings-v2-base-en':
    os.environ['HF_TOKEN'] = "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"
    from transformers import AutoModel

    model = AutoModel.from_pretrained(EMBEDDINGS_MODEL_NAME,
                                      trust_remote_code=True,
                                      cache_dir=EMBEDDINGS_MODEL_DIR
                                      )

cuda_memory_info()
if EMBEDDINGS_MODEL_NAME == "hkunlp/instructor-large":
    embeddings = HuggingFaceInstructEmbeddings(
        model_name=EMBEDDINGS_MODEL_NAME,
        encode_kwargs=encode_kwargs,
        embed_instruction='Represent the legal, compliance and operating procedures document for retrieval:',
        query_instruction='Represent the question for retrieving supporting documents:',
        cache_folder=EMBEDDINGS_MODEL_DIR
    )
else:
    embeddings = HuggingFaceEmbeddings(model_name=EMBEDDINGS_MODEL_NAME,
                                       model_kwargs=model_kwargs,
                                       encode_kwargs=encode_kwargs,
                                       cache_folder=EMBEDDINGS_MODEL_DIR)

print(f"Downloaded {EMBEDDINGS_MODEL_NAME}:", embeddings)
cuda_memory_info()
