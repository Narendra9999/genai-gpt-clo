# import os
# import time
# from util import env,logger
# logger = logger.getlogger()
# from langchain.llms import LlamaCpp
# from langchain.chains import RetrievalQA
# from langchain.vectorstores import Chroma
# from src.nlp_config import embeddings
# from src.llama_prompt import get_llm_prompt, sys_prompt as system_prompt
# from src.private_gpt import QAndAModel
#
#
# def end_to_end_model_flow(params: dict, model_name):
#     try:
#         logger.info(model_name)
#         user_id = params.get("user_id")
#         input_query = params.get("query")
#         input_sys_prompt = params.get("prompt", system_prompt)
#         top_k = params.get("top_k", env.TARGET_SOURCE_CHUNKS)
#         kwargs = {
#             "model_path": os.path.join(env.MODEL_DIR_LOC, model_name),
#             "n_ctx": params.get("n_ctx", env.MODEL_N_CTX),
#             "n_batch": params.get("n_batch", env.MODEL_N_BATCH),  # set this based on your GPU & CPU RAM
#             "n_threads": params.get("n_threads", env.MODEL_N_THREADS),
#             # "max_tokens": max_tokens,
#             "repeat_penalty": params.get("repeat_penalty", 1.1),
#             "temperature": params.get("temperature", 0.5),
#             "verbose": False,
#             # f16_kv=True,
#             "n_gpu_layers": 70,  # set this based on your GPU
#             "seed": 1,
#         }
#         llm = LlamaCpp(**kwargs)
#         _db_path = os.path.join(env.PERSIST_DIRECTORY, user_id)
#         logger.info(_db_path)
#         if os.path.exists(os.path.join(_db_path, 'chroma.sqlite3')):
#             db = Chroma(collection_name=str(user_id),
#                         persist_directory=os.path.join(env.PERSIST_DIRECTORY, user_id),
#                         embedding_function=embeddings,
#                         client_settings=env.CHROMA_SETTINGS)
#             retriever = db.as_retriever(search_kwargs={"k": top_k})
#             qa = RetrievalQA.from_chain_type(llm=llm,
#                                              chain_type="stuff",
#                                              retriever=retriever,
#                                              chain_type_kwargs=get_llm_prompt(input_sys_prompt=input_sys_prompt),
#                                              return_source_documents=True)
#             print("Q & A Model is configured....")
#             _start_time = time.time()
#             res = qa(input_query)
#             answer, docs = res['result'], res['source_documents']
#             _end_time = time.time()
#             source_data = []
#             for document in docs:
#                 source_data.append({"doc_name": document.metadata["source"], 'source_content': document.page_content})
#
#             results_ = {"query": input_query,
#                         "answer": answer,
#                         "source": source_data,
#                         "retrieval_time": round(_end_time - _start_time, 2)
#                         }
#             return results_
#         else:
#             results_ = {
#                 "query": input_query,
#                 "answer": "There is no data available for user, please add the relevant document",
#                 "source": [{"doc_name": "<>", "source_content": "<>"}]
#             }
#             return results_
#     except Exception as ex:
#         raise Exception(ex)
#
#
# if __name__ == '__main__':
#     out_put_res = end_to_end_model_flow(env.MODEL_NAME, "langchain", input_sys_prompt=None)
#     print(out_put_res)
