examples = [
    {
        "input": "I am excited to be part of my son's school board. Do I need to do anything?",
        "output": "What are the compliance regulations regarding joining a school board?, Do I need to get prior "
                  "approvals from my employer?"
    },
    {
        "input": "How do i request to be re-assigned to an old credit i used to rate",
        "output": "Can I rate an issuer that I rated before?, Does company policy allow an analytical employee to be "
                  "on a rating committee more than once?"
    },
    {
        "input": "how long do i have to log the error in RADAR?",
        "output": "Within how many days or weeks should an error be documented on RADAR? How soon should an error "
                  "record be documented on ETR?"
    },
    {
        "input": "Can ROS withdraw a rating on Issuer request?",
        "output": "What authority does ROS have about Rating actions?, What procedures should be followed after a "
                  "Issuer requests Ratings to be withdrawn?"
    },
    {
        "input": "Who is responsible to document the error?",
        "output": "What are the different categories of errors?, Who is responsible to report an error once it is "
                  "discovered?"
    },
]

# from langchain.prompts import ChatPromptTemplate, FewShotChatMessagePromptTemplate
# from langchain.output_parsers import CommaSeparatedListOutputParser
# from langchain.schema.runnable import RunnableLambda
# from langchain.schema.output_parser import StrOutputParser
# from langchain.chat_models import ChatFireworks
#
# # We now transform these to example messages
# example_prompt = ChatPromptTemplate.from_messages([("human", "{input}"), ("ai", "{output}"), ])
# few_shot_prompt = FewShotChatMessagePromptTemplate(example_prompt=example_prompt, examples=examples, )
#
# prompt = ChatPromptTemplate.from_messages([
#     ("system", """<|system|>You are an expert at compliance and standard operating procedures at S&P.
#               Your task is to step back and abstract the original question
#               to some more  step-back questions that are related to compliance and standard operating procedures,
#               which are easier to answer. </s> Here are a few examples:"""),
#     few_shot_prompt,
#     ("user", "{question}</s>"),
# ])
#
# question_gen_chain = prompt | llmObj | CommaSeparatedListOutputParser()
#
# response_prompt_template = """<|system|> You are a Compliance Officer at a Credit Rating Agency. The user asking you
# the questions is an Analytical Employee at the Credit Rating Agency. </s> <|user|> I am going to ask you a question
# about compliance rules and operating rules and regulations. Your response should be concise and should answer the
# question about compliance and operating procedures based on the following context if they are relevant. If they are
# not relevant, say you dont know the answer.
#
# {step_back_context}
# Original Question: {question}
#
# </s>
# <|assistant|>
# Answer:"""
#
# response_prompt = ChatPromptTemplate.from_template(response_prompt_template)
# chain = ({
#              # Retrieve context using the normal question
#              "normal_context": RunnableLambda(lambda x: x["question"]) | retriever_list,
#              # Retrieve context using the step-back question
#              "step_back_context": question_gen_chain | retriever_list,
#              "question": lambda x: x["question"],
#          } | response_prompt | llmObj | StrOutputParser()
#          )
