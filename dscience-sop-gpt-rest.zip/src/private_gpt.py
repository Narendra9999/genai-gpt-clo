# import sys
import pprint
import time
from langchain.chains import RetrievalQA
# from langchain.embeddings import HuggingFaceEmbeddings
# from langchain.callbacks.streaming_stdout import StreamingStdOutCallbackHandler
# from langchain.vectorstores import Chroma
from langchain.llms import GPT4All, LlamaCpp
import os
# import glob
# from typing import List
# import requests

# from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.vectorstores import Chroma, OpenSearchVectorSearch
from opensearchpy import RequestsHttpConnection
# from langchain.embeddings import HuggingFaceEmbeddings
# from langchain.docstore.document import Document

from util import env, logger
from src.nlp_config import embeddings,cuda_memory_info
# from src.rerank_score import get_re_rank_score
from src.model_functions import download_model_to_workspace
# from src.llama_prompt import get_llm_prompt, sys_prompt as system_prompt
from src.mistral_prompt import QA_PROMPT

import langchain
from langchain.cache import InMemoryCache

langchain.llm_cache = InMemoryCache()

logger = logger.getlogger()

from util.env import (PERSIST_DIRECTORY,
                      MODEL_TYPE,
                      MODEL_FILE_PATH,
                      MODEL_N_CTX,
                      MODEL_N_BATCH, MODEL_N_THREADS, TARGET_SOURCE_CHUNKS,
                      CHROMA_SETTINGS, MAX_TOKEN, LLM_DEFAULT_USER,
                      opensearch_client, opensearch_credentials, opensearch_host_url
                      )


def trim_incomplete_sentence(paragraph):
    if paragraph and len(paragraph) > 2 and not paragraph.endswith('.'):
        # Split the paragraph into sentences and remove any empty strings and leading/trailing whitespaces
        sentences = [sentence.strip() for sentence in paragraph.split('.') if sentence.strip()]

        if len(sentences) >= 2:
            sentences.pop()

        # Join the remaining sentences back into a paragraph
        trimmed_paragraph = '. '.join(sentences)

        return trimmed_paragraph + "."

    else:
        return paragraph


class QAndAModel:

    def __init__(self):
        self.db = None
        self.qa = None
        self.llm = self.load_model()  # loading init model
        self.llm = None
        cuda_memory_info()  # clearing all the GPU cache

    def db_connect(self, input_query, user_id):
        try:
            if os.path.exists(os.path.join(PERSIST_DIRECTORY, user_id)):
                db = Chroma(collection_name=str(user_id),
                            persist_directory=os.path.join(PERSIST_DIRECTORY, user_id),
                            embedding_function=embeddings,
                            client_settings=CHROMA_SETTINGS)
                retriever = db.as_retriever(search_kwargs={"k": env.TARGET_SOURCE_CHUNKS})
                # _documents = retriever.get_relevant_documents(query=input_query)
                # _pair = [[input_query, doc.page_content] for doc in _documents]
                # logger.info(_pair)
                # _scores = get_re_rank_score(_pair)
                # mapped  = zip(_pair, _scores)
                # logger.info(list(mapped))
                qa = RetrievalQA.from_chain_type(llm=self.llm,
                                                 chain_type="stuff",
                                                 retriever=retriever,
                                                 chain_type_kwargs={"prompt": QA_PROMPT},
                                                 return_source_documents=True)
                logger.info("Q & A Model is configured....")
                return qa
            else:
                logger.error("No User Data found")
                return False
        except Exception as ex:
            logger.error(ex)
            return False

    def connect_llm_qa_model(self, input_query: str, user_id: str):
        if not env.local_model: cuda_memory_info()
        logger.info(f"QAndAModel- input_query:{input_query}")
        logger.info(f"QAndAModel- user_id:{user_id}")

        if not os.path.exists(os.path.join(PERSIST_DIRECTORY, user_id)):
            return {"query": input_query,
                    "answer": "User Data not exist, please upload LLM use case data ",
                    "source": " Click on ingest",
                    "status": 201}

        if user_id is not None and input_query is not None and input_query != "":
            try:
                if os.path.exists(os.path.join(PERSIST_DIRECTORY, user_id)):
                    db = Chroma(collection_name=str(user_id),
                                persist_directory=os.path.join(PERSIST_DIRECTORY, user_id),
                                embedding_function=embeddings,
                                client_settings=CHROMA_SETTINGS)
                    retriever = db.as_retriever(search_kwargs={"k": env.TARGET_SOURCE_CHUNKS})
                    qa = RetrievalQA.from_chain_type(llm=self.load_model(),
                                                     chain_type="stuff",
                                                     retriever=retriever,
                                                     chain_type_kwargs={"prompt": QA_PROMPT},
                                                     return_source_documents=True)
                    logger.info("Q & A Model is configured....")
                    _start_time = time.time()
                    res = qa(input_query)
                    answer, docs = res['result'], res['source_documents']
                    logger.log("LLM Model response")
                    logger.log(f"{answer}")
                    answer = trim_incomplete_sentence(answer)
                    logger.log("LLM Model response : After removing incomplete")
                    logger.log(f"{answer}")
                    _end_time = time.time()
                    source_data = []
                    for document in docs:
                        source_data.append(
                            {"doc_name": document.metadata["source"], 'source_content': document.page_content})

                    results_ = {"query": input_query,
                                "answer": answer,
                                "source": source_data,
                                "status": 200,
                                "retrieval_time": round(_end_time - _start_time, 2)
                                }
                    logger.info(f"qa_results: {results_}")
                    db.persist()
                    if not env.local_model: cuda_memory_info()
                    return results_
                else:
                    results_ = {
                        "query": input_query,
                        "answer": "There is no data available for user, please add the relevant document",
                        "source": [{"doc_name": "<>", "source_content": "<>"}],
                        "status": 200,
                    }
                    if not env.local_model: cuda_memory_info()
                    return results_
            except Exception as ex:
                logger.error(str(ex))
                return {"query": input_query, "answer": str(ex),
                        "source": [{"doc_name": "<>", "source_content": "<>"}], "status": 400, }
        return {"message": "Empty Query", "status": 201}

    @staticmethod
    def model_download_status(_model_path):
        if os.path.exists(_model_path):
            logger.info(f"Model already available : {_model_path}")
        else:
            if download_model_to_workspace():
                logger.info(f"Model Downloaded to DIR: {_model_path}")
            else:
                logger.error("Unable to download from s3/global model repo")
                raise Exception("Unable to download from s3/global model repo")

    def load_model(self):
        """
         method connects to the model folder and creates a model object.
         It is responsible for initializing the necessary components to load a pre-trained model
         from a specified directory or location. Once the model is loaded, it will be available as global variable
        :return: assign LLM object to GLOBAL object
        """
        try:
            callbacks = []  # [StreamingStdOutCallbackHandler()]
            if env.local_model:
                self.model_download_status(env.MODEL_FILE_PATH)
                llm = LlamaCpp(model_path=MODEL_FILE_PATH,
                               n_ctx=MODEL_N_CTX,
                               n_batch=MODEL_N_BATCH,
                               n_threads=MODEL_N_THREADS,
                               # seed=1,
                               max_tokens=MAX_TOKEN,
                               repeat_penalty=1.1,
                               temperature=0.3,
                               n_gpu_layers=100,
                               callbacks=callbacks,
                               verbose=False)
                logger.info("model configured completed..")
                return llm
            from langchain.llms import CTransformers
            llm = CTransformers(model="TheBloke/zephyr-7B-alpha-GPTQ",
                                model_type="gptq",
                                gpu_layers=50,
                                threads=12,
                                reset=False,
                                context_length=2048,
                                stream=True,
                                max_new_tokens=2048,
                                temperature=0.5,
                                repetition_penalty=1.1)
            logger.info("llm-gpu model configured completed..")
            return llm
        except Exception as ex:
            logger.error(ex)
            raise Exception(ex)

    # def load_model_ctransformers(self):
    #     import os
    #     os.environ['TRANSFORMERS_CACHE'] = env.MODEL_DIR_LOC
    #     os.environ['HUGGINGFACE_HUB_CACHE'] = env.MODEL_DIR_LOC
    #
    #     from langchain.llms import CTransformers
    #     config = {'max_new_tokens': 1400, 'repetition_penalty': 1.1, 'temperature': 0.15, 'top_p': 0.99,
    #               'top_k': 40,
    #               'context_length': 5800, 'seed': 189,
    #               # ,''max_length' :5800
    #               }
    #     self.model_download_status(env.MODEL_FILE_PATH)
    #     self.llm = CTransformers(model=env.MODEL_FILE_PATH,  # 'TheBloke/zephyr-7B-alpha-GGUF',
    #                              # model_file='zephyr-7b-alpha.Q5_K_M.gguf',
    #                              model_type="mistral", config=config, gpu_layers=50, device_map="auto")
    #
    #     from accelerate import Accelerator
    #     accelerator = Accelerator()
    #     self.llm, optimizer = accelerator.prepare(self.llm, config)
    #
    #     logger.info("TheBloke/zephyr-7B-alpha-GGUF : model configured completed..")
    #     return True

    def load_step_back_retrieve(self, input_query: str, user_id: str):

        from langchain.prompts import ChatPromptTemplate, FewShotChatMessagePromptTemplate
        from langchain.output_parsers import CommaSeparatedListOutputParser
        from langchain.schema.runnable import RunnableLambda
        from langchain.schema.output_parser import StrOutputParser
        from langchain.chat_models import ChatFireworks

        from src.sop_prompt import examples

        example_prompt = ChatPromptTemplate.from_messages([("human", "{input}"), ("ai", "{output}"), ])
        few_shot_prompt = FewShotChatMessagePromptTemplate(example_prompt=example_prompt, examples=examples, )

        prompt = ChatPromptTemplate.from_messages([
            ("system", """<|system|>You are an expert at compliance and standard operating procedures at S&P. 
                      Your task is to step back and abstract the original question 
                      to some more  step-back questions that are related to compliance and standard operating procedures, 
                      which are easier to answer. </s> Here are a few examples:"""),
            few_shot_prompt,
            ("user", "{question}</s>"),
        ])

        question_gen_chain = prompt | self.llm | CommaSeparatedListOutputParser()

        response_prompt_template = """<|system|> You are a Compliance Officer at a Credit Rating Agency. The user 
        asking you the questions is an Analytical Employee at the Credit Rating Agency. </s> <|user|> I am going to 
        ask you a question about compliance rules and operating rules and regulations. Your response should be 
        concise and should answer the question about compliance and operating procedures based on the following 
        context if they are relevant. If they are not relevant, say you dont know the answer.

        {step_back_context}
        Original Question: {question}

        </s>
        <|assistant|>
        Answer:"""

        db = Chroma(collection_name=str(user_id),
                    persist_directory=os.path.join(PERSIST_DIRECTORY, user_id),
                    embedding_function=embeddings,
                    client_settings=CHROMA_SETTINGS)
        retriever = db.as_retriever(search_kwargs={"k": env.TARGET_SOURCE_CHUNKS})

        def retriever_list(input_questions):
            import time
            answer = ''
            ques = ''
            for question in input_questions:
                ques += question
                ques += '/'
                if question[-1] == '?':
                    # ans = retriever22.run(ques)
                    retrieved_docs = retriever.invoke(ques)
                    ans = retrieved_docs[0].page_content
                    ques = ''
                    answer += ans
                    time.sleep(2)
            print("Answer: ", answer)
            return answer

        response_prompt = ChatPromptTemplate.from_template(response_prompt_template)
        chain = ({
                     # Retrieve context using the normal question
                     "normal_context": RunnableLambda(lambda x: x["question"]) | retriever_list,
                     # Retrieve context using the step-back question
                     "step_back_context": question_gen_chain | retriever_list,
                     "question": lambda x: x["question"],
                 } | response_prompt | self.llm | StrOutputParser()
                 )

        question_list = question_gen_chain.invoke({"question": input_query})
        print("Question List: ", question_list)
        print("*" * 80)
        sbs_output = chain.invoke({"question": input_query})
        print("*" * 80)
        print("\n\nSBS  Output: ", sbs_output)

        results_ = {"query": input_query,
                    "answer": sbs_output,
                    "source": [],
                    "status": 200,
                    "retrieval_time": 11.5
                    }

        return results_

    @staticmethod
    def end_to_end_model_flow(params: dict):
        logger.info("Running the fully parameterized. Following are the parameters")
        if not env.local_model:
            cuda_memory_info()

        try:
            user_id = params.get("user_id")
            input_query = params.get("query")
            #input_sys_prompt = params.get("DefaultPrompt", system_prompt)
            top_k = params.get("top_k", env.TARGET_SOURCE_CHUNKS)
            _db_path = os.path.join(env.PERSIST_DIRECTORY, user_id)
            logger.info(_db_path)
            if os.path.exists(os.path.join(_db_path, 'chroma.sqlite3')):
                db = Chroma(collection_name=str(user_id),
                            persist_directory=os.path.join(env.PERSIST_DIRECTORY, user_id),
                            embedding_function=embeddings,
                            client_settings=env.CHROMA_SETTINGS)
                retriever = db.as_retriever(search_kwargs={"k": top_k})

                config = {
                    "context_length": params.get("ContextLength", env.MODEL_N_CTX),
                    "max_new_tokens": params.get("MaxToken", env.MAX_TOKEN),
                    "threads": params.get("n_threads", env.MODEL_N_THREADS),
                    "repetition_penalty": params.get("Penalty", 1.1),
                    "temperature": params.get("Temperature", 0.5),
                    # "stream": True,
                    "reset": True
                }
                from langchain.llms import CTransformers
                input_model_name = env.MODEL_FILE_PATH
                if env.local_model:
                    input_model_type = "llama"
                else:
                    input_model_type = "gptq"
                logger.info(config)
                llm = CTransformers(model=input_model_name,
                                    model_type=input_model_type,
                                    config=config
                                    )
                logger.info(f"llm-gpu {input_model_name} configured completed..")
                qa = RetrievalQA.from_chain_type(llm=llm,
                                                 chain_type="stuff",
                                                 retriever=retriever,
                                                 chain_type_kwargs={"prompt": QA_PROMPT},
                                                 return_source_documents=True)
                print("END to END: Q & A Model is configured....")
                _start_time = time.time()
                res = qa(input_query)
                answer, docs = res['result'], res['source_documents']
                answer = trim_incomplete_sentence(answer)
                _end_time = time.time()
                source_data = [{"doc_name": "Prompt", 'source_content': QA_PROMPT }]
                for document in docs:
                    source_data.append(
                        {
                            "doc_name": document.metadata["source"],
                            'source_content': document.page_content}
                    )
                results_ = {"query": input_query,
                            "answer": answer,
                            "source": source_data,
                            "retrieval_time": round(_end_time - _start_time, 2)
                            }
                if not env.local_model:
                    cuda_memory_info()
                logger.info(results_)
                del llm
                del qa
                import gc
                gc.collect()
                return results_
            else:
                results_ = {
                    "query": input_query,
                    "answer": "There is no data available for user, please add the relevant document",
                    "source": [{"doc_name": "<>", "source_content": "<>"}]
                }
                logger.info(results_)
                return results_
        except Exception as ex:
            raise Exception(ex)

    def op_refresh_db(self):
        try:
            self.db = None
            self.db = OpenSearchVectorSearch(
                index_name=LLM_DEFAULT_USER,
                embedding_function=embeddings,
                http_auth=opensearch_credentials,
                opensearch_url=opensearch_host_url,
                use_ssl=True,
                verify_certs=True,
                ssl_show_warn=False,
                timeout=300,
                connection_class=RequestsHttpConnection
            )
            retriever = self.db.as_retriever(search_kwargs={"k": env.TARGET_SOURCE_CHUNKS})
            self.qa = RetrievalQA.from_chain_type(llm=self.llm,
                                                  chain_type="stuff",
                                                  retriever=retriever,
                                                  chain_type_kwargs={"prompt": QA_PROMPT},
                                                  return_source_documents=True)
            logger.info("Q & A Model is configured....")
            return True
        except Exception as ex:
            logger.warning(ex)
            return False

    def op_db_connect(self, input_query, user_id):
        try:
            all_indices = opensearch_client.cat.indices(format='json')
            indices_list = [index['index'] for index in all_indices]

            if user_id in indices_list:
                db = OpenSearchVectorSearch(
                    index_name=user_id,
                    embedding_function=embeddings,
                    http_auth=opensearch_credentials,
                    opensearch_url=opensearch_host_url,
                    use_ssl=True,
                    verify_certs=True,
                    ssl_show_warn=False,
                    timeout=300,
                    connection_class=RequestsHttpConnection
                )
                retriever = db.as_retriever(search_kwargs={"k": env.TARGET_SOURCE_CHUNKS})
                # _documents = retriever.get_relevant_documents(query=input_query)
                # _pair = [[input_query, doc.page_content] for doc in _documents]
                # logger.info(_pair)
                # _scores = get_re_rank_score(_pair)
                # mapped  = zip(_pair, _scores)
                # logger.info(list(mapped))
                qa = RetrievalQA.from_chain_type(llm=self.load_model(),
                                                 chain_type="stuff",
                                                 retriever=retriever,
                                                 chain_type_kwargs={"prompt": QA_PROMPT},
                                                 return_source_documents=True)
                logger.info("Q & A Model is configured....")
                return qa
            else:
                logger.error("No User Data found")
                return False
        except Exception as ex:
            logger.error(ex)
            return False

    def op_connect_llm_qa_model(self, input_query: str, user_id: str):
        if not env.local_model: cuda_memory_info()
        logger.info(f"QAndAModel- input_query:{input_query}")
        logger.info(f"QAndAModel- user_id:{user_id}")

        if user_id is not None and input_query is not None and input_query != "":
            try:
                all_indices = opensearch_client.cat.indices(format='json')
                indices_list = [index['index'] for index in all_indices]

                if user_id in indices_list:
                    db = OpenSearchVectorSearch(
                        index_name=user_id,
                        embedding_function=embeddings,
                        http_auth=opensearch_credentials,
                        opensearch_url=opensearch_host_url,
                        use_ssl=True,
                        verify_certs=True,
                        ssl_show_warn=False,
                        timeout=300,
                        connection_class=RequestsHttpConnection
                    )
                    retriever = db.as_retriever(search_kwargs={"k": env.TARGET_SOURCE_CHUNKS})
                    qa = RetrievalQA.from_chain_type(llm=self.load_model(),
                                                     chain_type="stuff",
                                                     retriever=retriever,
                                                     chain_type_kwargs={"prompt": QA_PROMPT},
                                                     return_source_documents=True)
                    logger.info("Q & A Model is configured....")
                    _start_time = time.time()
                    res = qa(input_query)
                    answer, docs = res['result'], res['source_documents']
                    answer = trim_incomplete_sentence(answer)
                    _end_time = time.time()
                    source_data = []
                    for document in docs:
                        source_data.append(
                            {"doc_name": document.metadata["source"], 'source_content': document.page_content})

                    results_ = {"query": input_query,
                                "answer": answer,
                                "source": source_data,
                                "status": 200,
                                "retrieval_time": round(_end_time - _start_time, 2)
                                }
                    logger.info(f"qa_results: {results_}")
                    if not env.local_model: cuda_memory_info()
                    return results_
                else:
                    results_ = {
                        "query": input_query,
                        "answer": "There is no data available for user, please add the relevant document",
                        "source": [{"doc_name": "<>", "source_content": "<>"}],
                        "status": 201,
                    }
                    if not env.local_model: cuda_memory_info()
                    return results_
            except Exception as ex:
                logger.error(str(ex))
                return {"query": input_query, "answer": str(ex),
                        "source": [{"doc_name": "<>", "source_content": "<>"}], "status": 400, }
        return {"message": "Empty Query", "status": 201}

    @staticmethod
    def op_end_to_end_model_flow(params: dict):
        if not env.local_model: cuda_memory_info()
        try:
            user_id = params.get("user_id")
            input_query = params.get("query")
            # input_sys_prompt = params.get("DefaultPrompt", system_prompt)

            top_k = params.get("top_k", env.TARGET_SOURCE_CHUNKS)

            all_indices = opensearch_client.cat.indices(format='json')
            indices_list = [index['index'] for index in all_indices]
            if user_id in indices_list:
                db = OpenSearchVectorSearch(
                    index_name=user_id,
                    embedding_function=embeddings,
                    http_auth=opensearch_credentials,
                    opensearch_url=opensearch_host_url,
                    use_ssl=True,
                    verify_certs=True,
                    ssl_show_warn=False,
                    timeout=300,
                    connection_class=RequestsHttpConnection
                )
                retriever = db.as_retriever(search_kwargs={"k": top_k})
                config = {
                    "context_length": params.get("ContextLength", env.MODEL_N_CTX),
                    "max_new_tokens": params.get("MaxToken", env.MAX_TOKEN),
                    "threads": params.get("n_threads", env.MODEL_N_THREADS),
                    "repetition_penalty": params.get("Penalty", 1.1),
                    "temperature": params.get("Temperature", env.TEMPERATURE),
                    # "stream": True,
                    "reset": True
                }
                from langchain.llms import CTransformers
                if env.local_model:
                    input_model_name = env.MODEL_FILE_PATH
                    input_model_type = "llama"
                    # config['gpu_layers'] = 35
                else:
                    input_model_name = "TheBloke/zephyr-7B-alpha-GPTQ"
                    input_model_type = "gptq"

                logger.info(config)
                llm = CTransformers(model=input_model_name,
                                    model_type=input_model_type,
                                    config=config
                                    )

                logger.info("llm-gpu model configured completed..")
                qa = RetrievalQA.from_chain_type(llm=llm,
                                                 chain_type="stuff",
                                                 retriever=retriever,
                                                 chain_type_kwargs={"prompt": QA_PROMPT},
                                                 return_source_documents=True)
                print("END to END: Q & A Model is configured....")
                _start_time = time.time()
                res = qa(input_query)
                answer, docs = res['result'], res['source_documents']
                answer = trim_incomplete_sentence(answer)
                _end_time = time.time()
                source_data = [{"doc_name": "Prompt", 'source_content': QA_PROMPT}]
                for document in docs:
                    source_data.append(
                        {
                            "doc_name": document.metadata["source"],
                            'source_content': document.page_content}
                    )
                results_ = {"query": input_query,
                            "answer": answer,
                            "source": source_data,
                            "retrieval_time": round(_end_time - _start_time, 2)
                            }
                if not env.local_model:
                    cuda_memory_info()
                logger.info(results_)
                del llm
                del qa
                import gc
                gc.collect()
                return results_
            else:
                results_ = {
                    "query": input_query,
                    "answer": "There is no data available for user, please add the relevant document",
                    "source": [{"doc_name": "<>", "source_content": "<>"}]
                }
                logger.info(results_)
                return results_
        except Exception as ex:
            raise Exception(ex)


if __name__ == '__main__':
    print("This is main call for this module, used for Unittest/Dry Run")
    # Get the answer from the chain
    start_time = time.time()
    from src.ingestion import DBIngestion

    print("This is main call for this module, used for Unittest/Dry Run")
    ingestionObj = DBIngestion()
    print(ingestionObj.status)
    qaObject = QAndAModel()
    while True:
        query = input("enter the input query: ")
        if query == 'exit':
            break
        # Get the answer from the chain
        end_time = time.time()
        print("TIME GAP", round(end_time - start_time, 2))
        results = qaObject.connect_llm_qa_model(query, env.LLM_DEFAULT_USER)
        print(results)
