#!/usr/bin/env python3
import os
import glob
from typing import List
from multiprocessing import Pool
from tqdm import tqdm

from langchain.docstore.document import Document
from langchain.document_loaders import (
    CSVLoader,
    EverNoteLoader,
    # PDFMinerLoader,
    PyMuPDFLoader,
    TextLoader,
    UnstructuredEmailLoader,
    UnstructuredEPubLoader,
    UnstructuredHTMLLoader,
    UnstructuredMarkdownLoader,
    UnstructuredODTLoader,
    UnstructuredPowerPointLoader,
    UnstructuredWordDocumentLoader,
    # Docx2txtLoader,
    UnstructuredExcelLoader
)

from util import logger
logger = logger.getlogger()

class MyElmLoader(UnstructuredEmailLoader):
    """Wrapper to fallback to text/plain when default does not work"""

    def load(self) -> List[Document]:
        """Wrapper adding fallback for elm without html"""
        try:
            try:
                doc = UnstructuredEmailLoader.load(self)
            except ValueError as e:
                if 'text/html content not found in email' in str(e):
                    # Try plain text
                    self.unstructured_kwargs["content_source"] = "text/plain"
                    doc = UnstructuredEmailLoader.load(self)
                else:
                    raise
        except Exception as e:
            # Add file_path to exception message
            raise type(e)(f"{self.file_path}: {e}") from e

        return doc


# Map file extensions to document loaders and their arguments
LOADER_MAPPING = {
    ".csv": (CSVLoader, {}),
    ".doc": (UnstructuredWordDocumentLoader, {}),
    ".DOC": (UnstructuredWordDocumentLoader, {}),
    # ".doc": (UnstructuredWordDocumentLoader, {}),
    # ".docx": (Docx2txtLoader, {}),
    ".docx": (UnstructuredWordDocumentLoader, {}),
    ".DOCX": (UnstructuredWordDocumentLoader, {}),
    ".enex": (EverNoteLoader, {}),
    ".eml": (MyElmLoader, {}),
    ".epub": (UnstructuredEPubLoader, {}),
    ".html": (UnstructuredHTMLLoader, {}),
    ".md": (UnstructuredMarkdownLoader, {}),
    ".odt": (UnstructuredODTLoader, {}),
    # ".pdf": (PDFMinerLoader, {}),
    ".pdf": (PyMuPDFLoader, {}),
    ".PDF": (PyMuPDFLoader, {}),
    ".ppt": (UnstructuredPowerPointLoader, {}),
    ".pptx": (UnstructuredPowerPointLoader, {}),
    ".txt": (TextLoader, {"encoding": "utf8"}),
    ".xlsx": (UnstructuredExcelLoader, {"mode": "elements"})
    # Add more mappings for other file extensions and loaders as needed
}


def load_single_document(file_path: str):
    try:
        logger.info(f'loading the document from path: {file_path}')
        ext = "." + file_path.rsplit(".", 1)[-1]
        logger.info(f"document extension {ext} : {file_path}")
        if ext.lower() in LOADER_MAPPING:
            loader_class, loader_args = LOADER_MAPPING[str(ext.lower())]
            loader = loader_class(file_path, **loader_args)
            return loader.load()
        logger.error(f"Unsupported file extension '{ext}'")
        return None
    except Exception as ex:
        logger.error(f"Failed to ingest to llm : {file_path}")
        logger.error(ex)
        return None


def load_documents(source_dir: str, ignored_files: List[str] = []) -> List[Document]:
    """
    Loads all documents from the source documents directory, ignoring specified files
    """
    try:
        all_files = []
        for ext in LOADER_MAPPING:
            all_files.extend(
                glob.glob(os.path.join(source_dir, f"**/*{ext}"), recursive=True)
            )
        filtered_files = [file_path for file_path in all_files if file_path not in ignored_files]

        # This is causing for the multiple logger (multi threading block)
        # with Pool(processes=os.cpu_count()) as pool:
        #     results = []
        #     with tqdm(total=len(filtered_files), desc='Loading new documents', ncols=80) as pbar:
        #         for i, docs in enumerate(pool.imap_unordered(load_single_document, filtered_files)):
        #             results.extend(docs)
        #             pbar.update()

        results = []
        for _file_path in filtered_files:
            docs = load_single_document(_file_path)
            if docs is not None:
                results.extend(docs)
        return results

    except Exception as Ex:
        logger.warning(Ex)
        logger.info(f"Error at load documents.. and dir {source_dir}")
