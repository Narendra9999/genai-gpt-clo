#!pip install llmware

# !python --version
# !python3 -m pip install llmware
# !pip install -U sentence-transformers
# !pip install transformers -U
#!pip install -q transformers peft  accelerate bitsandbytes safetensors sentencepiece streamlit  sentence-transformers gradio pypdf
#!pip install -q peft  accelerate bitsandbytes safetensors sentencepiece streamlit  sentence-transformers gradio pypdf

# import torch
# from transformers import AutoTokenizer, AutoModelForCausalLM
# device = torch.device('mps')
# tokenizer = AutoTokenizer.from_pretrained("../llmware/dragon-llama-7b-v0")
# model = AutoModelForCausalLM.from_pretrained("../llmware/dragon-llama-7b-v0").to(device)

# from llmware.prompts import Prompt
# import torch
#
# #model_name = "llmware/dragon-llama-7b-v0"
# model_name = "llmware/dragon-mistral-7b-v0"
#
# device = torch.device('mps')
# prompter = Prompt().load_model(model_name)
# #, from_hf=from_hf, api_key="dummy_not_used_by_hf")
#
#
#
# test_list = [
#     {"query": "What is the total amount of the invoice?",
#      "answer": "$22,500.00",
#      "context": "Services Vendor Inc. \n100 Elm Street Pleasantville, NY \nTO Alpha Inc. 5900 1st Street "
#                 "Los Angeles, CA \nDescription Front End Engineering Service $5000.00 \n Back End Engineering"
#                 " Service $7500.00 \n Quality Assurance Manager $10,000.00 \n Total Amount $22,500.00 \n"
#                 "Make all checks payable to Services Vendor Inc. Payment is due within 30 days."
#                 "If you have any questions concerning this invoice, contact Bia Hermes. "
#                 "THANK YOU FOR YOUR BUSINESS!  INVOICE INVOICE # 0001 DATE 01/01/2022 FOR Alpha Project P.O. # 1000"}]
#
#
# for i, entries in enumerate(test_list):
#     print(f"\n{i+1}. Query: {entries['query']}")
#      # run the prompt
#     output = prompter.prompt_main(entries["query"],context=entries["context"]
#                                       , prompt_name="default_with_context",temperature=0.30)
#
#     llm_response = output["llm_response"].strip("\n")
#     print(f"LLM Response: {llm_response}")
#