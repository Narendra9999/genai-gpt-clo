#
# # # pip install -U FlagEmbedding
# #
# import torch
# from transformers import AutoModelForSequenceClassification, AutoTokenizer
#
# _tokenizer = AutoTokenizer.from_pretrained('BAAI/bge-reranker-large')
# _model = AutoModelForSequenceClassification.from_pretrained('BAAI/bge-reranker-large')
# _model.eval()
#
#
# def get_re_rank_score(pairs):
#     with torch.no_grad():
#         inputs = _tokenizer(pairs, padding=True, truncation=True, return_tensors='pt', max_length=512)
#         scores = _model(**inputs, return_dict=True).logits.view(-1, ).float()
#         return scores
#
# # # from FlagEmbedding import FlagReranker
# # # reranker = FlagReranker('BAAI/bge-reranker-large', use_fp16=True) # Setting use_fp16 to True speeds up computation with a slight performance degradation
# # #
# # # score = reranker.compute_score(['query', 'passage'])
# # # print(score)
# # #
# # # scores = reranker.compute_score([['what is panda?', 'hi'], ['what is panda?', 'The giant panda (Ailuropoda melanoleuca), sometimes called a panda bear or simply panda, is a bear species endemic to China.']])
# # # print(scores)
