import os
import glob
import time
from typing import List
from measure_exec_time import measure_time
# from langchain.docstore.document import Document

from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.vectorstores import Chroma
from langchain.vectorstores import OpenSearchVectorSearch
from opensearchpy import RequestsHttpConnection

from util import env, logger, common_functions
from util.document_init_sample.spgi_about import txt_message

from src.nlp_config import embeddings, cuda_memory_info
from src.document_upload_type import load_documents

logger = logger.getlogger()
from util.env import (
    PERSIST_DIRECTORY,
    SOURCE_DIRECTORY,
    CHROMA_SETTINGS,
    chunk_size,
    chunk_overlap,
    opensearch_credentials,
    opensearch_client,
    opensearch_host_url
)

from util.s3utils import S3FileManager

global_s3_bucket_name = env.global_s3_bucket_name
documents_s3_loc = env.documents_s3_loc
s3_file_manager = S3FileManager(global_s3_bucket_name)
CHROMADB = env.CHROMADB


class DBIngestion:
    def __init__(self):
        if CHROMADB:
            self.status = self.ingest_data_to_vector_db(user_id=env.LLM_DEFAULT_USER)
        else:
            self.status = self.op_ingest_data_to_vector_db(user_id=env.LLM_DEFAULT_USER)
        logger.info(f"VECTOR DB Ingestion -initialize ingestion call status {self.status}")

    @staticmethod
    def vector_db_exist(persist_directory_: str) -> bool:
        """
        Checks if vector store exists
        """
        if os.path.exists(os.path.join(persist_directory_, 'index')):
            if os.path.exists(os.path.join(persist_directory_, 'chroma-collections.parquet')) and os.path.exists(
                    os.path.join(persist_directory_, 'chroma-embeddings.parquet')):
                list_index_files = glob.glob(os.path.join(persist_directory_, 'index/*.bin'))
                list_index_files += glob.glob(os.path.join(persist_directory_, 'index/*.pkl'))
                if len(list_index_files) > 3:
                    return True
        return False

    @staticmethod
    def process_documents(ignored_files: List[str] = [], _source_dir=None):
        """
        Load documents and split in chunks
        """
        if _source_dir is None: _source_dir = SOURCE_DIRECTORY
        logger.info(f"Loading documents from {_source_dir}")
        documents = load_documents(_source_dir, ignored_files)
        if not documents:
            logger.info("No new documents to load")
            return None
        logger.info(f"Loaded {len(documents)} documents from {_source_dir}")
        text_splitter = RecursiveCharacterTextSplitter(chunk_size=chunk_size, chunk_overlap=chunk_overlap)
        texts = text_splitter.split_documents(documents)
        logger.info(f"Split into {len(texts)} chunks of text (max. {chunk_size} characters each)")
        return texts

    @staticmethod
    def user_based_source_s3_directory(user_id_):
        _dir_loc = {"s3_loc": documents_s3_loc, "source_dir": SOURCE_DIRECTORY}

        if user_id_ is not None:
            _user_loc = os.path.join(SOURCE_DIRECTORY, user_id_)
            common_functions.create_dir_if_not_exist(_user_loc)
            _dir_loc["s3_loc"] = documents_s3_loc + user_id_ + "/"
            _dir_loc['source_dir'] = os.path.join(SOURCE_DIRECTORY, user_id_)
        logger.info(f"document location s3 --> source document")
        logger.info(_dir_loc)
        return _dir_loc

    def refresh_vector_db(self, user_id=None):
        """
        This is method to create vector db with new documents
        """
        if not env.local_model:
            dir_loc = self.user_based_source_s3_directory(user_id)
            if s3_file_manager.get_filesFromS3Bucket(dir_loc['s3_loc'], dir_loc['source_dir']):
                logger.info('Successfully Copied Users specific files to source directory!!!')
            else:
                logger.info('Failed to copy S3 files to source directory!!!')

        if CHROMADB:
            return self.ingest_data_to_vector_db(user_id)
        else:
            return self.op_ingest_data_to_vector_db(user_id)

    @measure_time(show_timedelta=True, show_start_end=False)
    def multi_process_ingest(self, i_persist_directory, i_source_directory, i_user_id):
        import threading
        """Update and store locally vector store"""
        logger.info(f"Appending to existing vector store at {i_persist_directory}")
        if not env.local_model:
            from pathlib import Path
            files = [i_persist_directory]
            for file in files: Path(file).chmod(0o0777)

        db = Chroma(collection_name=str(i_user_id),
                    persist_directory=i_persist_directory,
                    embedding_function=embeddings,
                    client_settings=env.CHROMA_SETTINGS)
        collection = db.get()
        ignore_file_lst = list(set([metadata['source'] for metadata in collection['metadatas']]))
        texts = self.process_documents(ignore_file_lst, _source_dir=i_source_directory)

        def add_text_document_chunk(dbobj, text_chunk):
            dbobj.add_documents(text_chunk)
            # dbobj.persist()

        if texts:
            logger.info(f"Creating embeddings. May take some minutes...")
            num_threads = os.cpu_count() - 2
            chunk_size_ = len(texts) // num_threads
            if chunk_size_ == 0: chunk_size_ = 1
            chunks_in = [texts[i:i + chunk_size_] for i in range(0, len(texts), chunk_size_)]
            logger.info(f"max : {len(chunks_in)} Threads/MultiProcess can be applicable..")

            thread_pool = []
            for chunk_in in chunks_in:
                thread = threading.Thread(target=add_text_document_chunk, args=(db, chunk_in))
                thread.start()
                time.sleep(.5)
                thread_pool.append(thread)

            # wait for all threads to complete
            for thread in thread_pool:
                thread.join()
            logger.info("document ingested completed...")

        db.persist()
        logger.info("DB persist is completed for the document")
        del db

    @measure_time(show_timedelta=True, show_start_end=False)
    def ingest_data_to_vector_db(self, user_id: str = None):
        """
        refers to a process where data is sourced from a document folder and ingested into a vector database.
        This method provides functionality to extract relevant information from documents within a specified folder and store
        it in a vector database for further analysis or retrieval.
        :return: True or False
        """
        if not env.local_model:
            cuda_memory_info()
        try:
            if user_id is not None:
                _persist_directory = os.path.join(env.PERSIST_DIRECTORY, user_id)
                _source_directory = os.path.join(env.SOURCE_DIRECTORY, user_id)
                common_functions.create_dir_if_not_exist(_persist_directory)
                common_functions.create_dir_if_not_exist(_source_directory)
            else:
                user_id = env.LLM_DEFAULT_USER
                _persist_directory = os.path.join(env.PERSIST_DIRECTORY, env.LLM_DEFAULT_USER)
                _source_directory = os.path.join(env.SOURCE_DIRECTORY, env.LLM_DEFAULT_USER)

            logger.info(f"Persist dir-read/write permissions?:{os.access(str(_persist_directory), os.X_OK | os.W_OK)}")
            logger.info(f" persist_directory{_persist_directory}")

            if os.path.exists(os.path.join(_persist_directory, 'chroma.sqlite3')):
                self.multi_process_ingest(_persist_directory, _source_directory, user_id)
            else:
                """Create and store locally vector store"""
                texts = self.process_documents(_source_dir=_source_directory)
                if texts:
                    logger.info("init: Creating embeddings. May take some minutes...")
                    db = Chroma.from_documents(texts,
                                               embedding=embeddings,
                                               persist_directory=_persist_directory,
                                               client_settings=CHROMA_SETTINGS,
                                               collection_name=str(user_id)
                                               )

                    logger.info(f"Persist location : {_persist_directory}")
                    logger.info("Will be calling persist.. ")
                    db.persist()
                    logger.info("DB persist is completed for the document")
                    del db
            logger.info("Ingestion complete! You can now run /gpt/chat service with query")
            return True
        except Exception as ex:
            logger.warning(ex)
            logger.warning("Issues at ingest_data_to_vector_db..")
            return False

    @staticmethod
    def delete_document_embeddings(document_name, user_id: str):
        try:
            db = Chroma(collection_name=str(user_id),
                        persist_directory=os.path.join(PERSIST_DIRECTORY, user_id),
                        embedding_function=embeddings,
                        client_settings=CHROMA_SETTINGS)
            collection = db.get()
            ids = collection.get('ids')
            meta_data = collection.get('metadatas')
            if ids:
                found_match = False
                found_ids = []
                for id_, meta in zip(ids, meta_data):
                    if os.path.basename(meta["source"]) == document_name:
                        found_ids.append(id_)
                        found_match = True
                    elif found_match:
                        logger.info("Document found: " + document_name)
                        logger.info("Following are the ids of the document: " + document_name)
                        logger.info(set(found_ids))
                        break

                if len(set(found_ids)) == 0:
                    logger.error("The document is not present in collection. Upload the document and run the"
                                 "refresh endpoint to ingest the embeddings or just run the ingest if the "
                                 "document is already uploaded. ")
                    return False
                else:
                    db.delete(found_ids)
                    return True
            else:
                return False
        except Exception as ex:
            logger.error(ex)

    @staticmethod
    def delete_all_embeddings(user_id: str = None):
        try:
            _user_persist_directory = os.path.join(PERSIST_DIRECTORY, user_id)
            _user_source_directory = os.path.join(SOURCE_DIRECTORY, user_id)
            logger.info(f"user_persist_directory: {_user_persist_directory}")
            logger.info(f"user_source_directory: {_user_source_directory}")
            _db = Chroma(collection_name=str(user_id),
                         persist_directory=_user_persist_directory,
                         embedding_function=embeddings,
                         client_settings=env.CHROMA_SETTINGS)
            _db.delete_collection()
            _db.persist()
            del _db
            # common_functions.delete_dir_if_exist(_user_persist_directory)
            common_functions.delete_dir_if_exist(_user_source_directory)
            # common_functions.create_dir_if_not_exist(_user_persist_directory)
            common_functions.create_dir_if_not_exist(_user_source_directory)
            # with open(str(os.path.join(_user_source_directory, "about_spglobal.txt")), "w") as file:
            #     file.write(str(txt_message))
        except Exception as ex:
            logger.error(ex)

    @staticmethod
    def get_vector_db_metadata(user_id: str = None):
        try:
            if user_id is not None:
                logger.info(f"Getting vector db metadata {os.path.join(PERSIST_DIRECTORY, user_id)}")
                _user_persist_directory = os.path.join(PERSIST_DIRECTORY, user_id)
                _db = Chroma(collection_name=str(user_id),
                             persist_directory=_user_persist_directory,
                             embedding_function=embeddings,
                             client_settings=CHROMA_SETTINGS)
                collection = _db.get()
                metadata_list = collection['metadatas']
                metadata_list = set([src_doc['source'] for src_doc in metadata_list])
                logger.info(metadata_list)
                file_names = set()
                for metadata in metadata_list:
                    # filename = metadata['source'].split('\\')[-1]
                    filename = metadata.split('\\')[-1]
                    file_names.add(filename)
                _db.persist()
                del _db
                return file_names
            else:
                return {"Empty User ID"}
        except Exception as ex:
            logger.error(ex)

    def get_document_embeddings_list(self, user_id: str = None):
        try:
            document_list = set()
            document_names = self.get_vector_db_metadata(user_id)
            for document in document_names:
                file_name = document.split('/')[-1]
                if file_name != "sample_mount.txt" or file_name != "about_spglobal.txt":
                    document_list.add(file_name)
            return list(document_list)
        except Exception as ex:
            logger.info(ex)

    @measure_time(show_timedelta=True, show_start_end=False)
    def op_multi_process_ingest(self, i_persist_directory, i_source_directory, i_user_id):
        import threading
        """Update and store locally vector store"""
        # logger.info(f"Appending to existing vector store at {i_persist_directory}")
        db = OpenSearchVectorSearch(
            index_name=i_user_id,
            embedding_function=embeddings,
            http_auth=opensearch_credentials,
            opensearch_url=opensearch_host_url,
            use_ssl=True,
            verify_certs=True,
            ssl_show_warn=False,
            timeout=300,
            connection_class=RequestsHttpConnection
        )

        query = {
            "query": {
                "match_all": {}
            }
        }
        initial_scroll = opensearch_client.search(index=i_user_id, body=query, _source=["metadata.source"],
                                                  scroll="2m", size=1000)

        all_documents = initial_scroll['hits']['hits']
        if not initial_scroll['hits']['hits']:
            print("no documents found in the initial scroll")
            scroll_id = initial_scroll["_scroll_id"]

            while True:
                page = opensearch_client.scroll(scroll_id=scroll_id, scroll="2m")

                # error handling
                if page.get('_shard', {}).get('failed', 0) > 0:
                    print("error occurred during scrolling")
                    break

                scroll_id = page['_scroll_id']
                if not page['hits']['hits']:
                    print("no more documents to scroll")
                    break

                all_documents.extend(page['hits']['hits'])
            opensearch_client.clear_scroll(scroll_id=scroll_id)

        ignore_file_lst = list(set([doc["_source"]["metadata"]["source"] for doc in all_documents]))
        texts = self.process_documents(ignore_file_lst, _source_dir=i_source_directory)

        def add_text_document_chunk(dbobj, text_chunk):
            dbobj.add_documents(documents=text_chunk, bulk_size=len(texts) + 5)
            # dbobj.persist()

        if texts:
            logger.info(f"Creating embeddings. May take some minutes...")
            num_threads = os.cpu_count() - 2
            chunk_size_ = len(texts) // num_threads
            if chunk_size_ == 0: chunk_size_ = 1
            chunks_in = [texts[i:i + chunk_size_] for i in range(0, len(texts), chunk_size_)]
            logger.info(f"max : {len(chunks_in)} Threads/MultiProcess can be applicable..")

            thread_pool = []
            for chunk_in in chunks_in:
                thread = threading.Thread(target=add_text_document_chunk, args=(db, chunk_in))
                thread.start()
                time.sleep(.5)
                thread_pool.append(thread)

            # wait for all threads to complete
            for thread in thread_pool:
                thread.join()
            logger.info("document ingested completed...")

        # db.persist()
        logger.info("DB persist is completed for the document")
        del db

    @measure_time(show_timedelta=True, show_start_end=False)
    def op_ingest_data_to_vector_db(self, user_id: str = None):
        """
        refers to a process where data is sourced from a document folder and ingested into a vector database.
        This method provides functionality to extract relevant information from documents within a specified folder and store
        it in a vector database for further analysis or retrieval.
        :return: True or False
        """
        if not env.local_model:
            cuda_memory_info()
        try:
            if user_id is not None:
                _source_directory = os.path.join(env.SOURCE_DIRECTORY, user_id)
                common_functions.create_dir_if_not_exist(_source_directory)
            else:
                user_id = env.LLM_DEFAULT_USER
                _source_directory = os.path.join(env.SOURCE_DIRECTORY, env.LLM_DEFAULT_USER)

            all_indices = opensearch_client.cat.indices(format='json')
            indices_list = [index['index'] for index in all_indices]

            if user_id in indices_list:
                self.op_multi_process_ingest(i_persist_directory="", i_source_directory=_source_directory,
                                             i_user_id=user_id)
            else:
                """Create and store locally vector store"""
                texts = self.process_documents(_source_dir=_source_directory)
                if texts:
                    logger.info("New Users: Creating embeddings. May take some minutes...")
                    db = OpenSearchVectorSearch.from_documents(
                        documents=texts,
                        embedding=embeddings,
                        opensearch_url=opensearch_host_url,
                        http_auth=opensearch_credentials,
                        timeout=300,
                        use_ssl=True,
                        verify_certs=True,
                        connection_class=RequestsHttpConnection,
                        index_name=user_id,
                        bulk_size=len(texts) + 5
                    )
                    logger.info("DB persist is completed for the document")
                    del db
            logger.info("Ingestion complete! You can now run /gpt/chat service with query")
            return True
        except Exception as ex:
            logger.warning(ex)
            logger.warning("Issues at ingest_data_to_vector_db..")
            return False

    @staticmethod
    def op_delete_document_embeddings(document_name, user_id: str):
        logger.info("op_delete_document_embeddings....")
        try:
            # opensearch_client.indices.refresh(index=user_id)
            query = {
                "query": {
                    "match_all": {}
                }
            }
            initial_scroll = opensearch_client.search(index=user_id, body=query, _source=["metadata.source"],
                                                      scroll="2m", size=1000)

            if not initial_scroll['hits']['hits']:
                logger.info("no documents/embeddings found in the user id")
                return None

            all_documents = initial_scroll['hits']['hits']
            scroll_id = initial_scroll["_scroll_id"]
            match_ids = []

            while True:
                page = opensearch_client.scroll(scroll_id=scroll_id, scroll="2m")

                # error handling
                if page.get('_shard', {}).get('failed', 0) > 0:
                    logger.error("error occurred during scrolling")
                    break

                scroll_id = page['_scroll_id']
                if not page['hits']['hits']:
                    logger.info("scrolling completed, no more documents have to be fetch")
                    break

                all_documents.extend(page['hits']['hits'])
            opensearch_client.clear_scroll(scroll_id=scroll_id)

            if all_documents:
                for doc in all_documents:
                    doc_path = doc["_source"]["metadata"]["source"]
                    if doc_path.split(os.path.sep)[-1] == document_name:
                        match_ids.append(doc["_id"])

                if match_ids:
                    logger.info("match ids founds for delete")
                    for doc_id in match_ids:
                        opensearch_client.delete(index=user_id, id=doc_id)
                    opensearch_client.indices.refresh(index=user_id)
                    return True
                else:
                    logger.info(f"no ids found for {document_name} in database")
                    return False
            else:
                logger.info(f" {document_name} not in database")
                return False
        except Exception as ex:
            logger.error(ex)

    @staticmethod
    def op_delete_all_embeddings(user_id: str = None):
        try:
            all_indices = opensearch_client.cat.indices(format='json')
            indices_list = [index['index'] for index in all_indices]

            if user_id is not None and user_id in indices_list:
                _user_source_directory = os.path.join(SOURCE_DIRECTORY, user_id)
                common_functions.delete_dir_if_exist(_user_source_directory)
                common_functions.create_dir_if_not_exist(_user_source_directory)

                query = {
                    "query": {
                        "match_all": {}
                    }
                }
                response_mes = opensearch_client.delete_by_query(index=user_id, body=query)
                logger.info(response_mes)
                opensearch_client.indices.refresh(index=user_id)

                initial_scroll = opensearch_client.search(index=user_id, body=query, _source=["metadata.source"],
                                                          scroll="2m", size=1000)

                if not initial_scroll['hits']['hits']:
                    logger.error("no documents found in scrolling")
                    return None
                scroll_id = initial_scroll["_scroll_id"]

                all_documents = initial_scroll['hits']['hits']
                while True:
                    page = opensearch_client.scroll(scroll_id=scroll_id, scroll="2m")

                    # error handling
                    if page.get('_shard', {}).get('failed', 0) > 0:
                        logger.error("error occurred during scrolling")
                        break

                    scroll_id = page['_scroll_id']
                    if not page['hits']['hits']:
                        logger.info("no more documents to scroll")
                        break

                    all_documents.extend(page['hits']['hits'])
                opensearch_client.clear_scroll(scroll_id=scroll_id)

                if all_documents:
                    for doc in all_documents:
                        opensearch_client.delete(index=user_id, id=doc["_id"])
                    opensearch_client.indices.refresh(index=user_id)
                else:
                    logger.info("no documents found")
            else:
                logger.error("no user found")

        except Exception as ex:
            logger.error(ex)

    @staticmethod
    def op_get_vector_db_metadata(user_id: str = None):
        try:
            all_indices = opensearch_client.cat.indices(format='json')
            indices_list = [index['index'] for index in all_indices]
            if user_id is not None and user_id in indices_list:
                logger.info(f"User id Present in indices {user_id}")
                query = {
                    "query": {
                        "match_all": {}
                    }
                }
                initial_scroll = opensearch_client.search(index=user_id, body=query, _source=["metadata.source"],
                                                          scroll="2m", size=1000)
                if not initial_scroll['hits']['hits']:
                    print("no documents found in the initial scroll")
                    return []

                all_documents = initial_scroll['hits']['hits']
                scroll_id = initial_scroll["_scroll_id"]

                while True:
                    page = opensearch_client.scroll(scroll_id=scroll_id, scroll="2m")

                    # error handling
                    if page.get('_shard', {}).get('failed', 0) > 0:
                        print("error occurred during scrolling")
                        break

                    scroll_id = page['_scroll_id']
                    if not page['hits']['hits']:
                        print("no more documents to scroll")
                        break

                    all_documents.extend(page['hits']['hits'])
                opensearch_client.clear_scroll(scroll_id=scroll_id)

                metadata_list = list(set([doc["_source"]["metadata"]["source"] for doc in all_documents]))
                logger.info(metadata_list)
                file_names = set()
                for metadata in metadata_list:
                    filename = metadata.split('\\')[-1]
                    file_names.add(filename)
                return file_names
            else:
                logger.info("User id not Present... ")
                return []
        except Exception as ex:
            logger.error(ex)

    def op_get_document_embeddings_list(self, user_id: str = None):
        try:
            document_list = set()
            document_names = self.op_get_vector_db_metadata(user_id)
            for document in document_names:
                file_name = document.split('/')[-1]
                document_list.add(file_name)
            return list(document_list)
        except Exception as ex:
            logger.info(ex)


if __name__ == '__main__':
    print("This is main call for this module, used for Unittest/Dry Run")
    ingestionObj = DBIngestion()
    print(ingestionObj.status)
