import os
from util import env, logger
from util.s3utils import S3FileManager

logger = logger.getlogger()


global_s3_bucket_name = env.global_s3_bucket_name
s3_file_manager = S3FileManager(global_s3_bucket_name)


def download_model_to_workspace():
    """
    The method serves the purpose of facilitating the downloading of models from either
    Amazon S3 or a global model repository.
    It assists in retrieving models by providing functionality to fetch them from the specified sources.
    :return: True or False
    """
    model_file_path = env.MODEL_FILE_PATH
    logger.info(f"===>{os.path.join(env.MODEL_DIR_LOC, env.MODEL_NAME)}")
    if os.path.exists(model_file_path):
        logger.info("Model File already exist in /model location ")
    else:
        if env.model_download_s3:
            if s3_file_manager.get_fileFromS3Bucket(env.model_s3_file_loc,
                                                    env.MODEL_NAME, env.MODEL_DIR_LOC, False):
                logger.info("===> Downloaded model file !!")
            else:
                logger.error("===> Failed to download model file from S3 cloud !!")
        else:
            logger.error("===> Using default model @ " + model_file_path)

    if os.path.exists(model_file_path):
        logger.info(f"Model available in desire location {model_file_path}")
        return True
    else:
        logger.info(f"Failed to load the model to {model_file_path}")
        return False


