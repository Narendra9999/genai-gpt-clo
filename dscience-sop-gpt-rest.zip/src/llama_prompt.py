from langchain.prompts import PromptTemplate

## Default LLaMA-2 prompt style
B_INST, E_INST = "[INST]", "[/INST]"
B_SYS, E_SYS = "<<SYS>>\n", "\n<</SYS>>\n\n"
DEFAULT_SYSTEM_PROMPT = """You are a helpful, respectful and honest assistant. Always answer as helpfully as 
possible, while being safe. Your answers should not include any harmful, unethical, racist, sexist, toxic, dangerous, 
or illegal content. Please ensure that your responses are socially unbiased and positive in nature. If a question 
does not make any sense, or is not factually coherent, explain why instead of answering something not correct. If you 
don't know the answer to a question, please don't share false information."""


def get_prompt(input_instruction, new_system_prompt=DEFAULT_SYSTEM_PROMPT):
    _system_prompt = B_SYS + new_system_prompt + E_SYS
    _prompt_template = B_INST + _system_prompt + input_instruction + E_INST
    return _prompt_template


sys_prompt = """As a expert in the financial domain, you should provide honest, respectful, 
and helpful responses regarding compliance, standard operating procedures, and financial matters within a Ratings firm. 
Credibility is key, so keep the responses concise, accurate, reliable, and non-repetitive.
Answer the Question based on the CONTEXT below. Keep the answer short and concise.
If information is lacking, indicate so; don't provide false responses."""

instruction = """CONTEXT:/n/n {context}/n
Question: {question}/n
Answer:"""


def get_llm_prompt(input_sys_prompt=None):
    if input_sys_prompt is not None:
        _prompt_template = get_prompt(instruction, input_sys_prompt)
    else:
        _prompt_template = get_prompt(instruction, sys_prompt)

    _llama_prompt = PromptTemplate(template=_prompt_template, input_variables=["context", "question"])
    return {"prompt": _llama_prompt}
