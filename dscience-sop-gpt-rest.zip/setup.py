"""The setup script."""
import os
import platform
import re
import sys

from os import path
from setuptools import find_packages, setup, Extension
from pathlib import Path

setup_requirements = []
install_requirements = []


def glob_fix(package_name, glob):
    # this assumes setup.py lives in the folder that contains the package
    package_path = Path(f'./{package_name}').resolve()
    return [str(_path.relative_to(package_path))
            for _path in package_path.glob(glob)]


test_requirements = ['pytest>=3', ]
here = path.abspath(path.dirname(__file__))

# Get the long description from the README file
with open(path.join(here, 'README.md')) as f:
    long_description = f.read()
setup(
    author="<Author>",
    author_email='<Author>@spglobal.com',
    python_requires='>=3.5',
    classifiers=[
        'Development Status :: 2 - Pre-Alpha',
        'Intended Audience :: Developers',
        'Natural Language :: English',
        'Programming Language :: Python :: 3.6',
        'Programming Language :: Python :: 3.7',
        'Programming Language :: Python :: 3.8',
    ],
    description="This is a reference implementation for Python based application to deploy as Kubernetes cronjob.",
    long_description=long_description,
    include_package_data=True,
    keywords='dscience-sop-gpt-rest',
    name='dscience-sop-gpt-rest',

    packages=find_packages(include=['util', 'util.*', 'src', 'src.*', 'source_documents', 'llmware','llmware.*']),
    py_modules=['app', 'rootdir', 'app_fastapi'],
    # package_data={'llmware': ['*.c', '*.so', '*.dylib', '.dylibs/*', '*.so.*', *glob_fix('llmware', 'lib/**/*')],
    #               'llmware.libs': ['*']},
    setup_requires=setup_requirements,
    install_requires=install_requirements,
    test_suite='tests',
    tests_require=test_requirements,
    url='https://dev.azure.com/spglobal/ratingsproducts/_git/dscience-sop-gpt-rest',
    version='1.0',
    zip_safe=True

)
