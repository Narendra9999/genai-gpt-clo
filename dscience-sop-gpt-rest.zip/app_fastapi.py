from fastapi import FastAPI, Response, status, Header, Request
from fastapi.responses import JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from fastapi import File, UploadFile, Form
from fastapi import HTTPException
import boto3
import os
from util import env, logger, common_functions
from src.ingestion import DBIngestion
from src.private_gpt import QAndAModel, download_model_to_workspace
from util.mongo_connecter import get_mongo_client

logger = logger.getlogger()

app = FastAPI(debug=True)
username = None
global_s3_bucket_name = env.global_s3_bucket_name
documents_s3_loc = env.documents_s3_loc
CHROMADB = env.CHROMADB
user_id = env.LLM_DEFAULT_USER

origins = [
    "http://localhost",
    "http://localhost:8080",
    "http://0.0.0.0:8080 ",
    "http://localhost:3000",
    "https://poc-dataservices-modelinference-rest.api.dev.spratingsvpc.com",
    "http://poc-dataservices-modelinference-rest.api.dev.spratingsvpc.com",
    "https://poc-dataservices-modelinference-rest.caas.dev.spratingsvpc.com",
    "http://poc-dataservices-modelinference-rest.caas.dev.spratingsvpc.com",
    "http://poc-dataservices-modelinference-rest-pod-1.caas.dev.spratingsvpc.com",
    "https://poc-dataservices-modelinference-rest-pod-1.caas.dev.spratingsvpc.com",
    "http://poc-dataservices-modelinference-rest-pod-2.caas.dev.spratingsvpc.com",
    "https://poc-dataservices-modelinference-rest-pod-2.caas.dev.spratingsvpc.com",
    "https://poc-dscience-chatbot-ui-dev.faas.dev.spratingsvpc.com",
    "https://poc-dscience-chatbot-ui-si.faas.qa.spratingsvpc.com"
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

logger.info("===> init starting for DBIngestion")
ingest = DBIngestion()  # __init__: initial method will execute
logger.info("===> init starting for QAndAModel")
qaObject = QAndAModel()  # __init__: initial method will execute
if not env.local_model:
    s3_client = boto3.client('s3')

@app.get('/ready')
async def ready():
    logger.info(f"requested /ready")
    msg = {"Message": "Ready"}
    return msg


@app.get("/get_sys_config_info")
async def get_avx2_info():
    import cpuinfo
    info = cpuinfo.get_cpu_info()
    flags = info['flags']

    import sys
    logger.info("Python version")
    logger.info(sys.version)

    logger.info("Version info.")
    logger.info(sys.version_info)

    if 'avx' in flags or 'avx2' in flags:
        logger.info("==> flags...")
        logger.info(flags)
        return "AVX is supported"
    else:
        return "AVX is not supported"


@app.get('/gpt/refresh')
async def ingest_data_vector_db():
    """
     # when ever new document ingest, need to call to create vector DB
    """
    try:
        if user_id:
            logger.info(f"/gpt/refresh: Refresh Requested for the User :{user_id}")
            if ingest.refresh_vector_db(user_id):
                logger.info(f"For the {user_id} : Refreshing Db with new embeddings")
                return JSONResponse(content={"message": f"Document upload successful, ingested data and refresh DB "},
                                    status_code=status.HTTP_200_OK)
            else:
                return JSONResponse(content={"message": f"Document upload successfully, but failed to ingest data to "
                                                        f"knowledgebase as it very low"},
                                    status_code=status.HTTP_403_FORBIDDEN)
        else:
            return JSONResponse(content={"message": f"User ID empty or incorrect id : {user_id}"},
                                status_code=status.HTTP_400_BAD_REQUEST)
    except Exception as ex:
        return JSONResponse(content={"message": str(ex)},
                            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR)


@app.post('/gpt/chat')
async def get_chat(query: dict):
    logger.info(f"requested /gpt/chat service with query: {query['query']}")
    # #qaObject.llm is None: return {"message": "Model was not loaded from S3 !!", "status": 400}
    optional_parameters_obj = common_functions.process_child_object(query)
    logger.info(optional_parameters_obj)
    if "optionalParameter" not in query or query['optionalParameter'] in ["None", None]:
        logger.info("optionalParameter is null and marking all default LLM parameters..")
        optional_parameters_obj['optionalParameter'] = {}
        # return qaObject.connect_llm_qa_model(str(query['query']), query['user_id'])
        # return qaObject.load_step_back_retrieve(str(query['query']), user_id)
        # output = qaObject.end_to_end_model_flow({"query": query['query']})
        # return output
    # else:
    #     # optional_parameters_obj = common_functions.process_child_object(query)
    #     # optional_parameters_obj['optionalParameter'] = optional_parameters_obj.get('optionalParameter', {})

    optional_parameters_obj['optionalParameter']['query'] = query['query']
    optional_parameters_obj['optionalParameter']['user_id'] = user_id
    logger.info(optional_parameters_obj)
    if CHROMADB:
        output = qaObject.end_to_end_model_flow(optional_parameters_obj['optionalParameter'])
    else:
        output = qaObject.op_end_to_end_model_flow(optional_parameters_obj['optionalParameter'])
    return output


@app.post('/gpt/full_parameter_fine')
async def model_with_params(input_params: dict):
    try:
        logger.info("Running the fully parameterized. Following are the parameters")
        optional_parameters_obj = common_functions.process_child_object(input_params)
        optional_parameters_obj['optionalParameter']['query'] = input_params['query']
        optional_parameters_obj['optionalParameter']['user_id'] = input_params['user_id']
        logger.info(optional_parameters_obj)
        if CHROMADB:
            output = qaObject.end_to_end_model_flow(optional_parameters_obj['optionalParameter'])
        else:
            output = qaObject.op_end_to_end_model_flow(optional_parameters_obj['optionalParameter'])
        return output
    except Exception as ex:
        logger.warning(ex)


@app.post("/gpt/upload")
async def upload_file(file: UploadFile = File(...)):
    if not file.filename:
        return {"message", "No document file found"}, 400

    contents = await file.read()
    if not os.path.exists(os.path.join(env.SOURCE_DIRECTORY, user_id)):
        os.makedirs(os.path.join(env.SOURCE_DIRECTORY, user_id))
    save_path = os.path.join(env.SOURCE_DIRECTORY, user_id, file.filename)
    with open(save_path, "wb") as f:
        f.write(contents)
    return {"filename": file.filename, "message": "Document upload successful"}


@app.get('/gpt/load_model')
async def load_model():
    if qaObject.load_model():
        return {"response": "Successfully run the model. Ready to use now.."}
    else:
        return {"response": "Failed run the model..."}


@app.get('/gpt/model_download')
async def download_model():
    if download_model_to_workspace():
        return {"response": "Successfully downloaded the model. Ready to use now..s"}
    else:
        return {"response": "Failed to downloaded the model.Ensure S3 or Global Model repo url/parameter updated "}


@app.post("/gpt/upload_to_S3")
async def upload_to_s3(file: UploadFile = File(...)):
    logger.info(f"/gpt/upload_to_S3 : user_id:{user_id}")
    if not file.filename:
        logger.info(f"filename:{file.filename}")
        return JSONResponse(content={"message": "No document file found"},
                            status_code=status.HTTP_400_BAD_REQUEST)
    if not env.local_model:
        if user_id:
            s3_key = documents_s3_loc + env.LLM_DEFAULT_USER + "/" + file.filename
        else:
            s3_key = documents_s3_loc + file.filename

        logger.info(f"Upload to S3 File path: {s3_key}")
        s3_client.upload_fileobj(file.file, global_s3_bucket_name, s3_key)
    else:
        contents = await file.read()
        if not os.path.exists(os.path.join(env.SOURCE_DIRECTORY, user_id)):
            os.makedirs(os.path.join(env.SOURCE_DIRECTORY, user_id))
        save_path = os.path.join(env.SOURCE_DIRECTORY, user_id, file.filename)
        with open(save_path, "wb") as f:
            f.write(contents)

    try:
        if user_id:
            logger.info(f"For the {user_id} : Ingesting new embeddings")
            if ingest.refresh_vector_db(user_id):
                logger.info(f"For the {user_id} : Refreshing Db with new embeddings")
                return JSONResponse(content={"filename": file.filename,
                                             "message": f"Document upload successful, ingested data and refresh DB "},
                                    status_code=status.HTTP_200_OK)
            else:
                return JSONResponse(content={"filename": file.filename,
                                             "message": f"Document upload successfully, but failed to ingest data to "
                                                        f"knowledgebase as it very low"},
                                    status_code=status.HTTP_424_FAILED_DEPENDENCY)

        return JSONResponse(content={"filename": file.filename,
                                     "message": f"Document upload successful. Refresh the Ingest call for the user"},
                            status_code=status.HTTP_200_OK)
    except Exception as ex:
        return JSONResponse(content={"filename": file.filename,
                                     "message": str(ex)},
                            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR)


@app.post('/gpt/read_user')
async def process_username(new_username: str):
    global username
    username = new_username
    # Process the received username as desired
    return {'message': f'Received username: {username}'}


@app.post('/gpt/delete_old_files')
async def clean_up_files():
    try:
        if env.delete_old_files():
            return JSONResponse(content={"message": str("Documents deleted successfully.")},
                                status_code=status.HTTP_200_OK
                                )
        else:
            return JSONResponse(content={"message": str("failed to delete documents.")},
                                status_code=status.HTTP_401_UNAUTHORIZED
                                )
    except Exception as ex:
        logger.error(ex)
        return JSONResponse(content={"message": str(ex)},
                            status_code=status.HTTP_400_BAD_REQUEST
                            )


@app.get('/gpt/documents_list')
async def process_username():
    document_list = []
    try:
        if user_id:
            response = s3_client.list_objects_v2(
                Bucket=global_s3_bucket_name,
                Prefix=documents_s3_loc + user_id + '/')

            for content in response.get('Contents', []):
                document_list.append(content['Key'])
                logger.info(os.path.split(content["Key"])[-1])

            return JSONResponse(content={"documents": document_list, "user_id": user_id},
                                status_code=status.HTTP_200_OK
                                )
        else:
            return JSONResponse(content={"message": str("Please provide the user1")},
                                status_code=status.HTTP_401_UNAUTHORIZED
                                )
    except Exception as ex:
        logger.error(ex)
        return JSONResponse(content={"message": str(ex)},
                            status_code=status.HTTP_400_BAD_REQUEST
                            )


@app.delete('/gpt/delete_document')
async def delete_document(document_name: str):
    try:
        if user_id and document_name:
            if CHROMADB:
                if not ingest.delete_document_embeddings(document_name, user_id):
                    return JSONResponse(
                        content={"message": f"Document '{document_name}' Not Found '{user_id}'"},
                        status_code=status.HTTP_403_FORBIDDEN)
            else:
                if not ingest.op_delete_document_embeddings(document_name, user_id):
                    return JSONResponse( content={"message": f"Document '{document_name}' Not Found '{user_id}'"},
                                         status_code=status.HTTP_403_FORBIDDEN)

            if not env.local_model:
                s3_key = documents_s3_loc + user_id + '/' + document_name
                s3_client.delete_object(Bucket=global_s3_bucket_name, Key=s3_key)
                logger.info(f"successfully removed the file {document_name} from S3")

            user_src_dir = os.path.join(env.SOURCE_DIRECTORY, user_id)
            common_functions.delete_file_by_name(user_src_dir, document_name)
            return JSONResponse(
                content={"message": f"Document '{document_name}' deleted successfully for user '{user_id}'"},
                status_code=status.HTTP_200_OK)
        else:
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST,
                                detail="Please provide both user ID and document name")
    except Exception as ex:
        logger.error(ex)
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(ex))


@app.get('/gpt/documents_list_from_vector_db')
async def show_documents_list():
    try:
        if user_id:
            if CHROMADB:
                document_list = ingest.get_document_embeddings_list(user_id)
            else:
                document_list = ingest.op_get_document_embeddings_list(user_id)

            return JSONResponse(content={"documents": document_list, "user_id": user_id},
                                status_code=status.HTTP_200_OK
                                )
        else:
            return JSONResponse(content={"message": str("Please login with USER ID")},
                                status_code=status.HTTP_401_UNAUTHORIZED
                                )
    except Exception as ex:
        logger.error(ex)
        return JSONResponse(content={"message": str(ex)},
                            status_code=status.HTTP_400_BAD_REQUEST
                            )


@app.delete('/gpt/delete_all_documents')
async def delete_all_documents_for_user():
    try:
        if user_id:
            if not env.local_model:
                prefix = documents_s3_loc + user_id + '/'
                logger.info(f"Delete All the document {prefix}")
                response = s3_client.list_objects_v2(Bucket=global_s3_bucket_name, Prefix=prefix)
                deleted_count = 0
                for content in response.get('Contents', []):
                    s3_client.delete_object(Bucket=global_s3_bucket_name, Key=content['Key'])
                    deleted_count += 1
                logger.info("deleting all embeddings from persist directory")
                logger.info(f"{deleted_count} documents deleted successfully for user '{user_id}'")

            if CHROMADB:
                ingest.delete_all_embeddings(user_id)
            else:
                ingest.op_delete_all_embeddings(user_id)
            return JSONResponse(
                content={"message": f"documents deleted successfully for user {user_id} "},
                status_code=status.HTTP_200_OK)
        else:
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Please provide a user ID")
    except Exception as ex:
        logger.error(ex)
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(ex))


@app.post('/gpt/save_feedback')
async def save_feedback(request: Request):
    try:
        feedback_collection = get_mongo_client()
        feedback_data = await request.json()
        result = feedback_collection.insert_one(feedback_data)
        return {"message": "Feedback saved successfully", "feedback_id": str(result.inserted_id)}
    except Exception as ex:
        return {"message": "Failed to save feedback", "error": str(ex)}


@app.get('/gpt/llmwareprompt')
async def llm_ware_model_load():
    try:
        from llmware.prompts import Prompt
        import os
        print(os.environ["TRANSFORMERS_CACHE"])
        import torch
        # model_name = "llmware/dragon-llama-7b-v0"
        # model_name = "llmware/dragon-mistral-7b-v0"
        # device = torch.device('mps')
        prompter = Prompt().load_model("llmware/dragon-mistral-7b-v0", from_hf=True)

        test_list = [
            {"query": "What is the total amount of the invoice?",
             "answer": "$22,500.00",
             "context": "Services Vendor Inc. \n100 Elm Street Pleasantville, NY \nTO Alpha Inc. 5900 1st Street "
                        "Los Angeles, CA \nDescription Front End Engineering Service $5000.00 \n Back End Engineering"
                        " Service $7500.00 \n Quality Assurance Manager $10,000.00 \n Total Amount $22,500.00 \n"
                        "Make all checks payable to Services Vendor Inc. Payment is due within 30 days."
                        "If you have any questions concerning this invoice, contact Bia Hermes. "
                        "THANK YOU FOR YOUR BUSINESS!  INVOICE INVOICE # 0001 DATE 01/01/2022 FOR Alpha Project P.O. # 1000"}
        ]

        for i, entries in enumerate(test_list):
            print(f"\n{i + 1}. Query: {entries['query']}")
            # run the prompt
            output = prompter.prompt_main(entries["query"], context=entries["context"]
                                          , prompt_name="default_with_context", temperature=0.30)

            llm_response = output["llm_response"].strip("\n")
            print(f"LLM Response: {llm_response}")
            return llm_response
    except Exception as ex:
        print(ex)
        return ex


@app.get('/gpt/sys_command')
async def install_sys_command(sys_command: str):
    try:
        import os
        os.system(f"{sys_command}")
        return "Executed"
    except Exception as ex:
        return ex


# @app.get('/file_conversion')
# async def file_conversion_check(file_path, file_path_out):
#     # !pip install aspose-words
#     import aspose.words as aw
#     # Load the PDF document from the disc.
#     doc = aw.Document(file_path)
#     # Save the document to DOCX format.
#     doc.save(file_path_out)
#     print("saved...")


if __name__ == "__main__":
    logger.info("Starting Model Server ")
    import uvicorn

    uvicorn.run(app, host="0.0.0.0", port=8080)
